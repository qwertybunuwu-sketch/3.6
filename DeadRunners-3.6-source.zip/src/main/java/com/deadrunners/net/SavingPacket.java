package com.deadrunners.net;

import com.deadrunners.client.SavingHud;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: началось сохранение на кассете, показать «Saving...». */
public record SavingPacket() {
    public void encode(FriendlyByteBuf buf) {}

    public static SavingPacket decode(FriendlyByteBuf buf) {
        return new SavingPacket();
    }

    public static void handle(SavingPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> SavingHud::start));
        ctx.setPacketHandled(true);
    }
}
