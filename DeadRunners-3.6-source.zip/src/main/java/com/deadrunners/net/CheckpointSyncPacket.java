package com.deadrunners.net;

import com.deadrunners.CheckpointClient;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: какая звезда сейчас активна у игрока. */
public record CheckpointSyncPacket(boolean has, ResourceLocation dim, BlockPos star) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(has);
        buf.writeResourceLocation(dim);
        buf.writeBlockPos(star);
    }

    public static CheckpointSyncPacket decode(FriendlyByteBuf buf) {
        return new CheckpointSyncPacket(buf.readBoolean(), buf.readResourceLocation(), buf.readBlockPos());
    }

    public static void handle(CheckpointSyncPacket p, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            if (p.has) CheckpointClient.set(ResourceKey.create(Registries.DIMENSION, p.dim), p.star);
            else CheckpointClient.clear();
        });
        ctx.setPacketHandled(true);
    }
}
