package com.deadrunners;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

import com.deadrunners.net.Net;

@Mod(DeadRunnersMod.MODID)
public class DeadRunnersMod {
    public static final String MODID = "deadrunners";

    public DeadRunnersMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        bus.addListener(this::addCreative);

        ModLoadingContext ctx = ModLoadingContext.get();
        // SERVER-конфиг синхронизируется с сервера на клиент (баланс, перезарядка, сила прыжка).
        // файлы конфигов DeadRunners 1.x
        ctx.registerConfig(ModConfig.Type.SERVER, DeadRunnersConfig.SERVER_SPEC, "deadrunners-server.toml");
        // CLIENT-конфиг: частицы, звуки, HUD.
        ctx.registerConfig(ModConfig.Type.CLIENT, DeadRunnersConfig.CLIENT_SPEC, "deadrunners-client.toml");

        bus.addListener(this::commonSetup);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.WIND_DASH_EGG);
            event.accept(ModItems.LIFE_ESSENCE_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.CHECKPOINT_STAR);
            event.accept(ModItems.SPACE_MARK);
        }
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
    }
}
