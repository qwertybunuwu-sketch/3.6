package com.deadrunners.net;

import com.deadrunners.client.LifeClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: состояние ожогов для индикатора здоровья. */
public record LifeSyncPacket(int burnLeft, int burnTotal, int scars) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(burnLeft);
        buf.writeVarInt(burnTotal);
        buf.writeVarInt(scars);
    }

    public static LifeSyncPacket decode(FriendlyByteBuf buf) {
        return new LifeSyncPacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(LifeSyncPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> LifeClient.set(packet.burnLeft(), packet.burnTotal(), packet.scars())));
        ctx.setPacketHandled(true);
    }
}
