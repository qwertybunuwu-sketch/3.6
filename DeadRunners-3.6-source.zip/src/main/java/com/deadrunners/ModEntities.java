package com.deadrunners;

import com.deadrunners.entity.LifeEssenceEntity;
import com.deadrunners.entity.WindDashEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DeadRunnersMod.MODID);

    public static final RegistryObject<EntityType<WindDashEntity>> WIND_DASH = ENTITIES.register("wind_dash",
            () -> EntityType.Builder.<WindDashEntity>of(WindDashEntity::new, MobCategory.MISC)
                    .sized(0.6f, 0.6f).clientTrackingRange(8).updateInterval(20).fireImmune()
                    .build("wind_dash"));

    public static final RegistryObject<EntityType<LifeEssenceEntity>> LIFE_ESSENCE = ENTITIES.register("life_essence",
            () -> EntityType.Builder.<LifeEssenceEntity>of(LifeEssenceEntity::new, MobCategory.MISC)
                    .sized(0.6f, 0.6f).clientTrackingRange(8).updateInterval(20).fireImmune()
                    .build("life_essence"));

    private ModEntities() {}
}
