package com.deadrunners;

import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Клиентский список загруженных меток пространства (чтобы не сканировать мир при наведении). */
public final class SpaceMarks {
    public static final List<BlockPos> CLIENT = new ArrayList<>();

    private SpaceMarks() {}

    public static void add(BlockPos pos) {
        if (!CLIENT.contains(pos)) CLIENT.add(pos.immutable());
    }

    public static void remove(BlockPos pos) {
        CLIENT.remove(pos);
    }
}
