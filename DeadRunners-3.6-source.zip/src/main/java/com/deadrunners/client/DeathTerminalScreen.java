package com.deadrunners.client;

import com.deadrunners.ModSounds;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * Экран смерти «КАСЕТА»: идёт запись (REC), сигнал рвётся, из глубины экрана
 * проступает DEAD END, лента мотается назад (REWIND), белая вспышка — возврат к жизни,
 * DEAD END ещё раз и глитч-исчезновение. Всё привязано к времени звука death.ogg (6 c).
 * Без аллокаций в рендере.
 */
public class DeathTerminalScreen extends Screen {
    private static final float T_BREAK = 2.45f, T_REW0 = 3.00f, T_REW1 = 3.85f, T_FLASH = 3.90f,
            T_DE2 = 4.06f, T_VANISH = 4.80f, VANISH_LEN = 0.24f, T_DARK = 4.90f;
    private static final int END_TICK = 102;
    private static final int FADE_HOLD = 4, FADE = 12;
    private static final int SKIP_AFTER = 10;
    /** Огибающая звука по тикам (0..99), вшита из death.ogg. */
    private static final int[] ENV = {20,50,53,42,42,44,51,50,45,40,44,49,52,45,44,51,53,57,52,45,50,46,52,55,52,48,43,44,50,52,53,52,45,43,48,47,53,57,50,48,46,43,47,50,57,52,51,54,47,97,83,69,60,60,55,56,56,51,42,60,70,54,55,48,47,53,49,57,54,52,52,54,55,54,50,53,72,72,99,93,84,80,74,68,63,61,53,55,49,45,46,38,42,37,36,32,68,57,49,48,43,20,19,17};
    private static final int NC = 44;
    private static final String GL = "DEARCWINSUM";
    private static final int[][] GLY = {
        {0x1E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1E}, // D
        {0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F}, // E
        {0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11}, // A
        {0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11}, // R
        {0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E}, // C
        {0x11, 0x11, 0x11, 0x15, 0x15, 0x1B, 0x11}, // W
        {0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x1F}, // I
        {0x11, 0x19, 0x15, 0x15, 0x13, 0x11, 0x11}, // N
        {0x0E, 0x11, 0x10, 0x0E, 0x01, 0x11, 0x0E}, // S
        {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E}, // U
        {0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11}  // M
    };
    private static SimpleSoundInstance current;

    private final int[] bS = new int[NC], bE = new int[NC];
    private final float[] bL = new float[NC];
    private int nb;
    private Component skip;
    private int fadeStart = -1;
    private boolean respawned;
    private int ticks;
    private SimpleSoundInstance sound;

    public DeathTerminalScreen() {
        super(Component.translatable("deadrunners.death.title"));
    }

    private static int h(int a, int b) {
        int x = a * 374761393 + b * 668265263;
        x = (x ^ (x >>> 13)) * 1274126177;
        return (x ^ (x >>> 16)) & 0x7fffffff;
    }

    private static float envAt(float time) {
        int i = Mth.clamp((int) time, 0, ENV.length - 2);
        float f = Mth.clamp(time - i, 0f, 1f);
        return ENV[i] + (ENV[i + 1] - ENV[i]) * f;
    }

    /** Сила «удара» (только пики: слом, вспышка, глитч). */
    private static float kickAt(float time) {
        return Mth.clamp((envAt(time) - 60f) / 39f, 0f, 1f);
    }

    /** Вероятность глитча (%) по фазам. */
    private static int rateAt(float t) {
        if (t < T_BREAK - 0.03f) return 3;
        if (t < T_REW0) return 28 + (int) (42 * Math.exp(-(t - T_BREAK) * 5f));
        if (t < T_REW1) return 30 + (int) (40 * (t - T_REW0) / (T_REW1 - T_REW0));
        if (t < T_FLASH + 0.05f) return 85;
        if (t < T_VANISH) return 10 + (int) (80 * Math.exp(-(t - T_FLASH) * 6f));
        return 90;
    }

    @Override
    protected void init() {
        skip = Component.translatable("deadrunners.death.skip");
        if (sound == null && minecraft != null) {
            if (current != null) minecraft.getSoundManager().stop(current);
            sound = SimpleSoundInstance.forUI(ModSounds.DEATH.get(), 1.0f, 1.0f);
            current = sound;
            minecraft.getSoundManager().play(sound);
        }
        // блоки «записи»: ширина 2..5 ячеек, высота от громкости на этом месте
        nb = 0;
        int i = 0;
        while (i < NC) {
            int e = Math.min(NC, i + 2 + h(i, 901) % 4);
            float m = 0f;
            for (int c = i; c < e; c++) {
                m = Math.max(m, ENV[Math.min((int) (c / (float) NC * T_BREAK * 20f), ENV.length - 1)]);
            }
            bS[nb] = i;
            bE[nb] = e;
            bL[nb] = Mth.clamp((m - 40f) / 20f, 0f, 1f);
            nb++;
            i = e;
        }
    }

    @Override
    public void tick() {
        ticks++;
        if (fadeStart >= 0) {
            if (ticks - fadeStart >= FADE_HOLD + FADE && minecraft != null) minecraft.setScreen(null);
            return;
        }
        if (minecraft != null && minecraft.player != null && !minecraft.player.isDeadOrDying()) {
            respawned = true;
            stopSound();
            fadeStart = ticks;
            return;
        }
        if (ticks >= END_TICK) respawn();
    }

    private void stopSound() {
        if (sound != null && minecraft != null) minecraft.getSoundManager().stop(sound);
    }

    /** Респавн сразу, а экран остаётся и плавно «проявляет» игру из чёрного. */
    private void respawn() {
        if (respawned) return;
        respawned = true;
        if (minecraft != null) {
            if (ticks < END_TICK - 2) stopSound();
            if (minecraft.player != null) minecraft.player.respawn();
        }
        fadeStart = ticks;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        float time = ticks + partial;
        if (fadeStart >= 0) {
            float ft = time - fadeStart - FADE_HOLD;
            float a = ft <= 0f ? 1f : 1f - Mth.clamp(ft / FADE, 0f, 1f);
            a = a * a * (3f - 2f * a);
            if (a > 0.003f) g.fill(0, 0, width, height, (int) (a * 255) << 24);
            return;
        }
        float t = time * 0.05f;
        int frame = (int) (time * 2.5f);
        int rate = rateAt(t);
        float kick = kickAt(time);
        int amp = (int) (kick * kick * 7f) + (rate > 40 ? 1 : 0);
        int shx = amp == 0 ? 0 : (h(frame, 1) % (amp * 2 + 1)) - amp;
        int shy = amp == 0 ? 0 : (h(frame, 2) % (amp * 2 + 1)) - amp;
        if (h(frame, 3) % 100 > rate + 35) { shx = 0; shy = 0; }
        g.fill(0, 0, width, height, 0xFF000000);
        g.pose().pushPose();
        g.pose().translate(shx, shy, 0);
        scene(g, t, frame, rate, kick);
        g.pose().popPose();
        overlay(g, t, frame, rate, kick);
    }

    // ---------- пиксельные примитивы ----------

    private static void disc(GuiGraphics g, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.sqrt(r * r - dy * dy);
            g.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, col);
        }
    }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) / 2);
        for (int i = 0; i <= n; i++) {
            int x = x0 + (x1 - x0) * i / n, y = y0 + (y1 - y0) * i / n;
            g.fill(x, y, x + 2, y + 2, col);
        }
    }

    private static void outline(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        g.fill(x0, y0, x1, y0 + 1, col);
        g.fill(x0, y1 - 1, x1, y1, col);
        g.fill(x0, y0, x0 + 1, y1, col);
        g.fill(x1 - 1, y0, x1, y1, col);
    }

    private static int pxw(String s, float u) {
        int c = 0;
        for (int i = 0; i < s.length(); i++) c += s.charAt(i) == ' ' ? 4 : 6;
        return Math.round((c - 1) * u);
    }

    /** Текст 5x7 пикселей. shiftPct/amt — построчный сдвиг (tracking), dropPct — выпадение пикселей. */
    private static void pxText(GuiGraphics g, String s, int ox, int oy, float u, int col,
                               int frame, int shiftPct, int amt, int dropPct) {
        int cx = 0;
        for (int ci = 0; ci < s.length(); ci++) {
            char c = s.charAt(ci);
            if (c == ' ') { cx += 4; continue; }
            int gi = GL.indexOf(c);
            if (gi < 0) { cx += 6; continue; }
            int[] gl = GLY[gi];
            for (int r = 0; r < 7; r++) {
                int off = 0;
                if (shiftPct > 0 && h(frame, r + 200) % 100 < shiftPct) off = (h(frame, r + 210) % (amt * 2 + 1)) - amt;
                int y0 = oy + Math.round(r * u), y1 = oy + Math.round((r + 1) * u);
                for (int b = 0; b < 5; b++) {
                    if ((gl[r] & (0x10 >> b)) == 0) continue;
                    if (dropPct > 0 && h(frame * 31 + ci * 7 + r, b + 500) % 100 < dropPct) continue;
                    g.fill(ox + off + Math.round((cx + b) * u), y0, ox + off + Math.round((cx + b + 1) * u), y1, col);
                }
            }
            cx += 6;
        }
    }

    /** DEAD END (красный) или RESUME (зелёный) «вдалеке, за стеклом»: тёмный проём-туннель, свечение, маленький пиксельный текст. */
    private void deadEnd(GuiGraphics g, int frame, int shiftPct, int amt, int dropPct, float a, boolean resume) {
        float du = Math.max(1.5f, width * 0.17f / 45f);
        int tun = Math.round(45 * du), th = Math.round(7 * du);
        String text = resume ? "RESUME" : "DEAD END";
        int tw = pxw(text, du);
        int glow = resume ? 0x18E8A0 : 0xE81830, hi = resume ? 0x80FFD8 : 0xFF6070, main = resume ? 0x30F0B0 : 0xE82838;
        // центр надписи = точка схода фоновой сетки (tunnelBackdrop), без смещений
        int cx = width / 2, cy = height / 2;
        int ox = cx - tw / 2, oy = cy - th / 2;
        int rw = (int) (tun * 1.38f) / 2, rh = (int) (th * 2.7f) / 2;
        // тёмная подложка под надпись (без сетки: сетка теперь фоновая, на весь экран)
        g.fill(cx - rw, cy - rh, cx + rw, cy + rh, 0xD0000000);
        int e = Math.round(du * 2f);
        g.fill(ox - e * 2, oy - e * 2, ox + tw + e * 2, oy + th + e * 2, ((int) (a * 0x10) << 24) | glow);
        g.fill(ox - e, oy - e, ox + tw + e, oy + th + e, ((int) (a * 0x22) << 24) | glow);
        pxText(g, text, ox + 1, oy, du, ((int) (a * 0x60) << 24) | hi, frame, shiftPct, amt, dropPct);
        pxText(g, text, ox, oy, du, ((int) (a * 255) << 24) | main, frame, shiftPct, amt, dropPct);
    }


    /** Фоновый туннель на весь экран: статичная сетка, уходящая в даль к центру, где надпись. */
    private void tunnelBackdrop(GuiGraphics g, float t, int frame, int rate) {
        float tv;
        if (t >= T_BREAK && t < T_FLASH - 0.02f) {
            tv = Mth.clamp((t - T_BREAK) / 0.35f, 0f, 1f);
        } else if (t >= T_DE2 && t < T_VANISH + VANISH_LEN) {
            tv = Mth.clamp((t - T_DE2) / 0.25f, 0f, 1f) * (1f - Mth.clamp((t - T_VANISH) / VANISH_LEN, 0f, 1f));
        } else {
            return;
        }
        if (h(frame, 97) % 100 < rate / 3) return; // глитч: кадр выпадает
        int cx = width / 2, cy = height / 2;
        float k0 = 0.12f;
        int x0 = Math.round(cx * k0), y0 = Math.round(cy * k0);
        // лучи перспективы: углы и по два луча на потолок/пол (точки на 1/2 ширины проёма)
        int la = (int) (0x30 * tv);
        if (la > 0) {
            int cl = (la << 24) | 0x8890A0;
            dashed(g, cx - x0, cy - y0, 0, 0, cl);
            dashed(g, cx + x0, cy - y0, width, 0, cl);
            dashed(g, cx - x0, cy + y0, 0, height, cl);
            dashed(g, cx + x0, cy + y0, width, height, cl);
            int hx = x0 / 2;
            dashed(g, cx - hx, cy - y0, cx - cx / 2, 0, cl);
            dashed(g, cx + hx, cy - y0, cx + cx / 2, 0, cl);
            dashed(g, cx - hx, cy + y0, cx - cx / 2, height, cl);
            dashed(g, cx + hx, cy + y0, cx + cx / 2, height, cl);
        }
        // рамки сечений: расстояния растут геометрически, дальние тусклее
        for (int i = 0; i < 8; i++) {
            float k = k0 * (float) Math.pow(1.5, i);
            if (k > 1.5f) break;
            int hx = Math.round(cx * k), hy = Math.round(cy * k);
            int a = (int) (0x58 * tv * Math.min(1f, 0.25f + k));
            if (a <= 0) continue;
            outline(g, cx - hx, cy - hy, cx + hx, cy + hy, (a << 24) | 0x8890A0);
        }
    }

    /** Пунктирная диагональ (редкие точки, чтобы не плодить сотни fill). */
    private static void dashed(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) / 5);
        for (int i = 0; i <= n; i++) {
            int x = x0 + (x1 - x0) * i / n, y = y0 + (y1 - y0) * i / n;
            g.fill(x, y, x + 2, y + 2, col);
        }
    }

    private void scene(GuiGraphics g, float t, int frame, int rate, float kick) {
        g.fill(0, 0, width, height, 0xFF07080A);
        tunnelBackdrop(g, t, frame, rate);
        int tu = Math.max(2, height / 90);
        int m = Math.max(5, width / 70);
        outline(g, m, m, width - m, height - m, 0xFF4A5058);
        outline(g, m + 1, m + 1, width - m - 1, height - m - 1, 0xFF4A5058);
        boolean broken = t >= T_BREAK && t < T_REW0;
        boolean rew = t >= T_REW0 && t < T_REW1;
        boolean alive = t >= T_FLASH;

        // ---- REC / REWIND ----
        int lx = m + tu * 3, ly = m + tu * 3, r = tu * 3;
        String label = rew ? "REWIND" : "REC";
        int lc = alive ? 0xFF6A7078 : 0xFFE8EAEE;
        if (t < T_BREAK) {
            boolean on = ((int) (t / 0.45f) & 1) == 0;
            if (on) {
                disc(g, lx + r, ly + tu * 7 / 2, r + tu, 0x40FF2030);
                disc(g, lx + r, ly + tu * 7 / 2, r, 0xFFF02030);
            } else {
                disc(g, lx + r, ly + tu * 7 / 2, r, 0xFF3A1016);
            }
        } else if (rew) {
            int c = (frame & 1) == 0 ? 0xFFFFFFFF : 0xFFB0B4BA;
            for (int k = 0; k < 2; k++) {
                int xr = lx + k * tu * 3;
                for (int rr = 0; rr < 7; rr++) {
                    int w = (4 - Math.abs(rr - 3)) * tu / 2 + tu / 2;
                    g.fill(xr + tu * 3 - w, ly + rr * tu, xr + tu * 3, ly + (rr + 1) * tu, c);
                }
            }
        } else {
            disc(g, lx + r, ly + tu * 7 / 2, r, alive ? 0xFF22262B : 0xFF3A1016);
        }
        int tx = lx + r * 2 + tu * 2;
        boolean hideLabel = broken && h(frame, 70) % 100 < rate;
        if (!hideLabel) pxText(g, label, tx, ly, tu, lc, frame, broken ? rate / 2 : 0, tu, 0);
        float sw = Math.abs(t - T_REW0);
        if (sw < 0.14f) {
            int lw = pxw("REWIND", tu);
            for (int i = 0; i < 16; i++) {
                int bx = tx + h(frame, 300 + i) % (lw + tu * 6) - tu * 2;
                int byl = ly - tu + h(frame, 320 + i) % (tu * 9);
                int c = (h(frame, 340 + i) & 3);
                g.fill(bx, byl, bx + tu + h(frame, 360 + i) % (tu * 4), byl + 1 + h(frame, 380 + i) % (tu * 2),
                        c == 0 ? 0xFFFFFFFF : c == 1 ? 0xFFE02030 : c == 2 ? 0xFF20E0FF : 0xFF000000);
            }
        }

        // ---- кнопки |< II >| ----
        int cell = tu * 8, gap = tu * 3;
        int ix = width - m - tu * 3 - (cell * 3 + gap * 2), iy = ly;
        int cOn = 0xFFE8EAEE, cOff = 0xFF5A6068;
        int c0 = rew ? ((frame & 1) == 0 ? 0xFFFFFFFF : cOn) : cOff;
        int c1 = t < T_BREAK ? cOn : broken ? (h(frame, 71) % 100 < rate ? 0xFFE02030 : cOff) : cOff;
        int c2 = cOff;
        for (int rr = 0; rr < 7; rr++) {
            int w = (4 - Math.abs(rr - 3)) * tu;
            g.fill(ix + tu * 2, iy + rr * tu, ix + tu * 2 + w, iy + (rr + 1) * tu, c0);
        }
        g.fill(ix, iy, ix + tu, iy + 7 * tu, c0);
        int x1i = ix + cell + gap;
        g.fill(x1i + tu, iy, x1i + tu * 3, iy + 7 * tu, c1);
        g.fill(x1i + tu * 5, iy, x1i + tu * 7, iy + 7 * tu, c1);
        int x2i = ix + (cell + gap) * 2;
        for (int rr = 0; rr < 7; rr++) {
            int w = (4 - Math.abs(rr - 3)) * tu;
            g.fill(x2i + tu, iy + rr * tu, x2i + tu + w, iy + (rr + 1) * tu, c2);
        }
        g.fill(x2i + tu * 6, iy, x2i + tu * 7, iy + 7 * tu, c2);

        // ---- шкала, запись и головка ----
        int x0 = m + tu * 3, x1 = width - m - tu * 3;
        int headMax = x0 + (int) ((x1 - x0) * 0.84f);
        int by = (int) (height * 0.80f), bottom = height - m - 2;
        float hf;
        if (t < T_BREAK) hf = t / T_BREAK;
        else if (t < T_REW0) hf = 1f;
        else if (t < T_REW1) hf = 1f - (float) Math.pow((t - T_REW0) / (T_REW1 - T_REW0), 1.7);
        else hf = 0f;
        int hx = x0 + (int) ((headMax - x0) * hf);
        if (broken && h(frame, 72) % 100 < rate) hx += (h(frame, 73) % (tu * 2 + 1)) - tu;
        float cw = (headMax - x0) / (float) NC;
        int gp = Math.max(1, tu / 2);
        if (!alive) {
            for (int b = 0; b < nb; b++) {
                int bx0 = x0 + (int) (bS[b] * cw), bx1 = x0 + (int) (bE[b] * cw) - gp;
                if (bx0 >= hx) continue;
                boolean cut = bx1 > hx;
                if (cut) bx1 = hx;
                int top = bottom - (int) (height * (0.175f + 0.09f * bL[b]));
                if (broken || rew) {
                    if (h(frame, 100 + b) % 100 < rate / 2) top += (h(frame, 140 + b) % (tu * 4 + 1)) - tu * 2;
                    if (broken && h(frame, 180 + b) % 100 < rate / 3) continue;
                }
                g.fill(bx0, top, bx1, bottom, 0x1EFFFFFF);
                g.fill(bx0, top, bx1, top + 2, 0xFFD6DAE0);
                g.fill(bx0, top, bx0 + 2, bottom, 0xFFD6DAE0);
                if (!cut) g.fill(bx1 - 2, top, bx1, bottom, 0xFFD6DAE0);
            }
        }
        g.fill(hx, by, x1, by + 3, 0xFF4E545C);
        if (broken) {
            int seg = Math.max(1, (hx - x0) / 16);
            for (int k = 0; k < 16; k++) {
                if (h(frame, 80 + k) % 100 < rate / 2) continue;
                g.fill(x0 + k * seg, by, x0 + (k + 1) * seg, by + 3, 0xFFE8EAEE);
            }
        } else {
            g.fill(x0, by, hx, by + 3, alive ? 0xFF4E545C : 0xFFE8EAEE);
        }
        if (rew) {
            for (int k = 1; k <= 6; k++) {
                int a = Math.max(0, 0x90 - k * 0x16);
                g.fill(hx + k * tu * 2, by - tu * 4, hx + k * tu * 2 + tu, by + tu * 5, (a << 24) | ((k & 1) == 0 ? 0xFF2090 : 0x20E0FF));
            }
        }
        int hc = alive ? 0xFF8A9098 : 0xFFFFFFFF;
        if (t < T_BREAK) {
            for (int rr = -4; rr <= 4; rr++) {      // смотрит вправо
                int w = (5 - Math.abs(rr)) * tu;
                g.fill(hx - w, by + 1 + rr * tu - tu / 2, hx, by + 1 + (rr + 1) * tu - tu / 2, hc);
            }
            g.fill(hx, by, hx + tu, by + 3, hc);
        } else if (broken) {
            explode(g, t, headMax, by, tu);
        } else {
            for (int rr = -4; rr <= 4; rr++) {      // теперь смотрит влево
                int w = (5 - Math.abs(rr)) * tu;
                g.fill(hx, by + 1 + rr * tu - tu / 2, hx + w, by + 1 + (rr + 1) * tu - tu / 2, hc);
            }
            g.fill(hx - tu, by, hx, by + 3, hc);
            float rt = t - T_REW0;
            if (rt >= 0f && rt < 0.14f) outline(g, hx - tu * 4, by - tu * 6, hx + tu * 8, by + tu * 6, ((int) ((1f - rt / 0.14f) * 255) << 24) | 0xFFFFFF);
        }

        // ---- полосы трекинга при перемотке / сломе ----
        if (broken || rew) {
            int n = rate / 12;
            for (int i = 0; i < n; i++) {
                int yy = h(frame, 500 + i) % height;
                g.fill(0, yy, width, yy + 1 + h(frame, 520 + i) % (tu * 2), 0x30FFFFFF);
            }
        }

        // ---- DEAD END ----
        boolean de1 = t >= T_BREAK && t < T_FLASH - 0.02f;
        boolean de2 = t >= T_DE2 && t < T_VANISH + VANISH_LEN;
        if (de1) {
            float dt = t - T_BREAK;
            boolean vis = dt > 0.16f || h(frame, 90) % 100 < 35 + (int) (dt * 400f);
            if (rate > 45 && h(frame, 91) % 100 < rate / 4) vis = false;
            boolean resume = t >= T_REW0;
            if (Math.abs(t - T_REW0) < 0.12f) resume = h(frame, 96) % 2 == 0; // сбой при смене надписи
            if (vis) deadEnd(g, frame, rate, 3, rate / 5, 0.85f + 0.15f * Mth.sin(t * 40f), resume);
        } else if (de2) {
            float vt = Mth.clamp((t - T_VANISH) / VANISH_LEN, 0f, 1f);
            boolean blip = t - T_DE2 < 0.06f && h(frame, 92) % 100 < 50;
            boolean cutOut = vt > 0.85f && h(frame, 93) % 2 == 0;
            // в конце надпись «багается»: RESUME и DEAD END сменяют друг друга, иногда вместе
            float bug = Mth.clamp((t - (T_VANISH - 0.35f)) / (0.35f + VANISH_LEN), 0f, 1f);
            float gl = Math.max(vt, bug * 0.5f);
            boolean showDead = h(frame, 94) % 100 < (int) (bug * 60f);
            boolean both = bug > 0.4f && h(frame, 95) % 100 < 25;
            if (!blip && !cutOut) {
                int sp = gl > 0f ? 3 + (int) (97 * gl) : 3, am = 2 + (int) (gl * 16f), dr = (int) (gl * 85f);
                float al = 1f - vt * 0.4f;
                if (both) deadEnd(g, frame, sp, am, dr, al, false);
                deadEnd(g, frame, sp, am, dr, al, !showDead || both);
            }
            if (vt > 0f) {
                for (int i = 0; i < 12; i++) {
                    int bx = width / 2 + h(frame, 400 + i) % (width / 3) - width / 6;
                    int byy = height / 2 + h(frame, 420 + i) % (height / 5) - height / 10;
                    int c = h(frame, 440 + i) & 3;
                    g.fill(bx, byy, bx + tu + h(frame, 460 + i) % (tu * 8), byy + 1 + h(frame, 480 + i) % tu,
                            c == 0 ? 0xFFFFFFFF : c == 1 ? 0xFFE02030 : c == 2 ? 0xFF20E0FF : 0xFF000000);
                }
            }
        }
    }

    /** Головка взрывается: ударная волна и разлетающиеся пиксели. */
    private void explode(GuiGraphics g, float t, int cx, int cy, int tu) {
        float dt = t - T_BREAK;
        if (dt < 0.2f) {
            int rr = (int) (tu * 26 * dt / 0.2f) + tu;
            outline(g, cx - rr, cy - rr, cx + rr, cy + rr, ((int) ((1f - dt / 0.2f) * 255) << 24) | 0xFFFFFF);
        }
        if (dt >= 0.5f) return;
        float k = dt / 0.5f, e = 1f - (1f - k) * (1f - k);
        int sz = Math.max(1, Math.round(tu * (1f - k * 0.6f)));
        int al = (int) ((1f - k) * 255) << 24;
        for (int i = 0; i < 28; i++) {
            float ang = (h(i, 700) % 628) / 100f;
            float sp = tu * (8 + h(i, 710) % 40) * 0.5f;
            int x = cx + (int) (Mth.cos(ang) * sp * e * 2f);
            int y = cy + (int) (Mth.sin(ang) * sp * e * 2f + 14f * tu * k * k);
            int c = i % 3 == 0 ? 0x20E0FF : (i & 1) == 0 ? 0xFFFFFF : 0xE02030;
            g.fill(x, y, x + sz, y + sz, al | c);
        }
    }

    /** Постэффекты поверх: строки развёртки, снег, виньетка, блик стекла, надпись о смерти, вспышка. */
    private void overlay(GuiGraphics g, float t, int frame, int rate, float kick) {
        for (int y = 0; y < height; y += 2) g.fill(0, y, width, y + 1, 0x2A000000);
        int snow = 18 + Math.min(100, rate);
        for (int i = 0; i < snow; i++) {
            int hh = h(frame, i);
            int sx = hh % width, sy = h(frame, i + 999) % height;
            g.fill(sx, sy, sx + 1 + (hh >>> 9) % 3, sy + 1, 0x70FFFFFF);
        }
        for (int k = 0; k < 6; k++) {
            int a = 0x1C - k * 3;
            int e1 = (6 - k) * width / 70;
            g.fill(0, 0, e1, height, a << 24);
            g.fill(width - e1, 0, width, height, a << 24);
            int e2 = (6 - k) * height / 70;
            g.fill(0, 0, width, e2, a << 24);
            g.fill(0, height - e2, width, height, a << 24);
        }
        int sh = Math.max(1, height / 18);
        for (int i = 0; i < 18; i++) {
            int sx = (int) (width * 0.08f) + (18 - i) * width / 70;
            g.fill(sx, i * sh, sx + width / 12, (i + 1) * sh, 0x0AFFFFFF);
            g.fill(sx + width / 9, i * sh, sx + width / 9 + width / 40, (i + 1) * sh, 0x07FFFFFF);
        }
        if (kick > 0.05f && t < T_REW0) g.fill(0, 0, width, height, ((int) (kick * 0x40) << 24) | 0xFF1030);
        float fa = 0f;
        if (t >= T_FLASH - 0.25f && t < T_FLASH) {
            float p = (t - (T_FLASH - 0.25f)) / 0.25f;
            fa = 0.35f * p * p;
        } else if (t >= T_FLASH) {
            float x = Mth.clamp((t - T_FLASH) / 0.85f, 0f, 1f);
            fa = x < 0.06f ? 1f : (float) Math.pow(1f - x, 2.2);
        }
        if (fa > 0.003f) g.fill(0, 0, width, height, ((int) (fa * 255) << 24) | 0xFFFFFF);
        if (t > T_DARK) g.fill(0, 0, width, height, (int) (Mth.clamp((t - T_DARK) / 0.18f, 0f, 1f) * 255) << 24);
        if (ticks >= SKIP_AFTER && t < T_VANISH) {
            g.drawString(font, skip, width - font.width(skip) - 12, height - 16, 0xFF70757C, false);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0 && ticks >= SKIP_AFTER && fadeStart < 0) {
            respawn();
            return true;
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
