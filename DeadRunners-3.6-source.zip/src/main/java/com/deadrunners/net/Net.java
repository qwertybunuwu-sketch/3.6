package com.deadrunners.net;

import com.deadrunners.DeadRunnersMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class Net {
    private static final String PROTOCOL = "4";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DeadRunnersMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {}

    public static void register() {
        CHANNEL.registerMessage(0, ActionPacket.class,
                ActionPacket::encode, ActionPacket::decode, ActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(1, ThunderCdPacket.class,
                ThunderCdPacket::encode, ThunderCdPacket::decode, ThunderCdPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(2, ResetDashPacket.class,
                ResetDashPacket::encode, ResetDashPacket::decode, ResetDashPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(3, CheckpointSyncPacket.class,
                CheckpointSyncPacket::encode, CheckpointSyncPacket::decode, CheckpointSyncPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(4, SavingPacket.class,
                SavingPacket::encode, SavingPacket::decode, SavingPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(5, HookPacket.class,
                HookPacket::encode, HookPacket::decode, HookPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(6, HookFxPacket.class,
                HookFxPacket::encode, HookFxPacket::decode, HookFxPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(7, LifeSyncPacket.class,
                LifeSyncPacket::encode, LifeSyncPacket::decode, LifeSyncPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
}
