package com.deadrunners.entity;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.ModParticles;
import com.deadrunners.ModSounds;
import com.deadrunners.server.ServerHandler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Неподвижная «сфера ветра»: касание игрока сбрасывает перезарядку рывка. Через 3 с появляется снова. ПКМ деревянной лопатой убивает навсегда. */
public class WindDashEntity extends Entity {
    private static final EntityDataAccessor<Boolean> ACTIVE =
            SynchedEntityData.defineId(WindDashEntity.class, EntityDataSerializers.BOOLEAN);
    /** Через сколько тиков сфера возвращается (3 секунды). */
    private static final int RESPAWN_TICKS = 60;
    private int respawn;

    public WindDashEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public boolean isActive() {
        return this.entityData.get(ACTIVE);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(ACTIVE, true);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        if (!isActive()) {
            if (--this.respawn <= 0) this.entityData.set(ACTIVE, true);
            return;
        }
        // раз в 2 тика и только по крошечной области
        if ((this.tickCount & 1) != 0 || !DeadRunnersConfig.serverReady()) return;
        for (ServerPlayer p : this.level().getEntitiesOfClass(ServerPlayer.class, this.getBoundingBox().inflate(0.6))) {
            if (p.isSpectator() || !onTouch(p)) continue;
            this.entityData.set(ACTIVE, false);
            this.respawn = respawnTicks();
            touchFx((ServerLevel) this.level());
            break;
        }
    }

    /** Игрок коснулся сферы. true - сфера «выпита» и уйдёт на перезарядку. */
    protected boolean onTouch(ServerPlayer p) {
        ServerHandler.refreshDash(p);
        return true;
    }

    protected int respawnTicks() {
        return RESPAWN_TICKS;
    }

    protected void touchFx(ServerLevel sl) {
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.READY.get(), SoundSource.PLAYERS, 1.0f, 1.3f);
        sl.sendParticles(ModParticles.DASH_CLOUD.get(), getX(), getY() + 0.3, getZ(), 10, 0.3, 0.3, 0.3, 0.05);
    }

    /** Для прицела сфера «твёрдая» только когда в руке деревянная лопата (иначе не мешает строить). */
    @Override
    public boolean isPickable() {
        return this.level().isClientSide && com.deadrunners.client.ClientPick.holdingWoodenShovel();
    }

    /** ПКМ деревянной лопатой: убить насовсем (как /kill), без возврата. */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!player.getItemInHand(hand).is(Items.WOODEN_SHOVEL)) return InteractionResult.PASS;
        if (!this.level().isClientSide) {
            ServerLevel sl = (ServerLevel) this.level();
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.READY.get(), SoundSource.PLAYERS, 1.0f, 0.7f);
            sl.sendParticles(ModParticles.DASH_CLOUD.get(), getX(), getY() + 0.3, getZ(), 10, 0.3, 0.3, 0.3, 0.05);
            this.kill();
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}
}
