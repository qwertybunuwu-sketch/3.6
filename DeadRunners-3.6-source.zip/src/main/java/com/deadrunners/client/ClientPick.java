package com.deadrunners.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Items;

/** Клиентская проверка для выбора сферы прицелом (без аллокаций). */
public final class ClientPick {
    private ClientPick() {}

    public static boolean holdingWoodenShovel() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && mc.player.getMainHandItem().is(Items.WOODEN_SHOVEL);
    }
}
