package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.HudStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

/** Лёгкий экран клиентских настроек (мод-меню): вкладки HUD / Цвета / Эффекты / Звуки / Частицы / QoL. */
public class ModSettingsScreen extends Screen {
    private static final String[] TABS = {"hud", "colors", "effects", "sounds", "particles", "qol"};
    private static int tab = 0;

    private final Screen parent;
    private int row;
    private final java.util.List<Object[]> colorLabels = new java.util.ArrayList<>();

    public ModSettingsScreen(Screen parent) {
        super(Component.translatable("deadrunners.cfg.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int tw = 60;
        int x0 = this.width / 2 - (TABS.length * tw) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.translatable("deadrunners.cfg.tab." + TABS[i]), btn -> {
                tab = idx;
                this.rebuildWidgets();
            }).bounds(x0 + i * tw, 26, tw - 2, 20).build();
            b.active = i != tab;
            addRenderableWidget(b);
        }
        row = 0;
        colorLabels.clear();
        DeadRunnersConfig.Client c = DeadRunnersConfig.CLIENT;
        switch (tab) {
            case 0 -> {
                bool("hud.on", c.hudEnabled);
                style("hud.style", c.hudStyle);
                intSlider("hud.size", c.hudSize, 8, 12);
                intSlider("hud.y", c.hudYOffset, 0, 64);
                dbl("hud.opacity", c.hudOpacity, 0.1, 1.0);
                intSlider("hud.fade", c.hudFadeTicks, 1, 40);
                intSlider("hud.barw", c.hudBarWidth, 12, 64);
                intSlider("hud.barh", c.hudBarHeight, 3, 10);
                bool("hud.hearts", c.healthEnabled);
                bool("hud.hunger", c.hideHungerBar);
                bool("hud.crosshair", c.customCrosshair);
            }
            case 1 -> {
                bool("col.blind", c.colorblindMode);
                colorBox("col.dash", c.dashColor, 0);
                colorBox("col.thunder_top", c.thunderColorTop, 1);
                colorBox("col.thunder_bot", c.thunderColorBottom, 2);
                colorBox("col.hook", c.hookColor, 3);
            }
            case 2 -> {
                bool("fx.dash", c.dashEffectEnabled);
                dbl("fx.opacity", c.dashEffectOpacity, 0.05, 1.0);
                dbl("fx.fov", c.dashFovBoost, 0.0, 0.5);
                dbl("fx.mantle", c.mantleCameraDip, 0.0, 10.0);
                dbl("fx.hookshake", c.hookShake, 0.0, 2.0);
            }
            case 3 -> {
                dbl("snd.dashv", c.dashVolume, 0.0, 2.0);
                dbl("snd.dashp", c.dashPitch, 0.5, 2.0);
                dbl("snd.bouncev", c.bounceVolume, 0.0, 2.0);
                dbl("snd.bouncep", c.bouncePitch, 0.5, 2.0);
                dbl("snd.jumpv", c.jumpVolume, 0.0, 2.0);
                dbl("snd.jumpp", c.jumpPitch, 0.5, 2.0);
                dbl("snd.readyv", c.readyVolume, 0.0, 2.0);
                dbl("snd.readyp", c.readyPitch, 0.5, 2.0);
            }
            case 4 -> {
                bool("part.on", c.particlesEnabled);
                intSlider("part.count", c.particleCount, 0, 8);
                dbl("part.size", c.particleSize, 0.03, 0.5);
                intSlider("part.life", c.particleLifetime, 4, 60);
            }
            default -> {
                intSlider("qol.buffer", c.dashBufferTicks, 0, 20);
                bool("qol.ready", c.readySoundEnabled);
                bool("qol.saving", c.savingIndicator);
            }
        }
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(this.width / 2 - 100, this.height - 27, 200, 20).build());
    }

    private void colorBox(String key, ForgeConfigSpec.ConfigValue<String> v, int idx) {
        int y = 84 + idx * 26;
        int x = this.width / 2 + 5;
        net.minecraft.client.gui.components.EditBox eb = new net.minecraft.client.gui.components.EditBox(
                this.font, x, y, 80, 20, label(key));
        eb.setMaxLength(7);
        eb.setFilter(t -> t.matches("#?[0-9A-Fa-f]{0,6}"));
        eb.setValue(v.get());
        eb.setResponder(t -> {
            if (HudColors.valid(t)) {
                v.set((t.startsWith("#") ? t : "#" + t).toUpperCase());
                eb.setTextColor(0xFFFFFF);
            } else {
                eb.setTextColor(0xFF5555);
            }
        });
        addRenderableWidget(eb);
        colorLabels.add(new Object[]{key, y, v});
    }

    private int nextX() {
        return this.width / 2 - 155 + (row % 2) * 160;
    }

    private int nextY() {
        return 56 + (row / 2) * 24;
    }

    private static MutableComponent label(String key) {
        return Component.translatable("deadrunners.cfg." + key);
    }

    private void bool(String key, ForgeConfigSpec.BooleanValue v) {
        Button b = Button.builder(boolText(key, v.get()), btn -> {
            v.set(!v.get());
            btn.setMessage(boolText(key, v.get()));
        }).bounds(nextX(), nextY(), 150, 20).build();
        addRenderableWidget(b);
        row++;
    }

    private static Component boolText(String key, boolean on) {
        return label(key).append(": ").append(on ? CommonComponents.OPTION_ON : CommonComponents.OPTION_OFF);
    }

    private void style(String key, ForgeConfigSpec.EnumValue<HudStyle> v) {
        Button b = Button.builder(label(key).append(": " + v.get().name()), btn -> {
            HudStyle[] all = HudStyle.values();
            v.set(all[(v.get().ordinal() + 1) % all.length]);
            btn.setMessage(label(key).append(": " + v.get().name()));
        }).bounds(nextX(), nextY(), 150, 20).build();
        addRenderableWidget(b);
        row++;
    }

    private void intSlider(String key, ForgeConfigSpec.IntValue v, int min, int max) {
        addRenderableWidget(new Slider(nextX(), nextY(), key, min, max, true, v::get, d -> v.set((int) Math.round(d))));
        row++;
    }

    private void dbl(String key, ForgeConfigSpec.DoubleValue v, double min, double max) {
        addRenderableWidget(new Slider(nextX(), nextY(), key, min, max, false, v::get,
                d -> v.set(Math.round(d * 100.0) / 100.0)));
        row++;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFF);
        super.render(g, mx, my, pt);
        for (Object[] e : colorLabels) {
            int y = (int) e[1];
            g.drawString(this.font, label((String) e[0]), this.width / 2 - 155, y + 6, 0xFFFFFF);
            @SuppressWarnings("unchecked")
            String hex = ((ForgeConfigSpec.ConfigValue<String>) e[2]).get();
            if (HudColors.valid(hex)) {
                int rgb = Integer.parseInt(hex.startsWith("#") ? hex.substring(1) : hex, 16);
                int sx = this.width / 2 + 90;
                g.fill(sx - 1, y - 1, sx + 21, y + 21, 0xFFFFFFFF);
                g.fill(sx, y, sx + 20, y + 20, 0xFF000000 | rgb);
            }
        }
    }

    @Override
    public void onClose() {
        DeadRunnersConfig.CLIENT_SPEC.save();
        if (this.minecraft != null) this.minecraft.setScreen(parent);
    }

    private static final class Slider extends AbstractSliderButton {
        private final String key;
        private final double min;
        private final double max;
        private final boolean integer;
        private final DoubleConsumer setter;

        Slider(int x, int y, String key, double min, double max, boolean integer, DoubleSupplier getter, DoubleConsumer setter) {
            super(x, y, 150, 20, Component.empty(), Mth.clamp((getter.getAsDouble() - min) / (max - min), 0.0, 1.0));
            this.key = key;
            this.min = min;
            this.max = max;
            this.integer = integer;
            this.setter = setter;
            updateMessage();
        }

        private double current() {
            double d = min + this.value * (max - min);
            return integer ? Math.round(d) : Math.round(d * 100.0) / 100.0;
        }

        @Override
        protected void updateMessage() {
            double d = current();
            setMessage(label(key).append(": " + (integer ? String.valueOf((int) d) : String.valueOf(d))));
        }

        @Override
        protected void applyValue() {
            setter.accept(current());
        }
    }
}
