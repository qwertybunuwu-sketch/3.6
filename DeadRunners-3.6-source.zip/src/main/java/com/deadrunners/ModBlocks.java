package com.deadrunners;

import com.deadrunners.block.CheckpointStarBlock;
import com.deadrunners.block.SpaceMarkBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, DeadRunnersMod.MODID);

    public static final RegistryObject<Block> CHECKPOINT_STAR = BLOCKS.register("checkpoint_star",
            () -> new CheckpointStarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.GOLD)
                    .noCollission().noOcclusion().strength(-1.0f, 3600000.0f).lightLevel(s -> 10)));

    public static final RegistryObject<Block> SPACE_MARK = BLOCKS.register("space_mark",
            () -> new SpaceMarkBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .noCollission().noOcclusion().strength(-1.0f, 3600000.0f).lightLevel(s -> 8)));

    private ModBlocks() {}
}
