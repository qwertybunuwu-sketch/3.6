package com.deadrunners;

import com.deadrunners.block.CheckpointStarBlockEntity;
import com.deadrunners.block.SpaceMarkBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, DeadRunnersMod.MODID);

    public static final RegistryObject<BlockEntityType<CheckpointStarBlockEntity>> CHECKPOINT_STAR =
            BLOCK_ENTITIES.register("checkpoint_star", () -> BlockEntityType.Builder
                    .of(CheckpointStarBlockEntity::new, ModBlocks.CHECKPOINT_STAR.get()).build(null));

    public static final RegistryObject<BlockEntityType<SpaceMarkBlockEntity>> SPACE_MARK =
            BLOCK_ENTITIES.register("space_mark", () -> BlockEntityType.Builder
                    .of(SpaceMarkBlockEntity::new, ModBlocks.SPACE_MARK.get()).build(null));

    private ModBlockEntities() {}
}
