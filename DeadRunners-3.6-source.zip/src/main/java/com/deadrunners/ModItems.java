package com.deadrunners;

import com.deadrunners.item.LifeEssenceEggItem;
import com.deadrunners.item.WindDashEggItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DeadRunnersMod.MODID);

    public static final RegistryObject<Item> WIND_DASH_EGG = ITEMS.register("wind_dash_spawn_egg",
            () -> new WindDashEggItem(new Item.Properties()));

    public static final RegistryObject<Item> LIFE_ESSENCE_EGG = ITEMS.register("life_essence_spawn_egg",
            () -> new LifeEssenceEggItem(new Item.Properties()));

    public static final RegistryObject<Item> CHECKPOINT_STAR = ITEMS.register("checkpoint_star",
            () -> new BlockItem(ModBlocks.CHECKPOINT_STAR.get(), new Item.Properties()));

    public static final RegistryObject<Item> SPACE_MARK = ITEMS.register("space_mark",
            () -> new BlockItem(ModBlocks.SPACE_MARK.get(), new Item.Properties()));

    private ModItems() {}
}
