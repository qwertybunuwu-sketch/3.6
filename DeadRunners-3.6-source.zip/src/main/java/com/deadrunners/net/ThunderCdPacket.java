package com.deadrunners.net;

import com.deadrunners.client.ClientEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: Гром сработал, запустить отображение перезарядки. */
public record ThunderCdPacket(int ticks) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(ticks);
    }

    public static ThunderCdPacket decode(FriendlyByteBuf buf) {
        return new ThunderCdPacket(buf.readVarInt());
    }

    public static void handle(ThunderCdPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientEvents.startThunderCooldown(packet.ticks())));
        ctx.setPacketHandled(true);
    }
}
