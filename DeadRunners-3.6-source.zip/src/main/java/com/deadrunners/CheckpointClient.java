package com.deadrunners;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Клиентская копия «какая звезда сейчас активна» (приходит пакетом, без запросов). */
public final class CheckpointClient {
    private static ResourceKey<Level> dim;
    private static BlockPos star;

    private CheckpointClient() {}

    public static void set(ResourceKey<Level> d, BlockPos p) {
        dim = d;
        star = p;
    }

    public static void clear() {
        dim = null;
        star = null;
    }

    public static boolean isActive(ResourceKey<Level> d, BlockPos p) {
        return star != null && star.equals(p) && d == dim;
    }
}
