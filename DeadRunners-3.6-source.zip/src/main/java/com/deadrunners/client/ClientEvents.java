package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.DeadRunnersMod;
import com.deadrunners.ModParticles;
import com.deadrunners.HudStyle;
import com.deadrunners.ModSounds;
import com.deadrunners.net.ActionPacket;
import com.deadrunners.net.Net;
import com.mojang.math.Axis;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Клиентская логика: рывок, двойной прыжок, перезарядка и HUD. */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    // --- перезарядка / HUD ---
    private static int cooldownLeft;
    private static int cooldownTotal;
    private static int fadeLeft;
    private static int fadeTotal;

    // --- рывок ---
    private static boolean dashing;
    private static Vec3 dir = Vec3.ZERO;
    private static Vec3 lastVel = Vec3.ZERO;
    private static Vec3 prevPos = Vec3.ZERO;
    private static double remaining;
    private static double rise;
    private static int ticksLeft;
    private static int bounces;
    /** Хвост рывка: пока действует неуязвимость, удар о стену даёт минимальный отскок. */
    private static final int POST_TICKS = 4;
    private static final double POST_BOUNCE = 0.15;
    private static int postTicks;
    private static Vec3 postVel = Vec3.ZERO;

    // --- мёд: скольжение вдоль стены ---
    private static boolean sliding;
    private static int slideTicks;
    private static Vec3 slideDir = Vec3.ZERO;
    private static Vec3 wallOut = Vec3.ZERO;

    // --- двойной прыжок ---
    private static boolean airJumpUsed;
    private static boolean jumpArmed;
    private static boolean wasJumpDown;

    // --- QoL ---
    private static boolean dashBuffered;
    /** Рывок начат с земли: в пол не отскакиваем. */
    private static boolean noFloorBounce;

    // --- взбирание на уступ ---
    private static final int MANTLE_ANIM_TICKS = 10;
    private static boolean mantling;
    private static int mantleTick;
    private static double mantleRise;
    private static Vec3 mantleDir = Vec3.ZERO;
    private static int mantleCooldown;
    private static int mantleAnim;

    // --- полоска здоровья ---
    private static float hpShown = -1.0f;
    private static float hpPrevShown;
    private static float hpTrail;
    private static float hpPrevTrail;
    private static float hpLast = -1.0f;
    private static int hpTrailDelay;
    private static int hpFlash;
    private static int hpNumber = -1;
    private static String hpNumberText = "";

    // --- перезарядка Грома ---
    private static int thunderLeft;
    private static int thunderTotal;
    private static int thunderFade;

    // --- эффект рывка ---
    private static float effect;
    private static float prevEffect;
    private static int clientTicks;

    private ClientEvents() {}

    public static boolean isDashing() {
        return dashing;
    }

    /** Крюк запущен: взбирание отменяется, идущий рывок мгновенно обрывается. */
    public static void hookBegin(LocalPlayer p) {
        mantling = false;
        dashBuffered = false;
        postTicks = 0;
        sliding = false;
        if (dashing) {
            dashing = false;
            p.setDeltaMovement(p.getDeltaMovement().scale(0.3));
            p.fallDistance = 0;
        }
    }

    /** Крюк долетел: рывок и двойной прыжок возвращаются мгновенно. */
    public static void hookRestore() {
        if (cooldownLeft > 0) resetDashCooldown();
        airJumpUsed = false;
        jumpArmed = false;
    }

    private static void resetAll() {
        dashing = false;
        sliding = false;
        postTicks = 0;
        cooldownLeft = 0;
        cooldownTotal = 0;
        fadeLeft = 0;
        dashBuffered = false;
        mantling = false;
        mantleCooldown = 0;
        mantleAnim = 0;
        effect = 0;
        prevEffect = 0;
        airJumpUsed = false;
        jumpArmed = false;
        wasJumpDown = false;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !DeadRunnersConfig.serverReady()) {
            resetAll();
            return;
        }
        if (mc.isPaused()) return;

        if (event.phase == TickEvent.Phase.START) {
            // Перед тиком игрока задаём скорость рывка: гравитация и трение не успевают на неё повлиять.
            if (dashing) applyDashVelocity(p);
            else if (mantling) applyMantleVelocity(p);
            else if (postTicks > 0) postVel = p.getDeltaMovement();
            return;
        }

        if (dashing) afterDashMove(mc, p);
        else if (mantling) {
            postTicks = 0;
            afterMantle(p);
        } else if (postTicks > 0) afterPost(mc, p);
        handleDashKey(mc, p);
        if (!dashing && !mantling && !HookClient.active()) tryStartMantle(mc, p);
        if (!dashing && !mantling && !HookClient.active()) handleDoubleJump(mc, p);
        tickCooldown();
        if (mantleCooldown > 0) mantleCooldown--;
        if (mantleAnim > 0) mantleAnim--;
        updateEffect();
        clientTicks++;
    }

    /** Плавные значения для полоски здоровья: основная заливка и отстающий «след» урона. */
    @SubscribeEvent
    public static void onHealthTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) {
            hpShown = -1.0f;
            hpLast = -1.0f;
            thunderLeft = 0;
            thunderFade = 0;
            LifeClient.reset();
            return;
        }
        if (!Minecraft.getInstance().isPaused()) {
            LifeClient.tick();
            if (thunderLeft > 0) {
                if (--thunderLeft == 0) thunderFade = 12;
            } else if (thunderFade > 0) {
                thunderFade--;
            }
        }
        float hp = p.getHealth();
        if (hpShown < 0.0f || hpLast < 0.0f) {
            hpShown = hpTrail = hpPrevShown = hpPrevTrail = hpLast = hp;
            return;
        }
        hpPrevShown = hpShown;
        hpPrevTrail = hpTrail;
        if (hp < hpLast - 0.01f) {
            hpFlash = 8;
            hpTrailDelay = 14;
        }
        hpLast = hp;
        hpShown += (hp - hpShown) * 0.4f;
        if (Math.abs(hp - hpShown) < 0.02f) hpShown = hp;
        if (hpTrail <= hp) {
            hpTrail = hp;
        } else if (hpTrailDelay > 0) {
            hpTrailDelay--;
        } else {
            hpTrail += (hp - hpTrail) * 0.12f;
            if (hpTrail - hp < 0.02f) hpTrail = hp;
        }
        if (hpFlash > 0) hpFlash--;
    }

    /** Во время рывка игрок не управляет движением и не может обычно прыгнуть. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!dashing && !mantling) return;
        Input in = event.getInput();
        in.forwardImpulse = 0;
        in.leftImpulse = 0;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
    }

    // ------------------------------------------------------------------ рывок

    private static boolean canDash(LocalPlayer p) {
        return DeadRunnersConfig.SERVER.dashEnabled.get() && !dashing && !HookClient.active() && cooldownLeft <= 0
                && p.isAlive() && !p.isSpectator() && !p.isPassenger()
                && !p.isFallFlying() && !p.getAbilities().flying;
    }

    private static void handleDashKey(Minecraft mc, LocalPlayer p) {
        KeyMapping key = ClientModEvents.DASH_KEY;
        if (mc.screen != null) {
            while (key.consumeClick()) { /* сбрасываем накопленные нажатия */ }
            dashBuffered = false;
            return;
        }
        // нажатие, сделанное чуть раньше конца перезарядки, срабатывает автоматически
        if (dashBuffered && canDash(p)) {
            dashBuffered = false;
            startDash(mc, p);
            return;
        }
        while (key.consumeClick()) {
            if (canDash(p)) {
                dashBuffered = false;
                startDash(mc, p);
            } else if (!dashing && cooldownLeft > 0
                    && cooldownLeft <= DeadRunnersConfig.CLIENT.dashBufferTicks.get()) {
                dashBuffered = true;
            }
        }
    }

    private static void startDash(Minecraft mc, LocalPlayer p) {
        Vec3 look = p.getLookAngle();
        if (look.lengthSqr() < 1.0E-6) return;
        dir = look.normalize();
        noFloorBounce = p.onGround();
        if (noFloorBounce && dir.y < 0) {
            // С земли взгляд вниз не отправляет рывок в пол: рывок идёт вперёд по горизонтали
            Vec3 flat = new Vec3(look.x, 0, look.z);
            dir = flat.lengthSqr() > 1.0E-6 ? flat.normalize() : Vec3.directionFromRotation(0, p.getYRot());
        }
        dashing = true;
        mantling = false;
        postTicks = 0;
        remaining = noFloorBounce ? DeadRunnersConfig.SERVER.dashDistance.get()
                : DeadRunnersConfig.SERVER.dashAirDistance.get();
        rise = 0.0;
        ticksLeft = DeadRunnersConfig.SERVER.dashDuration.get();
        bounces = 0;
        sliding = false;
        lastVel = Vec3.ZERO;
        prevPos = p.position();
        cooldownTotal = DeadRunnersConfig.SERVER.dashCooldown.get();
        cooldownLeft = cooldownTotal;
        fadeLeft = 0;

        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.DASH));
        var c = DeadRunnersConfig.CLIENT;
        playConfigured(p, c.dashSound.get(), c.dashVolume.get(), c.dashPitch.get(), ModSounds.DASH.get());
        puff(mc.level, p.getX(), p.getY() + p.getBbHeight() * 0.5, p.getZ(), 6, 0.25);
    }

    private static void applyDashVelocity(LocalPlayer p) {
        if (sliding) {
            double ss = DeadRunnersConfig.SERVER.honeySlideSpeed.get();
            prevPos = p.position();
            lastVel = new Vec3(slideDir.x * ss, 0.0, slideDir.z * ss);
            p.setDeltaMovement(lastVel);
            p.fallDistance = 0;
            return;
        }
        double speed = DeadRunnersConfig.SERVER.dashSpeed.get();
        // Плавный профиль: резкий, но не мгновенный разгон, и мягкое торможение в конце
        int elapsed = DeadRunnersConfig.SERVER.dashDuration.get() - ticksLeft;
        double accel = switch (Math.max(elapsed, 0)) {
            case 0 -> 0.6;
            case 1 -> 0.85;
            case 2 -> 1.05;
            default -> 1.15;
        };
        double ease = remaining < 1.0 ? Math.max(0.6, remaining) : 1.0;
        double step = Math.min(speed * accel * ease, Math.max(remaining, 0.0));
        prevPos = p.position();
        lastVel = scaleUp(dir.scale(step));
        if (lastVel.y > 0) {
            // потолок суммарного подъёма за рывок
            double room = Math.max(DeadRunnersConfig.SERVER.dashMaxRise.get() - rise, 0.0);
            double vy = Math.min(lastVel.y, room);
            rise += vy;
            lastVel = new Vec3(lastVel.x, vy, lastVel.z);
        }
        p.setDeltaMovement(lastVel);
        p.fallDistance = 0;
    }

    private static void afterDashMove(Minecraft mc, LocalPlayer p) {
        Vec3 now = p.position();
        spawnTrail(mc.level, p, prevPos, now);
        if (sliding) {
            slideTick(mc, p);
            return;
        }
        remaining -= now.subtract(prevPos).length();
        ticksLeft--;

        var cfg = DeadRunnersConfig.SERVER;
        Vec3 dm = p.getDeltaMovement();
        Vec3 v = lastVel;
        // Столкновение обнуляет соответствующую компоненту скорости
        boolean bx = p.horizontalCollision && Math.abs(v.x) > 0.02 && Math.abs(dm.x) < 1.0E-4;
        boolean bz = p.horizontalCollision && Math.abs(v.z) > 0.02 && Math.abs(dm.z) < 1.0E-4;
        boolean by = p.verticalCollision && Math.abs(v.y) > 0.02;
        if (noFloorBounce && v.y < 0) by = false;

        if (bx || bz || by) {
            int surface = surfaceKind(p, bx, by, bz, v);
            if (surface == SURF_HONEY && (bx || bz) && cfg.honeySlideEnabled.get() && startSlide(mc, p, bx, bz, v)) {
                return;
            }
            if (cfg.bounceEnabled.get() && bounces < cfg.maxBounces.get()) {
                dir = new Vec3(bx ? -dir.x : dir.x, by ? -dir.y : dir.y, bz ? -dir.z : dir.z);
                bounces++;
                remaining *= cfg.bounceRetention.get();
                if (surface == SURF_SLIME) {
                    // слизень: отскок сильнее (дальше и дольше), двойной прыжок возвращается всегда
                    double mult = cfg.slimeBounceMultiplier.get();
                    remaining *= mult;
                    ticksLeft = (int) Math.ceil(ticksLeft * mult);
                    airJumpUsed = false;
                    jumpArmed = false;
                    Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.SLIME));
                }
                if (cfg.bounceRestoresJump.get()) {
                    // отскок возвращает двойной прыжок
                    airJumpUsed = false;
                    jumpArmed = false;
                }
                Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.BOUNCE));
                var c = DeadRunnersConfig.CLIENT;
                playConfigured(p, c.bounceSound.get(), c.bounceVolume.get(), c.bouncePitch.get(), ModSounds.BOUNCE.get());
                puff(mc.level, p.getX(), p.getY() + p.getBbHeight() * 0.5, p.getZ(), 5, 0.2);
            } else {
                endDash(p);
                // рывок кончился о препятствие: минимальный отскок, пока действует неуязвимость
                Vec3 cur = p.getDeltaMovement();
                p.setDeltaMovement(
                        bx ? -Math.signum(dir.x) * POST_BOUNCE : cur.x,
                        by ? -Math.signum(dir.y) * POST_BOUNCE : cur.y,
                        bz ? -Math.signum(dir.z) * POST_BOUNCE : cur.z);
                postTicks = 0;
                Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.BOUNCE));
                var c = DeadRunnersConfig.CLIENT;
                playConfigured(p, c.bounceSound.get(), c.bounceVolume.get(), c.bouncePitch.get(), ModSounds.BOUNCE.get());
                return;
            }
        }

        if (ticksLeft <= 0 || remaining <= 0.05 || !p.isAlive() || p.isPassenger()) {
            endDash(p);
        }
    }


    // ------------------------------------------------- слизень и мёд

    private static final int SURF_NONE = 0;
    private static final int SURF_SLIME = 1;
    private static final int SURF_HONEY = 2;

    /** Какой блок остановил рывок: ищем слизень или мёд сразу за гранью столкновения (без аллокаций). */
    private static int surfaceKind(LocalPlayer p, boolean bx, boolean by, boolean bz, Vec3 v) {
        var bb = p.getBoundingBox();
        double ex = bx ? Math.signum(v.x) * 0.15 : 0.0;
        double ey = by ? Math.signum(v.y) * 0.15 : 0.0;
        double ez = bz ? Math.signum(v.z) * 0.15 : 0.0;
        double minX = bb.minX + Math.min(ex, 0), maxX = bb.maxX + Math.max(ex, 0);
        double minY = bb.minY + Math.min(ey, 0), maxY = bb.maxY + Math.max(ey, 0);
        double minZ = bb.minZ + Math.min(ez, 0), maxZ = bb.maxZ + Math.max(ez, 0);
        var level = p.level();
        var pos = new net.minecraft.core.BlockPos.MutableBlockPos();
        int found = SURF_NONE;
        for (int x = Mth.floor(minX); x <= Mth.floor(maxX); x++) {
            for (int y = Mth.floor(minY); y <= Mth.floor(maxY); y++) {
                for (int z = Mth.floor(minZ); z <= Mth.floor(maxZ); z++) {
                    pos.set(x, y, z);
                    var st = level.getBlockState(pos);
                    if (st.is(net.minecraft.world.level.block.Blocks.HONEY_BLOCK)) return SURF_HONEY;
                    if (st.is(net.minecraft.world.level.block.Blocks.SLIME_BLOCK)) found = SURF_SLIME;
                }
            }
        }
        return found;
    }

    /** Рядом со стороной wallOut (противоположной направлению в стену) нет ли мёда: стена ещё продолжается. */
    private static boolean honeyBesideWall(LocalPlayer p) {
        var bb = p.getBoundingBox();
        double ex = -wallOut.x * 0.2;
        double ez = -wallOut.z * 0.2;
        double minX = bb.minX + Math.min(ex, 0), maxX = bb.maxX + Math.max(ex, 0);
        double minZ = bb.minZ + Math.min(ez, 0), maxZ = bb.maxZ + Math.max(ez, 0);
        var level = p.level();
        var pos = new net.minecraft.core.BlockPos.MutableBlockPos();
        for (int x = Mth.floor(minX); x <= Mth.floor(maxX); x++) {
            for (int y = Mth.floor(bb.minY); y <= Mth.floor(bb.maxY); y++) {
                for (int z = Mth.floor(minZ); z <= Mth.floor(maxZ); z++) {
                    pos.set(x, y, z);
                    if (level.getBlockState(pos).is(net.minecraft.world.level.block.Blocks.HONEY_BLOCK)) return true;
                }
            }
        }
        return false;
    }

    /** Рывок упёрся в мёд: скользим вдоль стены. false - направление не найдено, отскакиваем как обычно. */
    private static boolean startSlide(Minecraft mc, LocalPlayer p, boolean bx, boolean bz, Vec3 v) {
        boolean alongX = bx && (!bz || Math.abs(v.x) >= Math.abs(v.z));
        Vec3 out = alongX ? new Vec3(-Math.signum(v.x), 0, 0) : new Vec3(0, 0, -Math.signum(v.z));
        // горизонталь рывка без составляющей в стену, иначе взгляд, иначе боковая сторона по взгляду
        Vec3 h = alongX ? new Vec3(0, 0, dir.z) : new Vec3(dir.x, 0, 0);
        if (h.lengthSqr() < 0.04) {
            Vec3 look = p.getLookAngle();
            h = alongX ? new Vec3(0, 0, look.z) : new Vec3(look.x, 0, 0);
        }
        if (h.lengthSqr() < 0.01) {
            // в стену прямо в лоб и взгляд тоже: уходим вбок по повороту головы
            float yaw = p.getYRot() * ((float) Math.PI / 180.0f);
            double side = alongX ? -Mth.cos(yaw) : Mth.sin(yaw);
            if (Math.abs(side) < 0.05) return false;
            h = alongX ? new Vec3(0, 0, Math.signum(side)) : new Vec3(Math.signum(side), 0, 0);
        }
        slideDir = h.normalize();
        wallOut = out;
        sliding = true;
        slideTicks = 0;
        airJumpUsed = false;
        jumpArmed = false;
        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.SLIDE));
        var c = DeadRunnersConfig.CLIENT;
        playConfigured(p, c.bounceSound.get(), c.bounceVolume.get(), c.bouncePitch.get(), ModSounds.BOUNCE.get());
        puff(mc.level, p.getX(), p.getY() + p.getBbHeight() * 0.5, p.getZ(), 4, 0.2);
        return true;
    }

    private static void slideTick(Minecraft mc, LocalPlayer p) {
        slideTicks++;
        Vec3 dm = p.getDeltaMovement();
        boolean blocked = p.horizontalCollision && dm.horizontalDistanceSqr() < 0.0025;
        if (slideTicks >= DeadRunnersConfig.SERVER.honeySlideMaxTicks.get() || blocked
                || !p.isAlive() || p.isPassenger() || !honeyBesideWall(p)) {
            endSlide(mc, p);
        }
    }

    /** Конец стены: отскок туда, куда смотрит игрок (всегда от стены), рывок продолжается. */
    private static void endSlide(Minecraft mc, LocalPlayer p) {
        sliding = false;
        Vec3 look = p.getLookAngle();
        double into = look.dot(wallOut);
        if (into < 0.35) {
            // взгляд в стену или вдоль неё: добавляем выталкивание от стены
            look = look.subtract(wallOut.scale(into)).add(wallOut.scale(0.35));
        }
        dir = look.normalize();
        var cfg = DeadRunnersConfig.SERVER;
        remaining = cfg.dashAirDistance.get() * cfg.bounceRetention.get();
        ticksLeft = cfg.dashDuration.get();
        rise = 0.0;
        noFloorBounce = false;
        lastVel = Vec3.ZERO;
        prevPos = p.position();
        airJumpUsed = false;
        jumpArmed = false;
        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.SLIDE_END));
        var c = DeadRunnersConfig.CLIENT;
        playConfigured(p, c.bounceSound.get(), c.bounceVolume.get(), c.bouncePitch.get(), ModSounds.BOUNCE.get());
        puff(mc.level, p.getX(), p.getY() + p.getBbHeight() * 0.5, p.getZ(), 5, 0.2);
    }

    /** Хвост рывка (последние тики неуязвимости): удар о стену или потолок даёт минимальный отскок. */
    private static void afterPost(Minecraft mc, LocalPlayer p) {
        postTicks--;
        if (!p.isAlive() || p.isPassenger() || p.isFallFlying() || p.getAbilities().flying) {
            postTicks = 0;
            return;
        }
        Vec3 v = postVel;
        Vec3 dm = p.getDeltaMovement();
        boolean bx = p.horizontalCollision && Math.abs(v.x) > 0.05 && Math.abs(dm.x) < 1.0E-4;
        boolean bz = p.horizontalCollision && Math.abs(v.z) > 0.05 && Math.abs(dm.z) < 1.0E-4;
        boolean by = p.verticalCollision && v.y > 0.05 && !p.onGround();
        if (!bx && !bz && !by) return;
        p.setDeltaMovement(
                bx ? -Math.signum(v.x) * POST_BOUNCE : dm.x,
                by ? -POST_BOUNCE : dm.y,
                bz ? -Math.signum(v.z) * POST_BOUNCE : dm.z);
        p.fallDistance = 0;
        postTicks = 0;
        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.BOUNCE));
        var c = DeadRunnersConfig.CLIENT;
        playConfigured(p, c.bounceSound.get(), c.bounceVolume.get(), c.bouncePitch.get(), ModSounds.BOUNCE.get());
        puff(mc.level, p.getX(), p.getY() + p.getBbHeight() * 0.5, p.getZ(), 3, 0.15);
    }

    private static void endDash(LocalPlayer p) {
        dashing = false;
        postTicks = POST_TICKS;
        double keep = DeadRunnersConfig.SERVER.momentumKeep.get();
        double speed = DeadRunnersConfig.SERVER.dashSpeed.get();
        // Сохраняем часть импульса, дальше игрок падает по обычной физике
        Vec3 out = scaleUp(dir.scale(speed * keep));
        if (out.y > 0 && rise >= DeadRunnersConfig.SERVER.dashMaxRise.get() - 1.0E-3) {
            out = new Vec3(out.x, 0.0, out.z);
        }
        p.setDeltaMovement(out);
        p.fallDistance = 0;
    }

    private static void tickCooldown() {
        if (cooldownLeft > 0) {
            cooldownLeft--;
            if (cooldownLeft == 0) {
                fadeTotal = DeadRunnersConfig.CLIENT.hudFadeTicks.get();
                fadeLeft = fadeTotal;
                playReady();
            }
        } else if (fadeLeft > 0) {
            fadeLeft--;
        }
    }

    // ---------------------------------------------------------- двойной прыжок

    private static void handleDoubleJump(Minecraft mc, LocalPlayer p) {
        boolean down = mc.options.keyJump.isDown();
        boolean resets = p.onGround() || p.isInWater() || p.isInLava() || p.isSwimming()
                || p.onClimbable() || p.getAbilities().flying || p.isFallFlying()
                || p.isPassenger() || p.isSpectator();
        if (resets) {
            airJumpUsed = false;
            jumpArmed = false;
            wasJumpDown = down;
            return;
        }
        // «Взводим» прыжок только после отпускания пробела в воздухе,
        // чтобы само нажатие обычного прыжка не считалось двойным.
        if (!down) {
            jumpArmed = true;
        } else if (jumpArmed && !wasJumpDown && !airJumpUsed && mc.screen == null
                && DeadRunnersConfig.SERVER.doubleJumpEnabled.get() && p.isAlive()) {
            doubleJump(mc, p);
        }
        wasJumpDown = down;
    }

    private static void doubleJump(Minecraft mc, LocalPlayer p) {
        airJumpUsed = true;
        double y = DeadRunnersConfig.SERVER.doubleJumpStrength.get();
        MobEffectInstance boost = p.getEffect(MobEffects.JUMP);
        if (boost != null) y += 0.1 * (boost.getAmplifier() + 1);
        Vec3 dm = p.getDeltaMovement();
        p.setDeltaMovement(dm.x, y, dm.z);
        p.hasImpulse = true;
        if (DeadRunnersConfig.SERVER.doubleJumpResetsFall.get()) p.fallDistance = 0;

        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.DOUBLE_JUMP));
        var c = DeadRunnersConfig.CLIENT;
        playConfigured(p, c.jumpSound.get(), c.jumpVolume.get(), c.jumpPitch.get(), ModSounds.DOUBLE_JUMP.get());
        puff(mc.level, p.getX(), p.getY() + 0.1, p.getZ(), 8, 0.3);
    }

    // ----------------------------------------------------- частицы и звук

    private static void puff(ClientLevel level, double x, double y, double z, int count, double spread) {
        for (int i = 0; i < count; i++) {
            level.addParticle(ModParticles.DASH_CLOUD.get(),
                    x + (level.random.nextDouble() - 0.5) * 2 * spread,
                    y + (level.random.nextDouble() - 0.5) * spread,
                    z + (level.random.nextDouble() - 0.5) * 2 * spread,
                    0, 0, 0);
        }
    }

    private static void spawnTrail(ClientLevel level, LocalPlayer p, Vec3 from, Vec3 to) {
        int count = DeadRunnersConfig.CLIENT.particleCount.get();
        double cy = p.getBbHeight() * 0.5;
        for (int i = 0; i < count; i++) {
            double t = level.random.nextDouble();
            level.addParticle(ModParticles.DASH_CLOUD.get(),
                    Mth.lerp(t, from.x, to.x) + (level.random.nextDouble() - 0.5) * 0.3,
                    Mth.lerp(t, from.y, to.y) + cy + (level.random.nextDouble() - 0.5) * 0.4,
                    Mth.lerp(t, from.z, to.z) + (level.random.nextDouble() - 0.5) * 0.3,
                    0, 0, 0);
        }
    }

    private static final java.util.HashMap<String, SoundEvent> SOUND_CACHE = new java.util.HashMap<>();

    private static void playConfigured(LocalPlayer p, String id, double volume, double pitch, SoundEvent fallback) {
        SoundEvent sound = SOUND_CACHE.get(id);
        if (sound == null) {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl != null) sound = ForgeRegistries.SOUND_EVENTS.getValue(rl);
            if (sound != null) {
                if (SOUND_CACHE.size() > 32) SOUND_CACHE.clear();
                SOUND_CACHE.put(id, sound);
            }
        }
        if (sound == null) sound = fallback;
        p.level().playLocalSound(p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS,
                (float) volume, (float) pitch, false);
    }

    // ---------------------------------------------- нерф вверх, эффект, QoL

    // ------------------------------------------------ взбирание на уступ

    /**
     * Если игрок в воздухе упёрся в уступ, верх которого чуть выше ног (по умолчанию до 0.6 блока),
     * и держит «вперёд», он быстро подтягивается наверх.
     */
    private static void tryStartMantle(Minecraft mc, LocalPlayer p) {
        var cfg = DeadRunnersConfig.SERVER;
        if (!cfg.mantleEnabled.get() || mantleCooldown > 0 || mc.screen != null) return;
        if (p.onGround() || !p.horizontalCollision || !mc.options.keyUp.isDown()
                || p.isInWater() || p.isInLava() || p.onClimbable() || p.isFallFlying()
                || p.isPassenger() || p.isSpectator() || p.getAbilities().flying) {
            return;
        }
        Vec3 fwd = Vec3.directionFromRotation(0.0f, p.getYRot());
        double reach = cfg.mantleReach.get();
        var level = p.level();
        AABB ahead = p.getBoundingBox().move(fwd.x * 0.4, 0.0, fwd.z * 0.4);
        if (level.noCollision(p, ahead)) return; // впереди нет стены

        // ищем минимальную высоту, на которой впереди свободно (в рост игрока)
        double h = -1.0;
        for (double t = 0.1; t <= reach + 1.0E-6; t += 0.1) {
            if (level.noCollision(p, ahead.move(0.0, t, 0.0))) {
                h = t;
                break;
            }
        }
        if (h < 0.0) return; // уступ слишком высокий
        // над игроком должно быть место для подъёма
        if (!level.noCollision(p, p.getBoundingBox().move(0.0, h + 0.05, 0.0))) return;

        mantling = true;
        mantleTick = 0;
        mantleRise = h + 0.12;
        mantleDir = fwd;
        mantleAnim = MANTLE_ANIM_TICKS;
        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.MANTLE));
    }

    private static void applyMantleVelocity(LocalPlayer p) {
        int rise = DeadRunnersConfig.SERVER.mantleRiseTicks.get();
        if (mantleTick < rise) {
            // подъём вдоль стены
            p.setDeltaMovement(mantleDir.x * 0.02, mantleRise / rise, mantleDir.z * 0.02);
        } else {
            // выход на уступ вперёд
            p.setDeltaMovement(mantleDir.x * 0.32, 0.0, mantleDir.z * 0.32);
        }
        p.fallDistance = 0;
    }

    private static void afterMantle(LocalPlayer p) {
        int rise = DeadRunnersConfig.SERVER.mantleRiseTicks.get();
        mantleTick++;
        boolean blocked = mantleTick <= rise && p.verticalCollision; // упёрлись в потолок
        if (blocked || mantleTick >= rise + 2 || !p.isAlive() || p.isPassenger()) {
            mantling = false;
            mantleCooldown = blocked ? 10 : 6;
            p.fallDistance = 0;
        }
    }

    /** Лёгкая качка камеры вниз и обратно во время взбирания. */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (mantleAnim <= 0) return;
        double deg = DeadRunnersConfig.CLIENT.mantleCameraDip.get();
        if (deg <= 0.0) return;
        float progress = 1.0f - (float) ((mantleAnim - event.getPartialTick()) / MANTLE_ANIM_TICKS);
        progress = Mth.clamp(progress, 0.0f, 1.0f);
        event.setPitch(event.getPitch() + (float) (Math.sin(progress * Math.PI) * deg));
    }

    /** Голод отключён сервером: полоска голода не нужна. Свои сердца заменяют ванильные. */
    @SubscribeEvent
    public static void onOverlayPre(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() == VanillaGuiOverlay.PLAYER_HEALTH.type()
                && DeadRunnersConfig.CLIENT.healthEnabled.get()) {
            event.setCanceled(true);
            return;
        }
        if (event.getOverlay() == VanillaGuiOverlay.FOOD_LEVEL.type()
                && DeadRunnersConfig.serverReady()
                && DeadRunnersConfig.SERVER.disableHunger.get()
                && DeadRunnersConfig.CLIENT.hideHungerBar.get()) {
            event.setCanceled(true);
        }
    }

    /** Вертикальная часть рывка вверх ослаблена, чтобы он не превосходил два прыжка. */
    private static Vec3 scaleUp(Vec3 v) {
        if (v.y > 0) {
            // нерф вверх: слабее вертикаль, а под углом вверх ещё и горизонталь (пропорционально наклону)
            double len = v.length();
            double up = len > 1.0E-6 ? Mth.clamp(v.y / len, 0.0, 1.0) : 0.0;
            double h = 1.0 - (1.0 - DeadRunnersConfig.SERVER.dashUpHorizontalMultiplier.get()) * up;
            return new Vec3(v.x * h, v.y * DeadRunnersConfig.SERVER.dashUpMultiplier.get(), v.z * h);
        }
        if (v.y < 0) {
            return new Vec3(v.x, v.y * DeadRunnersConfig.SERVER.dashDownMultiplier.get(), v.z);
        }
        return v;
    }

    private static void playReady() {
        var c = DeadRunnersConfig.CLIENT;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null || !c.readySoundEnabled.get()) return;
        playConfigured(p, c.readySound.get(), c.readyVolume.get(), c.readyPitch.get(),
                ModSounds.READY.get());
    }

    private static void updateEffect() {
        prevEffect = effect;
        if (dashing) {
            effect = Math.min(1.0f, effect + 0.5f);
        } else {
            // медленное затухание: свечение по краям остаётся заметно дольше самого рывка
            effect = Math.max(0.0f, effect - 0.08f);
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        var c = DeadRunnersConfig.CLIENT;
        float boost = c.dashFovBoost.get().floatValue();
        if (boost <= 0.0f || !c.dashEffectEnabled.get()) return;
        float level = Mth.lerp(Minecraft.getInstance().getFrameTime(), prevEffect, effect);
        if (level <= 0.0f) return;
        event.setNewFovModifier(event.getNewFovModifier() * (1.0f + boost * level));
    }

    /** Мягкое белое свечение у краёв экрана во время рывка. */
    public static void renderEffect(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        var c = DeadRunnersConfig.CLIENT;
        if (!c.dashEffectEnabled.get()) return;
        float level = Mth.lerp(partialTick, prevEffect, effect);
        if (level <= 0.01f) return;

        float opacity = c.dashEffectOpacity.get().floatValue() * level;

        // Мягкое белое свечение у краёв экрана (центр остаётся чистым)
        int strips = 10;
        float depth = Math.max(20.0f, Math.min(width, height) * 0.15f);
        float strip = depth / strips;
        for (int i = 0; i < strips; i++) {
            float fall = 1.0f - (float) i / strips;
            int col = argb(opacity * 0.3f * fall * fall, 255, 255, 255);
            if ((col >>> 24) == 0) break; // дальше только ещё прозрачнее
            int a0 = Math.round(i * strip);
            int a1 = Math.round((i + 1) * strip);
            g.fill(0, a0, width, a1, col);
            g.fill(0, height - a1, width, height - a0, col);
            g.fill(a0, 0, a1, height, col);
            g.fill(width - a1, 0, width - a0, height, col);
        }
    }

    // ------------------------------------------------------------------- HUD

    public static void renderHud(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        var c = DeadRunnersConfig.CLIENT;
        if (!c.hudEnabled.get() || !DeadRunnersConfig.serverReady() || cooldownTotal <= 0) return;

        float alpha;
        float progress;
        if (cooldownLeft > 0) {
            alpha = 1.0f;
            progress = 1.0f - (cooldownLeft - partialTick) / (float) cooldownTotal;
        } else if (fadeLeft > 0 && fadeTotal > 0) {
            alpha = (fadeLeft - partialTick) / (float) fadeTotal;
            progress = 1.0f;
        } else {
            return;
        }
        alpha = Mth.clamp(alpha, 0.0f, 1.0f);
        progress = Mth.clamp(progress, 0.0f, 1.0f);
        if (alpha <= 0.0f) return;

        int y = height / 2 + c.hudYOffset.get();
        float o = c.hudOpacity.get().floatValue() * alpha;
        int bg = argb(o * 0.45f, 0, 0, 0);
        int dc = HudColors.dash();
        int fillColor = argb(o * 0.9f, (dc >> 16) & 255, (dc >> 8) & 255, dc & 255);
        int border = argb(o * 0.5f, 255, 255, 255);

        if (c.hudStyle.get() == HudStyle.BAR) {
            // широкая низкая полоска, заполняется слева направо
            int bw = c.hudBarWidth.get();
            int bh = c.hudBarHeight.get();
            int x = (width - bw) / 2;
            g.fill(x, y, x + bw, y + bh, bg);
            int filled = Math.round(bw * progress);
            if (filled > 0) {
                g.fill(x, y, x + filled, y + bh, fillColor);
            }
            g.renderOutline(x, y, bw, bh, border);
        } else {
            // квадрат, заполняется снизу вверх
            int size = c.hudSize.get();
            int x = (width - size) / 2;
            g.fill(x, y, x + size, y + size, bg);
            int filled = Math.round(size * progress);
            if (filled > 0) {
                g.fill(x, y + size - filled, x + size, y + size, fillColor);
            }
            g.renderOutline(x, y, size, size, border);
        }
    }

    /** Сфера ветра: рывок снова доступен сразу (двойной прыжок не трогаем). */
    public static void resetDashCooldown() {
        cooldownLeft = 0;
        dashBuffered = false;
        fadeTotal = DeadRunnersConfig.CLIENT.hudFadeTicks.get();
        fadeLeft = fadeTotal;
        playReady();
    }

    public static void startThunderCooldown(int ticks) {
        thunderTotal = Math.max(ticks, 1);
        thunderLeft = thunderTotal;
        thunderFade = 0;
    }

    /** Перезарядка Грома справа от хотбара: «вода» с бегущей волной поднимается вверх. */
    public static void renderThunder(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        if (thunderTotal <= 0 || (thunderLeft <= 0 && thunderFade <= 0)) return;
        float alpha = thunderLeft > 0 ? 1.0f : Mth.clamp((thunderFade - partialTick) / 12.0f, 0.0f, 1.0f);
        float prog = thunderLeft > 0 ? 1.0f - (thunderLeft - partialTick) / thunderTotal : 1.0f;
        prog = Mth.clamp(prog, 0.0f, 1.0f);
        float o = 0.9f * alpha;

        int size = 18;
        int x = width / 2 + 91 + 12;
        int y = height - 22 + 2;
        g.fill(x + 1, y, x + size - 1, y + size, argb(o * 0.55f, 8, 8, 12));
        g.fill(x, y + 1, x + size, y + size - 1, argb(o * 0.55f, 8, 8, 12));

        float base = (size - 2) * prog;
        float phase = (clientTicks + partialTick) * 0.5f;
        int tc = HudColors.thunderTop();
        int bc = HudColors.thunderBottom();
        int top = argb(o, (tc >> 16) & 255, (tc >> 8) & 255, tc & 255);
        int bot = argb(o * 0.85f, (bc >> 16) & 255, (bc >> 8) & 255, bc & 255);
        for (int i = 0; i < size - 2; i++) {
            float surface = base + (prog > 0.0f && prog < 1.0f ? Mth.sin(i * 0.9f + phase) * 1.2f : 0.0f);
            int hgt = Mth.clamp(Math.round(surface), 0, size - 2);
            if (hgt <= 0) continue;
            int cx = x + 1 + i;
            g.fillGradient(cx, y + size - 1 - hgt, cx + 1, y + size - 1, top, bot);
        }
        g.renderOutline(x, y, size, size, argb(o * 0.3f, 255, 255, 255));
    }

    /** Индикатор здоровья: белый плюс и полоски-ячейки с лёгким чёрным контуром, слева внизу. */
    public static void renderHealth(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        var c = DeadRunnersConfig.CLIENT;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (!c.healthEnabled.get() || p == null || hpShown < 0.0f || mc.gameMode == null
                || !mc.gameMode.canHurtPlayer() || p.isSpectator()) {
            return;
        }
        int cells = Mth.clamp(Math.round(p.getMaxHealth()), 1, 10);
        float shown = Mth.lerp(partialTick, hpPrevShown, hpShown);
        float trail = Mth.lerp(partialTick, hpPrevTrail, hpTrail);
        int scars = Math.min(LifeClient.scars(), cells);
        boolean burning = LifeClient.burning();
        if (c.healthHideWhenFull.get() && shown >= cells - 0.01f && trail <= shown + 0.01f
                && scars == 0 && !burning) {
            return;
        }

        int h = c.healthHeight.get();
        int gap = Math.max(3, h);
        int dw = Math.max(6, (c.healthWidth.get() - (cells - 1) * gap) / cells);
        int plus = h * 3;
        int px = 12;
        int py = height - c.healthYOffset.get() - plus;
        int cy = py + plus / 2;
        float o = c.healthOpacity.get().floatValue();
        int outline = argb(Math.min(1.0f, o * 0.9f), 0, 0, 0);
        float pulse = 0.65f + 0.35f * Mth.sin((clientTicks + partialTick) * 0.4f);

        // плюс (при получении урона на миг краснеет)
        int pcol = hpFlash > 0 ? argb(o, 255, 90, 90) : argb(o, 255, 255, 255);
        int po = (plus - h) / 2;
        g.fill(px - 1, py + po - 1, px + plus + 1, py + po + h + 1, outline);
        g.fill(px + po - 1, py - 1, px + po + h + 1, py + plus + 1, outline);
        g.fill(px, py + po, px + plus, py + po + h, pcol);
        g.fill(px + po, py, px + po + h, py + plus, pcol);

        // ячейки
        int sx = px + plus + gap + 2;
        int dy = cy - h / 2;
        int burnIdx = burning ? Mth.ceil(p.getHealth() - 0.01f) - 1 : -1;
        for (int i = 0; i < cells; i++) {
            int cx = sx + i * (dw + gap);
            g.fill(cx - 1, dy - 1, cx + dw + 1, dy + h + 1, outline);
            if (i >= cells - scars) {
                // ожог: тёмная выжженная ячейка с тлеющей искрой
                g.fill(cx, dy, cx + dw, dy + h, argb(o, 62, 22, 12));
                int ey = dy + h / 2;
                g.fill(cx + 2, ey, cx + dw - 2, ey + Math.max(1, h / 3), argb(o * pulse * 0.85f, 255, 120, 30));
                continue;
            }
            g.fill(cx, dy, cx + dw, dy + h, argb(o * 0.55f, 46, 46, 50));
            if (i == burnIdx) {
                // горящая ячейка: оранжевая, сгорает справа налево
                int bw = Math.round(dw * LifeClient.burnFraction(partialTick));
                g.fill(cx, dy, cx + dw, dy + h, argb(o * 0.8f, 110, 45, 12));
                if (bw > 0) g.fill(cx, dy, cx + bw, dy + h, argb(o * (0.75f + 0.25f * pulse), 255, 150, 35));
                continue;
            }
            float v = Mth.clamp(shown - i, 0.0f, 1.0f);
            float t = Mth.clamp(trail - i, 0.0f, 1.0f);
            int fw = Math.round(dw * v);
            int tw = Math.round(dw * t);
            if (tw > fw) g.fill(cx + fw, dy, cx + tw, dy + h, argb(o * 0.8f, 255, 110, 100));
            if (fw > 0) g.fill(cx, dy, cx + fw, dy + h, argb(o, 255, 255, 255));
        }
    }

    private static int argb(float a, int r, int gr, int b) {
        int ai = Mth.clamp(Math.round(a * 255.0f), 0, 255);
        return (ai << 24) | (r << 16) | (gr << 8) | b;
    }
}
