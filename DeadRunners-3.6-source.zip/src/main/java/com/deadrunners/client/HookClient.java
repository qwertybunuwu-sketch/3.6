package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.DeadRunnersMod;
import com.deadrunners.ModBlocks;
import com.deadrunners.ModSounds;
import com.deadrunners.SpaceMarks;
import com.deadrunners.net.ActionPacket;
import com.deadrunners.net.HookPacket;
import com.deadrunners.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Крюк: наведение на метку пространства, запуск по ПКМ, подтяжка, тряска камеры и прицел. */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, value = Dist.CLIENT)
public final class HookClient {
    private enum Phase { NONE, FLY, PULL }

    private static final int FLY_TICKS = 3;
    private static final int SHAKE_TOTAL = 8;
    private static final double AIM_TOLERANCE = 1.5;

    private static Phase phase = Phase.NONE;
    private static BlockPos target;
    private static BlockPos aimed;
    private static int phaseTicks;
    private static int cd;
    private static int shake;
    private static int stuck;
    private static Vec3 lastPos = Vec3.ZERO;
    /** Направление подтяжки (к метке); в конце используется вместо мгновенного, которое у самой цели может смотреть назад. */
    private static Vec3 pullDir = Vec3.ZERO;
    private static HookWebs.Web localWeb;
    private static float fov;
    private static float prevFov;

    private HookClient() {}

    public static boolean active() {
        return phase != Phase.NONE;
    }

    public static BlockPos aimed() {
        return aimed;
    }

    public static void reset() {
        phase = Phase.NONE;
        aimed = null;
        target = null;
        pullDir = Vec3.ZERO;
        cd = 0;
        shake = 0;
        fov = 0;
        prevFov = 0;
        localWeb = null;
        HookWebs.clear();
    }

    private static boolean ready(LocalPlayer p) {
        return phase == Phase.NONE && cd <= 0 && p.isAlive()
                && !p.isPassenger() && !p.isFallFlying() && !p.getAbilities().flying;
    }

    // --------------------------------------------------------------- тики

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !DeadRunnersConfig.serverReady()) {
            if (phase != Phase.NONE || localWeb != null) reset();
            return;
        }
        if (mc.isPaused()) return;

        if (event.phase == TickEvent.Phase.START) {
            if (phase == Phase.PULL) applyPull(p);
            return;
        }

        if (cd > 0) cd--;
        if (shake > 0) shake--;
        prevFov = fov;
        fov = phase == Phase.PULL ? Math.min(1.0f, fov + 0.35f) : Math.max(0.0f, fov - 0.12f);

        if (phase == Phase.FLY) {
            if (!markExists(mc, target) || !p.isAlive()) {
                cancel(false);
            } else if (++phaseTicks >= FLY_TICKS) {
                hit(mc, p);
            }
        } else if (phase == Phase.PULL) {
            afterPull(mc, p);
        }
        updateAim(mc, p);
    }

    private static boolean markExists(Minecraft mc, BlockPos pos) {
        return pos != null && mc.level.getBlockState(pos).is(ModBlocks.SPACE_MARK.get());
    }

    private static void updateAim(Minecraft mc, LocalPlayer p) {
        aimed = null;
        var cfg = DeadRunnersConfig.SERVER;
        if (!cfg.hookEnabled.get() || mc.screen != null || !p.isAlive() || p.isSpectator()
                || SpaceMarks.CLIENT.isEmpty()) return;
        double range = cfg.hookRange.get();
        double r2 = (range + 0.5) * (range + 0.5);
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double best = Double.MAX_VALUE;
        double bestAlong = 0.0;
        BlockPos bestPos = null;
        for (BlockPos pos : SpaceMarks.CLIENT) {
            double dx = pos.getX() + 0.5 - eye.x;
            double dy = pos.getY() + 0.5 - eye.y;
            double dz = pos.getZ() + 0.5 - eye.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > r2 || d2 < 0.25) continue;
            double along = dx * look.x + dy * look.y + dz * look.z;
            if (along <= 0.0) continue;
            double off = d2 - along * along;
            if (off > AIM_TOLERANCE * AIM_TOLERANCE) continue;
            // из нескольких меток в круге берём ту, что ближе к центру прицела
            if (off < best) {
                best = off;
                bestAlong = along;
                bestPos = pos;
            }
        }
        if (bestPos == null) return;
        if (!markExists(mc, bestPos)) {
            // устаревшая запись (мир сменился или блок убран)
            SpaceMarks.CLIENT.remove(bestPos);
            return;
        }
        Vec3 c = Vec3.atCenterOf(bestPos);
        if (mc.level.clip(new ClipContext(eye, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p))
                .getType() == HitResult.Type.BLOCK) return;
        // кассета перед меткой: ПКМ по ней должен работать как обычно
        if (mc.hitResult instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK
                && mc.level.getBlockState(bh.getBlockPos()).is(ModBlocks.CHECKPOINT_STAR.get())
                && bh.getLocation().distanceToSqr(eye) < bestAlong * bestAlong) return;
        aimed = bestPos;
    }

    // ---------------------------------------------------------------- ввод

    @SubscribeEvent
    public static void onUseKey(InputEvent.InteractionKeyMappingTriggered event) {
        if (!event.isUseItem() || aimed == null) return;
        event.setCanceled(true);
        event.setSwingHand(false);
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p != null && ready(p)) launch(mc, p, aimed);
    }

    private static void launch(Minecraft mc, LocalPlayer p, BlockPos pos) {
        phase = Phase.FLY;
        phaseTicks = 0;
        target = pos;
        cd = DeadRunnersConfig.SERVER.hookCooldown.get();
        ClientEvents.hookBegin(p);
        Net.CHANNEL.sendToServer(new HookPacket(pos));
        localWeb = HookWebs.addLocal(pos);
        mc.level.playLocalSound(p.getX(), p.getY(), p.getZ(), ModSounds.HOOK_FIRE.get(),
                SoundSource.PLAYERS, 0.8f, 1.0f, false);
    }

    private static void hit(Minecraft mc, LocalPlayer p) {
        phase = Phase.PULL;
        phaseTicks = 0;
        stuck = 0;
        lastPos = p.position();
        Vec3 first = feetTarget(p).subtract(lastPos);
        pullDir = first.lengthSqr() > 1.0E-6 ? first.normalize() : p.getLookAngle();
        shake = SHAKE_TOTAL;
        Vec3 c = Vec3.atCenterOf(target);
        mc.level.playLocalSound(c.x, c.y, c.z, ModSounds.HOOK_HIT.get(), SoundSource.PLAYERS, 0.9f, 1.0f, false);
        mc.level.playLocalSound(p.getX(), p.getY(), p.getZ(), ModSounds.HOOK_PULL.get(),
                SoundSource.PLAYERS, 0.7f, 1.0f, false);
    }

    // ------------------------------------------------------------ подтяжка

    private static Vec3 feetTarget(LocalPlayer p) {
        return Vec3.atCenterOf(target).subtract(0.0, p.getBbHeight() * 0.5, 0.0);
    }

    private static void applyPull(LocalPlayer p) {
        Vec3 v = feetTarget(p).subtract(p.position());
        double dist = v.length();
        if (dist < 1.0E-4) {
            p.setDeltaMovement(Vec3.ZERO);
            return;
        }
        if (dist > 0.5) pullDir = v.scale(1.0 / dist);
        double speed = DeadRunnersConfig.SERVER.hookPullSpeed.get();
        double accel = Math.min(1.0, 0.45 + phaseTicks * 0.28);
        double ease = dist < 2.5 ? Math.max(0.5, dist / 2.5) : 1.0;
        double step = Math.min(speed * accel * ease, dist);
        p.setDeltaMovement(v.scale(step / dist));
        p.fallDistance = 0;
    }

    private static void afterPull(Minecraft mc, LocalPlayer p) {
        phaseTicks++;
        if (!markExists(mc, target) || !p.isAlive() || p.isPassenger() || p.isFallFlying()
                || p.getAbilities().flying || phaseTicks > 40) {
            cancel(true);
            return;
        }
        Vec3 pos = p.position();
        stuck = pos.distanceToSqr(lastPos) < 0.0025 ? stuck + 1 : 0;
        lastPos = pos;
        Vec3 v = feetTarget(p).subtract(pos);
        double dist = v.length();
        if (dist <= 0.75) {
            arrive(p, dist > 1.0E-4 ? v.scale(1.0 / dist) : Vec3.ZERO);
        } else if (stuck >= 3) {
            cancel(true);
        }
    }

    private static void arrive(LocalPlayer p, Vec3 dir) {
        double speed = DeadRunnersConfig.SERVER.hookPullSpeed.get();
        // направление берём из подтяжки: у самой метки мгновенное может смотреть назад и толкнуть игрока обратно
        Vec3 fwd = pullDir.lengthSqr() > 1.0E-6 ? pullDir : dir;
        Vec3 out = fwd.scale(speed * 0.25);
        p.setDeltaMovement(out.x, Math.min(out.y, 0.3), out.z);
        ClientEvents.hookRestore();
        Net.CHANNEL.sendToServer(new ActionPacket(ActionPacket.HOOK_ARRIVE));
        cd = DeadRunnersConfig.SERVER.hookCooldown.get();
        finish();
    }

    private static void cancel(boolean keepMomentum) {
        cd = DeadRunnersConfig.SERVER.hookCooldown.get();
        finish();
    }

    private static void finish() {
        phase = Phase.NONE;
        target = null;
        if (localWeb != null) {
            HookWebs.end(localWeb);
            localWeb = null;
        }
    }

    // ------------------------------------------------- камера и поле зрения

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (shake <= 0) return;
        double k = DeadRunnersConfig.CLIENT.hookShake.get();
        if (k <= 0.0) return;
        float left = Mth.clamp((shake - (float) event.getPartialTick()) / SHAKE_TOTAL, 0.0f, 1.0f);
        float t = (Minecraft.getInstance().player != null ? Minecraft.getInstance().player.tickCount : 0)
                + (float) event.getPartialTick();
        float amp = (float) (k * 1.6 * left);
        event.setRoll(event.getRoll() + Mth.sin(t * 2.7f) * amp);
        event.setPitch(event.getPitch() + Mth.cos(t * 3.3f) * amp * 0.6f);
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        double k = DeadRunnersConfig.CLIENT.hookShake.get();
        if (k <= 0.0) return;
        float level = Mth.lerp(Minecraft.getInstance().getFrameTime(), prevFov, fov);
        if (level <= 0.0f) return;
        event.setNewFovModifier(event.getNewFovModifier() * (1.0f + (float) (0.10 * Math.min(k, 1.5)) * level));
    }

    // -------------------------------------------------------------- прицел

    @SubscribeEvent
    public static void onOverlayPre(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;
        if (!DeadRunnersConfig.CLIENT.customCrosshair.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.getCameraType().isFirstPerson()) event.setCanceled(true);
    }

    /** Точка ровно по центру экрана; над меткой пространства превращается в ромб. */
    public static void renderCrosshair(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        if (!DeadRunnersConfig.CLIENT.customCrosshair.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (!mc.options.getCameraType().isFirstPerson() || mc.options.hideGui) return;
        int cx = width / 2;
        int cy = height / 2;
        var pose = g.pose();
        pose.pushPose();
        if (aimed == null) {
            // квадрат 2x2 с центром ровно в середине окна (учитываем нечётную ширину в единицах интерфейса)
            pose.translate(width / 2.0 - cx, height / 2.0 - cy, 0.0);
            g.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0x66000000);
            g.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFFFFFF);
        } else {
            pose.translate(width / 2.0 - (cx + 0.5), height / 2.0 - (cy + 0.5), 0.0);
            LocalPlayer p = mc.player;
            boolean can = p != null && ready(p);
            int rgb = HudColors.hook();
            int a = can ? 255 : 110;
            int col = (a << 24) | rgb;
            int shadow = (can ? 0x80 : 0x40) << 24;
            int half = 4;
            for (int i = -half; i <= half; i++) {
                int w = half - Math.abs(i);
                g.fill(cx - w - 1, cy + i, cx + w + 2, cy + i + 1, shadow);
            }
            half = 3;
            for (int i = -half; i <= half; i++) {
                int w = half - Math.abs(i);
                g.fill(cx - w, cy + i, cx + w + 1, cy + i + 1, col);
            }
            g.fill(cx, cy, cx + 1, cy + 1, (a << 24) | 0xFFFFFF);
        }
        pose.popPose();
    }
}
