package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Плоское кольцо на земле: расширяется и растворяется. Одна частица на волну. */
public class ShockwaveParticle extends TextureSheetParticle {
    private static final int DURATION = 18;
    private static final int FULL_BRIGHT = 0xF000F0;
    private final int delay;
    private final float maxHalfSize;

    protected ShockwaveParticle(ClientLevel level, double x, double y, double z,
                                int delay, float radius, SpriteSet sprites) {
        super(level, x, y, z);
        this.pickSprite(sprites);
        this.delay = delay;
        this.maxHalfSize = Math.max(radius, 1.0f);
        this.lifetime = delay + DURATION;
        this.hasPhysics = false;
        this.gravity = 0.0f;
        this.xd = 0.0;
        this.yd = 0.0;
        this.zd = 0.0;
        this.rCol = 0.80f;
        this.gCol = 0.90f;
        this.bCol = 1.0f;
    }

    /** Без физики и движения: только счётчик возраста. */
    @Override
    public void tick() {
        if (this.age++ >= this.lifetime) this.remove();
    }

    @Override
    public void render(VertexConsumer buf, Camera camera, float partial) {
        float t = (this.age - this.delay + partial) / DURATION;
        if (t <= 0.0f || t >= 1.0f) return;
        float inv = 1.0f - t;
        float ease = 1.0f - inv * inv * inv;
        float s = Mth.lerp(ease, 0.8f, this.maxHalfSize);
        float a = inv * inv * 0.75f;

        Vec3 cam = camera.getPosition();
        float px = (float) (this.x - cam.x);
        float py = (float) (this.y - cam.y);
        float pz = (float) (this.z - cam.z);
        float u0 = this.getU0(), u1 = this.getU1(), v0 = this.getV0(), v1 = this.getV1();

        // обе стороны, чтобы кольцо было видно и сверху, и снизу
        quad(buf, px, py, pz, s, u0, u1, v0, v1, a, false);
        quad(buf, px, py, pz, s, u0, u1, v0, v1, a, true);
    }

    private void quad(VertexConsumer b, float px, float py, float pz, float s,
                      float u0, float u1, float v0, float v1, float a, boolean flip) {
        if (!flip) {
            vtx(b, px - s, py, pz - s, u0, v0, a);
            vtx(b, px - s, py, pz + s, u0, v1, a);
            vtx(b, px + s, py, pz + s, u1, v1, a);
            vtx(b, px + s, py, pz - s, u1, v0, a);
        } else {
            vtx(b, px - s, py, pz - s, u0, v0, a);
            vtx(b, px + s, py, pz - s, u1, v0, a);
            vtx(b, px + s, py, pz + s, u1, v1, a);
            vtx(b, px - s, py, pz + s, u0, v1, a);
        }
    }

    private void vtx(VertexConsumer b, float x, float y, float z, float u, float v, float a) {
        b.vertex(x, y, z).uv(u, v).color(this.rCol, this.gCol, this.bCol, a).uv2(FULL_BRIGHT).endVertex();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        /** vx = задержка волны в тиках, vy = радиус (передаются с сервера). */
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            if (!DeadRunnersConfig.CLIENT.particlesEnabled.get()) return null;
            return new ShockwaveParticle(level, x, y, z, (int) Math.round(vx), (float) vy, this.sprites);
        }
    }
}
