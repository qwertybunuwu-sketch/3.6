package com.deadrunners;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, DeadRunnersMod.MODID);

    public static final RegistryObject<SimpleParticleType> DASH_CLOUD =
            PARTICLES.register("dash_cloud", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> SHOCKWAVE =
            PARTICLES.register("shockwave", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
