package com.deadrunners;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public final class DeadRunnersConfig {
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final Server SERVER;
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Server, ForgeConfigSpec> s = new ForgeConfigSpec.Builder().configure(Server::new);
        SERVER = s.getLeft();
        SERVER_SPEC = s.getRight();
        Pair<Client, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = c.getLeft();
        CLIENT_SPEC = c.getRight();
    }

    private DeadRunnersConfig() {}

    /** Серверный конфиг доступен только после входа в мир. */
    public static boolean serverReady() {
        return SERVER_SPEC.isLoaded();
    }

    public static class Server {
        public final ForgeConfigSpec.BooleanValue dashEnabled;
        public final ForgeConfigSpec.BooleanValue dashInvulnerable;
        public final ForgeConfigSpec.DoubleValue dashSpeed;
        public final ForgeConfigSpec.IntValue dashDuration;
        public final ForgeConfigSpec.DoubleValue dashDistance;
        public final ForgeConfigSpec.DoubleValue dashAirDistance;
        public final ForgeConfigSpec.DoubleValue dashMaxRise;
        public final ForgeConfigSpec.IntValue dashCooldown;
        public final ForgeConfigSpec.DoubleValue momentumKeep;
        public final ForgeConfigSpec.DoubleValue dashUpMultiplier;
        public final ForgeConfigSpec.DoubleValue dashDownMultiplier;
        public final ForgeConfigSpec.DoubleValue dashUpHorizontalMultiplier;
        public final ForgeConfigSpec.BooleanValue bounceRestoresJump;
        public final ForgeConfigSpec.BooleanValue mantleEnabled;
        public final ForgeConfigSpec.DoubleValue mantleReach;
        public final ForgeConfigSpec.IntValue mantleRiseTicks;
        public final ForgeConfigSpec.BooleanValue parryEnabled;
        public final ForgeConfigSpec.DoubleValue parryRadius;
        public final ForgeConfigSpec.DoubleValue parrySpeedMultiplier;
        public final ForgeConfigSpec.DoubleValue parryMinSpeed;
        public final ForgeConfigSpec.BooleanValue parryTowardOwner;
        public final ForgeConfigSpec.BooleanValue parryHoming;
        public final ForgeConfigSpec.DoubleValue parryHomingSpeed;
        public final ForgeConfigSpec.DoubleValue parryHomingTurn;
        public final ForgeConfigSpec.IntValue parryHomingTicks;
        public final ForgeConfigSpec.DoubleValue parryHomingRange;
        public final ForgeConfigSpec.BooleanValue disableHunger;
        public final ForgeConfigSpec.BooleanValue thunderEnabled;
        public final ForgeConfigSpec.DoubleValue thunderDamage;
        public final ForgeConfigSpec.DoubleValue thunderRadius;
        public final ForgeConfigSpec.DoubleValue thunderKnockback;
        public final ForgeConfigSpec.BooleanValue thunderBreakGlass;
        public final ForgeConfigSpec.BooleanValue thunderNoFallDamage;
        public final ForgeConfigSpec.IntValue thunderWindowTicks;
        public final ForgeConfigSpec.IntValue thunderMaxTargets;
        public final ForgeConfigSpec.IntValue thunderCooldown;
        public final ForgeConfigSpec.DoubleValue thunderMinPitch;
        public final ForgeConfigSpec.BooleanValue bounceEnabled;
        public final ForgeConfigSpec.IntValue maxBounces;
        public final ForgeConfigSpec.DoubleValue bounceRetention;
        public final ForgeConfigSpec.DoubleValue slimeBounceMultiplier;
        public final ForgeConfigSpec.BooleanValue honeySlideEnabled;
        public final ForgeConfigSpec.DoubleValue honeySlideSpeed;
        public final ForgeConfigSpec.IntValue honeySlideMaxTicks;
        public final ForgeConfigSpec.BooleanValue lifeEnabled;
        public final ForgeConfigSpec.IntValue lifeMaxHealth;
        public final ForgeConfigSpec.DoubleValue lifeHeavyHit;
        public final ForgeConfigSpec.DoubleValue lifeInstaKill;
        public final ForgeConfigSpec.IntValue lifeBurnTicks;
        public final ForgeConfigSpec.IntValue lifeScarTicks;
        public final ForgeConfigSpec.IntValue lifeRegenTicks;
        public final ForgeConfigSpec.IntValue lifeEssenceRespawn;
        public final ForgeConfigSpec.BooleanValue doubleJumpEnabled;
        public final ForgeConfigSpec.DoubleValue doubleJumpStrength;
        public final ForgeConfigSpec.BooleanValue hookEnabled;
        public final ForgeConfigSpec.DoubleValue hookRange;
        public final ForgeConfigSpec.IntValue hookCooldown;
        public final ForgeConfigSpec.DoubleValue hookPullSpeed;
        public final ForgeConfigSpec.BooleanValue doubleJumpResetsFall;

        Server(ForgeConfigSpec.Builder b) {
            b.push("dash");
            dashEnabled = b.comment("Включить рывок").define("enabled", true);
            dashInvulnerable = b.comment("Неуязвимость игрока во время рывка (кроме void и /kill)")
                    .define("invulnerable", true);
            dashSpeed = b.comment("Сила рывка: скорость в блоках за тик")
                    .defineInRange("speed", 1.0, 0.2, 3.0);
            dashDuration = b.comment("Максимальная длительность рывка в тиках (20 тиков = 1 сек)")
                    .defineInRange("durationTicks", 7, 1, 40);
            dashDistance = b.comment("Дистанция рывка С ЗЕМЛИ в блоках. Рывок кончается, когда пройдена дистанция или вышло время")
                    .defineInRange("groundDistance", 4.4, 1.0, 16.0);
            dashAirDistance = b.comment("Дистанция рывка В ВОЗДУХЕ в блоках (короче наземного, чтобы отскок от стен и двойной прыжок имели смысл)")
                    .defineInRange("airDistanceBlocks", 3.8, 0.5, 16.0);
            dashMaxRise = b.comment("Максимальный суммарный подъём за один рывок вверх, в блоках")
                    .defineInRange("maxRiseHeight", 1.4, 0.2, 8.0);
            dashCooldown = b.comment("Перезарядка в тиках (40 = 2 секунды)")
                    .defineInRange("cooldownTicks", 40, 0, 1200);
            momentumKeep = b.comment("Какая доля скорости рывка сохраняется после его окончания (0..1)")
                    .defineInRange("momentumKeep", 0.5, 0.0, 1.0);
            dashUpMultiplier = b.comment("Множитель вертикальной части рывка ВВЕРХ. Меньше 1 - нерф, чтобы рывок вверх не превосходил два прыжка")
                    .defineInRange("upwardMultiplier", 0.33, 0.1, 2.0);
            dashUpHorizontalMultiplier = b.comment("Во сколько раз ослабляется ГОРИЗОНТАЛЬНАЯ часть рывка при взгляде вверх (на полном вертикальном рывке = этому множителю, под углом - пропорционально). Нерф рывка под углом вверх")
                    .defineInRange("upwardHorizontalMultiplier", 0.75, 0.1, 1.0);
            dashDownMultiplier = b.comment("Множитель вертикальной части рывка ВНИЗ. Больше 1 - рывок в землю быстрее и агрессивнее (для удара)")
                    .defineInRange("downwardMultiplier", 1.4, 0.5, 3.0);
            b.pop();

            b.push("bounce");
            bounceEnabled = b.comment("Отражение от стен под углом (иначе рывок просто прерывается)")
                    .define("enabled", true);
            bounceRestoresJump = b.comment("Успешный отскок от стены возвращает двойной прыжок (механика для паркура)")
                    .define("restoresDoubleJump", true);
            maxBounces = b.comment("Максимум отскоков за один рывок")
                    .defineInRange("maxBounces", 4, 0, 20);
            bounceRetention = b.comment("Множитель оставшейся дистанции после отскока (1.0 = импульс не теряется)")
                    .defineInRange("retention", 1.0, 0.1, 1.5);
            slimeBounceMultiplier = b.comment("Слизневый блок: во сколько раз сильнее отскок рывка от него (дистанция и время рывка)")
                    .defineInRange("slimeMultiplier", 1.6, 1.0, 3.0);
            honeySlideEnabled = b.comment("Медовый блок: рывок в него превращается в скольжение вдоль стены, в конце - отскок туда, куда смотрит игрок")
                    .define("honeySlide", true);
            honeySlideSpeed = b.comment("Скорость скольжения по мёду, блоков за тик")
                    .defineInRange("honeySlideSpeed", 0.5, 0.1, 1.5);
            honeySlideMaxTicks = b.comment("Максимальная длительность скольжения по мёду в тиках")
                    .defineInRange("honeySlideMaxTicks", 40, 5, 100);
            b.pop();

            b.push("life");
            lifeEnabled = b.comment("Система жизней: мало здоровья, лечение только на чекпоинтах (естественная регенерация и лечение отключены)")
                    .define("enabled", true);
            lifeMaxHealth = b.comment("Максимум здоровья (1 здоровье = 1 удар)")
                    .defineInRange("maxHealth", 3, 1, 20);
            lifeHeavyHit = b.comment("Удар от этого урона и выше отнимает 2 здоровья, остальные - 1 (пустота и /kill убивают сразу)")
                    .defineInRange("heavyHitDamage", 8.0, 1.0, 100.0);
            lifeInstaKill = b.comment("Урон от этого значения и выше убивает мгновенно (мгновенный урон 99 и подобное). Пустота, лава и /kill убивают всегда")
                    .defineInRange("instaKillDamage", 100.0, 10.0, 10000.0);
            lifeBurnTicks = b.comment("Огонь: сколько тиков ячейка горит (оранжевая), прежде чем выгорит (20 тиков = 1 сек)")
                    .defineInRange("burnTicks", 50, 10, 200);
            lifeScarTicks = b.comment("Сколько тиков держится ожог на выгоревшей ячейке: пока он есть, ячейку лечит только чекпоинт")
                    .defineInRange("scarTicks", 140, 20, 1200);
            lifeRegenTicks = b.comment("Естественная регенерация: тиков на одну ячейку (360 = 18 сек)")
                    .defineInRange("regenTicks", 360, 40, 6000);
            lifeEssenceRespawn = b.comment("Эссенция жизни: через сколько тиков возвращается после глотка (500 = 25 сек)")
                    .defineInRange("essenceRespawnTicks", 500, 20, 12000);
            b.pop();

            b.push("double_jump");
            doubleJumpEnabled = b.comment("Включить двойной прыжок").define("enabled", true);
            doubleJumpStrength = b.comment("Вертикальный импульс (обычный прыжок = 0.42)")
                    .defineInRange("strength", 0.52, 0.1, 2.0);
            doubleJumpResetsFall = b.comment("Сбрасывать накопленное расстояние падения при двойном прыжке")
                    .define("resetsFallDistance", false);
            b.pop();

            b.push("mantle");
            mantleEnabled = b.comment("Автовзбирание: если вы в воздухе упираетесь в уступ чуть выше ног и зажата клавиша вперёд, игрок быстро подтягивается наверх")
                    .define("enabled", true);
            mantleReach = b.comment("На сколько блоков выше ног может быть верх уступа (0.5 = полблока)")
                    .defineInRange("reach", 0.6, 0.2, 1.5);
            mantleRiseTicks = b.comment("Длительность подъёма в тиках (меньше = быстрее)")
                    .defineInRange("riseTicks", 3, 1, 10);
            b.pop();

            b.push("parry");
            parryEnabled = b.comment("Парирование снарядов рывком: снаряд летит обратно")
                    .define("enabled", true);
            parryRadius = b.comment("На сколько блоков вокруг игрока в рывке снаряд считается пойманным")
                    .defineInRange("radius", 0.8, 0.2, 3.0);
            parrySpeedMultiplier = b.comment("Множитель скорости отражённого снаряда")
                    .defineInRange("speedMultiplier", 1.2, 0.5, 3.0);
            parryMinSpeed = b.comment("Минимальная скорость отражённого снаряда")
                    .defineInRange("minSpeed", 1.2, 0.2, 4.0);
            parryTowardOwner = b.comment("Отражать в сторону прошлого владельца (иначе по направлению взгляда)")
                    .define("towardOwner", true);
            parryHoming = b.comment("Самонаведение отражённого снаряда: летит в цель, огибает стены и попадает")
                    .define("homing", true);
            parryHomingSpeed = b.comment("Скорость самонаводящегося снаряда (блоков за тик)")
                    .defineInRange("homingSpeed", 2.2, 0.5, 4.0);
            parryHomingTurn = b.comment("Максимальный поворот снаряда за тик в градусах (больше = круче закручивается)")
                    .defineInRange("homingTurnDegrees", 35.0, 5.0, 90.0);
            parryHomingTicks = b.comment("Сколько тиков снаряд может самонаводиться")
                    .defineInRange("homingMaxTicks", 100, 10, 400);
            parryHomingRange = b.comment("Радиус поиска цели, если прошлого владельца нет (ищем врага по взгляду игрока)")
                    .defineInRange("homingSearchRange", 32.0, 8.0, 96.0);
            b.pop();

            b.push("thunder");
            thunderEnabled = b.comment("Гром: рывок в воздухе строго вниз + касание земли = ударная волна")
                    .define("enabled", true);
            thunderCooldown = b.comment("Перезарядка Грома в тиках (140 = 7 секунд)")
                    .defineInRange("cooldownTicks", 140, 20, 2400);
            thunderMinPitch = b.comment("Насколько круто вниз надо смотреть при рывке в воздухе (90 = ровно вниз)")
                    .defineInRange("minPitchDegrees", 75.0, 45.0, 90.0);
            thunderDamage = b.comment("Урон мобам вокруг (2 = одно сердце, небольшой)")
                    .defineInRange("damage", 3.0, 0.0, 40.0);
            thunderRadius = b.comment("Радиус волны в блоках")
                    .defineInRange("waveRadius", 7.0, 1.0, 16.0);
            thunderKnockback = b.comment("Сила отбрасывания (0.75 = на среднюю дистанцию)")
                    .defineInRange("knockback", 0.75, 0.0, 3.0);
            thunderBreakGlass = b.comment("Ломать стекло 3x3 под игроком (игрок падает дальше)")
                    .define("breakGlass", true);
            thunderNoFallDamage = b.comment("Гром гасит урон от падения при приземлении")
                    .define("noFallDamage", true);
            thunderWindowTicks = b.comment("Сколько тиков после рывка в воздухе Гром ждёт касания земли")
                    .defineInRange("windowTicks", 200, 20, 1200);
            thunderMaxTargets = b.comment("Максимум задетых существ за удар (защита от лагов на фермах)")
                    .defineInRange("maxTargets", 40, 1, 200);
            b.pop();

            b.push("hook");
            hookEnabled = b.comment("Крюк: ПКМ по метке пространства подтягивает игрока и мгновенно возвращает рывок и двойной прыжок")
                    .define("enabled", true);
            hookRange = b.comment("Дальность крюка в блоках (нужна прямая видимость)")
                    .defineInRange("range", 10.0, 4.0, 24.0);
            hookCooldown = b.comment("Перезарядка крюка в тиках (4 = 200 мс)")
                    .defineInRange("cooldownTicks", 4, 1, 40);
            hookPullSpeed = b.comment("Скорость подтяжки, блоков за тик")
                    .defineInRange("pullSpeed", 1.6, 0.6, 3.0);
            b.pop();

            b.push("survival");
            disableHunger = b.comment("Отключить голод: сытость всегда полная, еда не тратится")
                    .define("disableHunger", true);
            b.pop();
        }
    }

    public static class Client {
        public final ForgeConfigSpec.BooleanValue particlesEnabled;
        public final ForgeConfigSpec.IntValue particleCount;
        public final ForgeConfigSpec.DoubleValue particleSize;
        public final ForgeConfigSpec.IntValue particleLifetime;

        public final ForgeConfigSpec.ConfigValue<String> dashSound;
        public final ForgeConfigSpec.DoubleValue dashVolume;
        public final ForgeConfigSpec.DoubleValue dashPitch;
        public final ForgeConfigSpec.ConfigValue<String> bounceSound;
        public final ForgeConfigSpec.DoubleValue bounceVolume;
        public final ForgeConfigSpec.DoubleValue bouncePitch;
        public final ForgeConfigSpec.ConfigValue<String> jumpSound;
        public final ForgeConfigSpec.DoubleValue jumpVolume;
        public final ForgeConfigSpec.DoubleValue jumpPitch;

        public final ForgeConfigSpec.BooleanValue hudEnabled;
        public final ForgeConfigSpec.IntValue hudSize;
        public final ForgeConfigSpec.IntValue hudYOffset;
        public final ForgeConfigSpec.DoubleValue hudOpacity;
        public final ForgeConfigSpec.IntValue hudFadeTicks;
        public final ForgeConfigSpec.EnumValue<HudStyle> hudStyle;
        public final ForgeConfigSpec.IntValue hudBarWidth;
        public final ForgeConfigSpec.IntValue hudBarHeight;
        public final ForgeConfigSpec.ConfigValue<String> dashColor;
        public final ForgeConfigSpec.ConfigValue<String> thunderColorTop;
        public final ForgeConfigSpec.ConfigValue<String> thunderColorBottom;
        public final ForgeConfigSpec.BooleanValue colorblindMode;
        public final ForgeConfigSpec.ConfigValue<String> hookColor;
        public final ForgeConfigSpec.BooleanValue customCrosshair;
        public final ForgeConfigSpec.DoubleValue hookShake;

        public final ForgeConfigSpec.BooleanValue healthEnabled;
        public final ForgeConfigSpec.IntValue healthWidth;
        public final ForgeConfigSpec.IntValue healthHeight;
        public final ForgeConfigSpec.IntValue healthYOffset;
        public final ForgeConfigSpec.DoubleValue healthOpacity;
        public final ForgeConfigSpec.BooleanValue healthHideWhenFull;

        public final ForgeConfigSpec.BooleanValue dashEffectEnabled;
        public final ForgeConfigSpec.DoubleValue dashEffectOpacity;
        public final ForgeConfigSpec.DoubleValue dashFovBoost;

        public final ForgeConfigSpec.IntValue dashBufferTicks;
        public final ForgeConfigSpec.BooleanValue readySoundEnabled;
        public final ForgeConfigSpec.ConfigValue<String> readySound;
        public final ForgeConfigSpec.DoubleValue readyVolume;
        public final ForgeConfigSpec.DoubleValue readyPitch;
        public final ForgeConfigSpec.DoubleValue mantleCameraDip;
        public final ForgeConfigSpec.BooleanValue hideHungerBar;
        public final ForgeConfigSpec.BooleanValue savingIndicator;

        Client(ForgeConfigSpec.Builder b) {
            b.push("particles");
            particlesEnabled = b.define("enabled", true);
            particleCount = b.comment("Облачков за тик во время рывка")
                    .defineInRange("countPerTick", 2, 0, 8);
            particleSize = b.comment("Размер облачка")
                    .defineInRange("size", 0.14, 0.03, 0.5);
            particleLifetime = b.comment("Время жизни облачка в тиках")
                    .defineInRange("lifetimeTicks", 16, 4, 60);
            b.pop();

            b.push("sounds");
            b.comment("Звук задаётся ID звукового события, например deadrunners:dash или minecraft:entity.phantom.flap");
            dashSound = b.define("dashSound", "deadrunners:dash");
            dashVolume = b.defineInRange("dashVolume", 0.8, 0.0, 2.0);
            dashPitch = b.defineInRange("dashPitch", 1.0, 0.5, 2.0);
            bounceSound = b.define("bounceSound", "deadrunners:bounce");
            bounceVolume = b.defineInRange("bounceVolume", 0.7, 0.0, 2.0);
            bouncePitch = b.defineInRange("bouncePitch", 1.0, 0.5, 2.0);
            jumpSound = b.define("doubleJumpSound", "deadrunners:double_jump");
            jumpVolume = b.defineInRange("doubleJumpVolume", 0.7, 0.0, 2.0);
            jumpPitch = b.defineInRange("doubleJumpPitch", 1.0, 0.5, 2.0);
            b.pop();

            b.push("hud");
            hudEnabled = b.define("enabled", true);
            hudSize = b.comment("Размер квадрата в пикселях интерфейса (8-12)")
                    .defineInRange("size", 9, 8, 12);
            hudYOffset = b.comment("Смещение вниз от центра экрана (прицела)")
                    .defineInRange("yOffset", 12, 0, 64);
            hudOpacity = b.comment("Общая непрозрачность")
                    .defineInRange("opacity", 0.6, 0.1, 1.0);
            hudFadeTicks = b.comment("Длительность плавного исчезновения в тиках")
                    .defineInRange("fadeTicks", 10, 1, 40);
            hudStyle = b.comment("BAR - широкая полоска слева направо, SQUARE - маленький квадрат")
                    .defineEnum("style", HudStyle.BAR);
            hudBarWidth = b.comment("Ширина полоски (режим BAR)")
                    .defineInRange("barWidth", 24, 12, 64);
            hudBarHeight = b.comment("Высота полоски (режим BAR)")
                    .defineInRange("barHeight", 5, 3, 10);
            dashColor = b.comment("Цвет заполнения полоски рывка, HEX вида #RRGGBB")
                    .define("dashColor", "#AAAAAA", o -> o instanceof String str && str.matches("#?[0-9A-Fa-f]{6}"));
            thunderColorTop = b.comment("Цвет Грома: верх (гребень волны), HEX #RRGGBB")
                    .define("thunderColorTop", "#C8E6FF", o -> o instanceof String str && str.matches("#?[0-9A-Fa-f]{6}"));
            thunderColorBottom = b.comment("Цвет Грома: низ, HEX #RRGGBB")
                    .define("thunderColorBottom", "#5A96EB", o -> o instanceof String str && str.matches("#?[0-9A-Fa-f]{6}"));
            colorblindMode = b.comment("Режим для дальтоников: игнорирует свои цвета и берёт контрастную палитру (оранжевый рывок, синий Гром)")
                    .define("colorblindMode", false);
            hookColor = b.comment("Цвет паутины крюка и ромба прицела, HEX #RRGGBB")
                    .define("hookColor", "#4FA8FF", o -> o instanceof String str && str.matches("#?[0-9A-Fa-f]{6}"));
            customCrosshair = b.comment("Свой прицел: точка ровно по центру экрана, над меткой пространства превращается в ромб")
                    .define("customCrosshair", true);
            b.pop();

            b.push("health_bar");
            healthEnabled = b.comment("Свой индикатор здоровья (плюс и полоски слева внизу) вместо ванильных сердец")
                    .define("customBar3", true);
            healthWidth = b.comment("Общая ширина трёх полосок здоровья").defineInRange("width2", 66, 30, 160);
            healthHeight = b.comment("Толщина полосок и плюса").defineInRange("height2", 4, 3, 12);
            healthYOffset = b.comment("Отступ низа плюса от нижнего края экрана (слева внизу)")
                    .defineInRange("yOffset2", 16, 4, 200);
            healthOpacity = b.defineInRange("opacity", 0.9, 0.1, 1.0);
            healthHideWhenFull = b.comment("Прятать полоску при полном здоровье")
                    .define("hideWhenFull", false);
            b.pop();

            b.push("effects");
            hookShake = b.comment("Сила тряски камеры и рывка FOV у крюка (0 = выключено)")
                    .defineInRange("hookShake", 1.0, 0.0, 2.0);
            dashEffectEnabled = b.comment("Эффект ускорения по краям экрана во время рывка")
                    .define("dashEffect", true);
            dashEffectOpacity = b.comment("Яркость эффекта")
                    .defineInRange("dashEffectOpacity", 0.4, 0.05, 1.0);
            dashFovBoost = b.comment("Расширение поля зрения во время рывка (0 = выключено)")
                    .defineInRange("dashFovBoost", 0.12, 0.0, 0.5);
            b.pop();

            b.push("qol");
            savingIndicator = b.comment("Значок кассеты и надпись Saving... в правом нижнем углу при сохранении")
                    .define("savingIndicator", true);
            dashBufferTicks = b.comment("Буфер нажатия: если нажать R за столько тиков до конца перезарядки, рывок сработает сам (0 = выключено)")
                    .defineInRange("dashBufferTicks", 4, 0, 20);
            readySoundEnabled = b.comment("Тихий звук, когда перезарядка закончилась")
                    .define("readySound", true);
            readySound = b.define("readySoundId", "deadrunners:ready");
            readyVolume = b.defineInRange("readyVolume", 1.0, 0.0, 2.0);
            readyPitch = b.defineInRange("readyPitch", 1.0, 0.5, 2.0);
            mantleCameraDip = b.comment("Лёгкая качка камеры вниз и обратно при взбирании, в градусах (0 = выключено)")
                    .defineInRange("mantleCameraDip", 3.0, 0.0, 10.0);
            hideHungerBar = b.comment("Скрывать полоску голода, когда голод отключён сервером")
                    .define("hideHungerBar", true);
            b.pop();
        }
    }
}
