package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Маленькое белое полупрозрачное облачко. */
public class DashCloudParticle extends TextureSheetParticle {
    private static final float BASE_ALPHA = 0.55f;
    private final SpriteSet sprites;

    protected DashCloudParticle(ClientLevel level, double x, double y, double z,
                                double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.xd = vx * 0.1 + (this.random.nextFloat() - 0.5f) * 0.01;
        this.yd = vy * 0.1 + (this.random.nextFloat() - 0.5f) * 0.01;
        this.zd = vz * 0.1 + (this.random.nextFloat() - 0.5f) * 0.01;
        this.quadSize = DeadRunnersConfig.CLIENT.particleSize.get().floatValue() * (0.8f + this.random.nextFloat() * 0.4f);
        this.lifetime = DeadRunnersConfig.CLIENT.particleLifetime.get() + this.random.nextInt(6);
        this.gravity = 0.0f;
        this.friction = 0.92f;
        this.hasPhysics = false;
        this.rCol = 1.0f;
        this.gCol = 1.0f;
        this.bCol = 1.0f;
        this.alpha = BASE_ALPHA;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.removed) return;
        this.setSpriteFromAge(this.sprites);
        float t = (float) this.age / (float) this.lifetime;
        this.alpha = BASE_ALPHA * (1.0f - t * t);
        this.quadSize *= 0.985f;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            if (!DeadRunnersConfig.CLIENT.particlesEnabled.get()) return null;
            return new DashCloudParticle(level, x, y, z, vx, vy, vz, this.sprites);
        }
    }
}
