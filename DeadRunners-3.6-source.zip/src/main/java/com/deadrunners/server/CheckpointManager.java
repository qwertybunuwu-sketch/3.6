package com.deadrunners.server;

import com.deadrunners.CheckpointData;
import com.deadrunners.DeadRunnersMod;
import net.minecraft.commands.Commands;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Команда сброса чекпоинта, возврат на чекпоинт после смерти, синхронизация при входе. */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID)
public final class CheckpointManager {
    private static final Map<UUID, CheckpointData.Entry> DEATH_TARGET = new HashMap<>();
    private static final List<UUID> RESPAWNED = new ArrayList<>();

    private CheckpointManager() {}

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("deadrunners")
                .then(Commands.literal("checkpoint")
                        .then(Commands.literal("clear")
                                .executes(c -> {
                                    CheckpointData.clear(c.getSource().getPlayerOrException());
                                    return 1;
                                }))));
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        CheckpointData.Entry e = CheckpointData.get(p.server).getEntry(p.getUUID());
        if (e != null) DEATH_TARGET.put(p.getUUID(), e);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p && DEATH_TARGET.containsKey(p.getUUID())) {
            RESPAWNED.add(p.getUUID()); // телепорт в следующем тике, когда респавн полностью завершён
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) CheckpointData.sync(p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        DEATH_TARGET.remove(id);
        RESPAWNED.remove(id);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || RESPAWNED.isEmpty()) return;
        MinecraftServer server = event.getServer();
        for (UUID id : RESPAWNED) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            CheckpointData.Entry e = DEATH_TARGET.remove(id);
            if (p != null && e != null) teleport(p, e);
        }
        RESPAWNED.clear();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        DEATH_TARGET.clear();
        RESPAWNED.clear();
    }

    private static void teleport(ServerPlayer p, CheckpointData.Entry e) {
        ServerLevel level = p.server.getLevel(e.dim());
        if (level == null) return;
        p.teleportTo(level, e.x(), e.y(), e.z(), e.yRot(), e.xRot());
        p.fallDistance = 0.0f;
        p.setDeltaMovement(Vec3.ZERO);
        p.hurtMarked = true;
    }
}
