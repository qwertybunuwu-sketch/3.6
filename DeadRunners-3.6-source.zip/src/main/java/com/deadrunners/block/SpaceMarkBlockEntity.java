package com.deadrunners.block;

import com.deadrunners.ModBlockEntities;
import com.deadrunners.SpaceMarks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Нужна для рендерера и регистрации метки в клиентском списке. */
public class SpaceMarkBlockEntity extends BlockEntity {
    public SpaceMarkBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SPACE_MARK.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && level.isClientSide) SpaceMarks.add(worldPosition);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (level != null && level.isClientSide) SpaceMarks.remove(worldPosition);
    }
}
