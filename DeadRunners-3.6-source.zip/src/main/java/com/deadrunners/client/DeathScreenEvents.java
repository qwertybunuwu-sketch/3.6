package com.deadrunners.client;

import com.deadrunners.DeadRunnersMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Подмена ванильного экрана смерти (кроме хардкора). */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, value = Dist.CLIENT)
public final class DeathScreenEvents {
    private DeathScreenEvents() {}

    @SubscribeEvent
    public static void onOpening(ScreenEvent.Opening event) {
        if (!(event.getNewScreen() instanceof DeathScreen)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.getLevelData().isHardcore()) return;
        event.setNewScreen(new DeathTerminalScreen());
    }
}
