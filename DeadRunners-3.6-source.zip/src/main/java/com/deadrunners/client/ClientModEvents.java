package com.deadrunners.client;

import com.deadrunners.DeadRunnersMod;
import com.deadrunners.ModItems;
import com.deadrunners.ModParticles;
import com.deadrunners.item.WindDashEggItem;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Регистрации на MOD-шине (только клиент). */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    /** Клавиша рывка (по умолчанию R, меняется в Настройки -> Управление). */
    public static final KeyMapping DASH_KEY = new KeyMapping(
            "key.deadrunners.dash",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "key.categories.deadrunners");

    private ClientModEvents() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new ModSettingsScreen(parent)));
    }

    @SubscribeEvent
    public static void onItemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tint) -> tint == 0 ? WindDashEggItem.COLOR_MAIN : WindDashEggItem.COLOR_SPOT,
                ModItems.WIND_DASH_EGG.get());
        event.register((stack, tint) -> tint == 0 ? com.deadrunners.item.LifeEssenceEggItem.COLOR_MAIN
                : com.deadrunners.item.LifeEssenceEggItem.COLOR_SPOT, ModItems.LIFE_ESSENCE_EGG.get());
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(DASH_KEY);
    }

    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.DASH_CLOUD.get(), DashCloudParticle.Provider::new);
        event.registerSpriteSet(ModParticles.SHOCKWAVE.get(), ShockwaveParticle.Provider::new);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(com.deadrunners.ModEntities.WIND_DASH.get(), WindDashRenderer::new);
        event.registerEntityRenderer(com.deadrunners.ModEntities.LIFE_ESSENCE.get(),
                ctx -> new WindDashRenderer<>(ctx, WindDashRenderer.LIFE_CUBE, 0.6f, 1.0f, 0.6f));
        event.registerBlockEntityRenderer(com.deadrunners.ModBlockEntities.CHECKPOINT_STAR.get(), CheckpointStarRenderer::new);
        event.registerBlockEntityRenderer(com.deadrunners.ModBlockEntities.SPACE_MARK.get(), SpaceMarkRenderer::new);
    }

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll("dash_effect", ClientEvents::renderEffect);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "dash_cooldown", ClientEvents::renderHud);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "health_bar", ClientEvents::renderHealth);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "thunder_cooldown", ClientEvents::renderThunder);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "saving", SavingHud::render);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "dr_crosshair", HookClient::renderCrosshair);
    }
}
