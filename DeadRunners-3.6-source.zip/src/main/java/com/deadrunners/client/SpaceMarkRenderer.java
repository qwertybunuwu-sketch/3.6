package com.deadrunners.client;

import com.deadrunners.DeadRunnersMod;
import com.deadrunners.block.SpaceMarkBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;

/** Метка пространства: 2.5D-спрайт, всегда повёрнутый к игроку, с несколькими слоями разной глубины. */
public class SpaceMarkRenderer implements BlockEntityRenderer<SpaceMarkBlockEntity> {
    private static final ResourceLocation FRAME = new ResourceLocation(DeadRunnersMod.MODID, "textures/block/space_mark_frame.png");
    private static final ResourceLocation SPIRAL = new ResourceLocation(DeadRunnersMod.MODID, "textures/block/space_mark_spiral.png");
    private static final ResourceLocation GLOW = new ResourceLocation(DeadRunnersMod.MODID, "textures/block/space_mark_glow.png");

    public SpaceMarkRenderer(BlockEntityRendererProvider.Context ctx) {}

    @Override
    public void render(SpaceMarkBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        float time = level.getGameTime() + pt;
        boolean aimed = be.getBlockPos().equals(HookClient.aimed());
        float size = aimed ? 0.56f : 0.48f;
        float pulse = 0.5f + 0.5f * Mth.sin(time * 0.12f);

        ps.pushPose();
        ps.translate(0.5, 0.5 + Mth.sin(time * 0.08f) * 0.05, 0.5);
        ps.mulPose(Minecraft.getInstance().getEntityRenderDispatcher().cameraOrientation());

        // свечение позади
        ps.pushPose();
        ps.mulPose(Axis.ZP.rotationDegrees(-time * 1.5f));
        quad(buffers.getBuffer(RenderType.entityTranslucentEmissive(GLOW)), ps, size * 1.7f,
                (int) ((aimed ? 150 : 90) + 50 * pulse));
        ps.popPose();

        // рамка
        quad(buffers.getBuffer(RenderType.entityTranslucent(FRAME)), ps, size, 255);

        // спираль: три слоя разной «глубины» крутятся с разной скоростью
        VertexConsumer sp = buffers.getBuffer(RenderType.entityTranslucentEmissive(SPIRAL));
        for (int i = 0; i < 3; i++) {
            ps.pushPose();
            ps.translate(0.0, 0.0, -0.01 * (i + 1));
            ps.mulPose(Axis.ZP.rotationDegrees(time * (3.0f + i * 2.2f) * (i % 2 == 0 ? 1 : -1)));
            quad(sp, ps, size * (0.95f - i * 0.22f + 0.04f * pulse), 255 - i * 55);
            ps.popPose();
        }
        ps.popPose();
    }

    private static void quad(VertexConsumer vc, PoseStack ps, float h, int alpha) {
        PoseStack.Pose pose = ps.last();
        int light = LightTexture.FULL_BRIGHT;
        vertex(vc, pose, -h, -h, 0.0f, 1.0f, alpha, light);
        vertex(vc, pose, h, -h, 1.0f, 1.0f, alpha, light);
        vertex(vc, pose, h, h, 1.0f, 0.0f, alpha, light);
        vertex(vc, pose, -h, h, 0.0f, 0.0f, alpha, light);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float u, float v, int a, int light) {
        vc.vertex(pose.pose(), x, y, 0.0f).color(255, 255, 255, Mth.clamp(a, 0, 255)).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), 0.0f, 0.0f, 1.0f).endVertex();
    }

    @Override
    public int getViewDistance() {
        return 96;
    }
}
