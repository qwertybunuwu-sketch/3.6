package com.deadrunners.net;

import com.deadrunners.server.ServerHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: действие игрока (рывок, отскок, двойной прыжок). */
public record ActionPacket(byte action) {
    public static final byte DASH = 0;
    public static final byte BOUNCE = 1;
    public static final byte DOUBLE_JUMP = 2;
    public static final byte MANTLE = 3;
    public static final byte HOOK_ARRIVE = 4;
    public static final byte SLIDE = 6;
    public static final byte SLIDE_END = 7;
    public static final byte SLIME = 8;

    public void encode(FriendlyByteBuf buf) {
        buf.writeByte(action);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        return new ActionPacket(buf.readByte());
    }

    public static void handle(ActionPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                ServerHandler.onAction(player, packet.action());
            }
        });
        ctx.setPacketHandled(true);
    }
}
