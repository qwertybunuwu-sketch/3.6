package com.deadrunners.block;

import com.deadrunners.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Пустая заглушка: нужна только чтобы рисовать вращающуюся дискету рендерером. */
public class CheckpointStarBlockEntity extends BlockEntity {
    public CheckpointStarBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CHECKPOINT_STAR.get(), pos, state);
    }
}
