package com.deadrunners.server;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.DeadRunnersMod;
import com.deadrunners.ModParticles;
import com.deadrunners.ModSounds;
import com.deadrunners.net.ActionPacket;
import com.deadrunners.net.Net;
import com.deadrunners.net.ResetDashPacket;
import com.deadrunners.net.ThunderCdPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.util.Mth;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID)
public final class ServerHandler {
    /** Кто последним отразил снаряд (этот игрок не может отразить его снова). */
    private static final String TAG_PARRY_BY = "deadrunners_parry_by";

    private static final class State {
        long lastDash = Long.MIN_VALUE / 2;
        long trailUntil = -1;
        long invulnUntil = -1;
        long lastJump = Long.MIN_VALUE / 2;
        /** «Гром» заряжен до этого тика (-1 = не заряжен). */
        long thunderUntil = -1;
        long thunderStart = -1;
        long thunderReadyAt = Long.MIN_VALUE / 2;
        long lastHook = Long.MIN_VALUE / 2;
        BlockPos hookTarget;
        long hookUntil = -1;
    }

    /** Снаряд, попавший в игрока в рывке: отражаем в конце тика, когда игра уже закончила его обработку. */
    private record Pending(ServerPlayer player, Projectile projectile, double speed) {}

    /** Отражённый снаряд, который самонаводится на цель. */
    private static final class Homing {
        final Projectile proj;
        final Entity target;
        final double speed;
        int ticksLeft;
        int stuck;
        Vec3 dir;

        Homing(Projectile proj, Entity target, double speed, int ticksLeft, Vec3 dir) {
            this.proj = proj;
            this.target = target;
            this.speed = speed;
            this.ticksLeft = ticksLeft;
            this.dir = dir;
        }
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final List<Pending> PENDING = new ArrayList<>();
    private static final List<Homing> HOMING = new ArrayList<>();
    /** Потолок одновременных самонаводящихся снарядов: защита от лагов на ловушках со скелетами/дозаторами. */
    private static final int MAX_HOMING = 48;

    private ServerHandler() {}

    public static void onAction(ServerPlayer player, byte action) {
        if (!DeadRunnersConfig.serverReady()) return;
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        State s = STATES.computeIfAbsent(player.getUUID(), id -> new State());

        switch (action) {
            case ActionPacket.DASH -> {
                if (!DeadRunnersConfig.SERVER.dashEnabled.get()) return;
                int cooldown = DeadRunnersConfig.SERVER.dashCooldown.get();
                // небольшой допуск на сетевую задержку
                if (now - s.lastDash < cooldown - 4) return;
                int duration = DeadRunnersConfig.SERVER.dashDuration.get();
                s.lastDash = now;
                s.trailUntil = now + duration;
                s.invulnUntil = now + duration + 4;
                player.fallDistance = 0;
                playToOthers(player, ModSounds.DASH.get(), 0.8f, 1.0f);
                // рывок в воздухе строго вниз заряжает «Гром»: удар случится при касании земли
                var tc = DeadRunnersConfig.SERVER;
                if (tc.thunderEnabled.get() && now >= s.thunderReadyAt && isAirborne(player)
                        && player.getLookAngle().y <= -Math.sin(Math.toRadians(tc.thunderMinPitch.get()))) {
                    s.thunderStart = now;
                    s.thunderUntil = now + DeadRunnersConfig.SERVER.thunderWindowTicks.get();
                } else {
                    s.thunderUntil = -1;
                }
            }
            case ActionPacket.BOUNCE -> {
                // отскок засчитывается только во время рывка
                if (now > s.trailUntil + 5) return;
                player.fallDistance = 0;
                playToOthers(player, ModSounds.BOUNCE.get(), 0.7f, 1.0f);
            }
            case ActionPacket.DOUBLE_JUMP -> {
                if (!DeadRunnersConfig.SERVER.doubleJumpEnabled.get()) return;
                if (now - s.lastJump < 4) return;
                s.lastJump = now;
                if (DeadRunnersConfig.SERVER.doubleJumpResetsFall.get()) {
                    player.fallDistance = 0;
                }
                playToOthers(player, ModSounds.DOUBLE_JUMP.get(), 0.7f, 1.0f);
                puffToOthers(player, player.getX(), player.getY() + 0.1, player.getZ(), 6, 0.25);
            }
            case ActionPacket.SLIDE -> {
                // скольжение по мёду: неуязвимость на всё скольжение
                if (now > s.trailUntil + 5 || !DeadRunnersConfig.SERVER.honeySlideEnabled.get()) return;
                int len = DeadRunnersConfig.SERVER.honeySlideMaxTicks.get();
                s.trailUntil = Math.max(s.trailUntil, now + len);
                s.invulnUntil = Math.max(s.invulnUntil, now + len + 4);
                player.fallDistance = 0;
                playToOthers(player, ModSounds.BOUNCE.get(), 0.7f, 0.7f);
            }
            case ActionPacket.SLIDE_END -> {
                // скольжение кончилось: окно рывка снова обычной длины
                if (now > s.trailUntil + 5) return;
                int duration = DeadRunnersConfig.SERVER.dashDuration.get();
                s.trailUntil = now + duration;
                s.invulnUntil = now + duration + 4;
                player.fallDistance = 0;
            }
            case ActionPacket.SLIME -> {
                // отскок от слизня удлиняет рывок: окно неуязвимости растёт вместе с ним
                if (now > s.trailUntil + 5) return;
                double mult = DeadRunnersConfig.SERVER.slimeBounceMultiplier.get();
                int duration = (int) Math.ceil(DeadRunnersConfig.SERVER.dashDuration.get() * mult);
                s.trailUntil = Math.max(s.trailUntil, now + duration);
                s.invulnUntil = Math.max(s.invulnUntil, now + duration + 4);
            }
            case ActionPacket.HOOK_ARRIVE -> {
                // крюк долетел: рывок и двойной прыжок возвращаются мгновенно (только после настоящего запуска)
                if (s.hookTarget == null || now > s.hookUntil) return;
                if (player.distanceToSqr(Vec3.atCenterOf(s.hookTarget)) > 16.0) return;
                s.hookTarget = null;
                s.lastDash = Long.MIN_VALUE / 2;
                s.lastJump = Long.MIN_VALUE / 2;
                s.trailUntil = -1;
                player.fallDistance = 0;
            }
            case ActionPacket.MANTLE -> {
                if (!DeadRunnersConfig.SERVER.mantleEnabled.get()) return;
                // взбирание не должно приводить к урону от накопленного падения
                player.fallDistance = 0;
            }
            default -> { }
        }
    }

    /** Проверка запуска крюка: метка существует, в радиусе и в прямой видимости. */
    public static void onHook(ServerPlayer player, BlockPos pos) {
        if (!DeadRunnersConfig.serverReady() || !DeadRunnersConfig.SERVER.hookEnabled.get()) return;
        if (!player.isAlive() || player.isSpectator()) return;
        ServerLevel level = player.serverLevel();
        if (!level.isLoaded(pos) || !level.getBlockState(pos).is(com.deadrunners.ModBlocks.SPACE_MARK.get())) return;
        Vec3 eye = player.getEyePosition();
        Vec3 c = Vec3.atCenterOf(pos);
        double range = DeadRunnersConfig.SERVER.hookRange.get() + 2.5;
        if (eye.distanceToSqr(c) > range * range) return;
        if (level.clip(new ClipContext(eye, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player))
                .getType() == HitResult.Type.BLOCK) return;
        long now = level.getGameTime();
        State s = STATES.computeIfAbsent(player.getUUID(), id -> new State());
        if (now - s.lastHook < 2) return;
        s.lastHook = now;
        if (now <= s.trailUntil) {
            // крюк обрывает идущий рывок; неуязвимость остаётся до конца окна
            s.trailUntil = -1;
            s.thunderUntil = -1;
        }
        s.hookTarget = pos.immutable();
        s.hookUntil = now + 60;
        player.fallDistance = 0;
        playToOthers(player, ModSounds.HOOK_FIRE.get(), 0.8f, 1.0f);
        Net.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> player),
                new com.deadrunners.net.HookFxPacket(player.getId(), pos));
    }

    private static void playToOthers(ServerPlayer src, SoundEvent sound, float volume, float pitch) {
        // Level#playSound с первым аргументом-игроком не отправляет звук этому игроку
        src.serverLevel().playSound(src, src.getX(), src.getY(), src.getZ(),
                sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static void puffToOthers(ServerPlayer src, double x, double y, double z, int count, double spread) {
        ServerLevel level = src.serverLevel();
        for (ServerPlayer viewer : level.players()) {
            if (viewer == src || viewer.distanceToSqr(x, y, z) > 4096.0) continue;
            level.sendParticles(viewer, ModParticles.DASH_CLOUD.get(), false,
                    x, y, z, count, spread, spread, spread, 0.01);
        }
    }

    // ------------------------------------------------------------ тик игрока

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;

        // Голод отключён: сытость всегда полная, еда не тратится
        if (DeadRunnersConfig.serverReady() && DeadRunnersConfig.SERVER.disableHunger.get()) {
            FoodData food = player.getFoodData();
            if (food.getFoodLevel() != 20) food.setFoodLevel(20);
            if (food.getSaturationLevel() != 0.0f) food.setSaturation(0.0f);
            if (food.getExhaustionLevel() != 0.0f) food.setExhaustion(0.0f);
        }

        State s = STATES.get(player.getUUID());
        if (s == null || !DeadRunnersConfig.serverReady()) return;
        long now = player.serverLevel().getGameTime();
        if (now <= s.trailUntil) {
            player.fallDistance = 0;
            puffToOthers(player, player.getX(), player.getY() + player.getBbHeight() * 0.5, player.getZ(), 2, 0.2);
        } else if (now <= s.invulnUntil) {
            player.fallDistance = 0;
        }
        if (now <= s.trailUntil + 1) {
            scanParry(player);
        }
        if (s.thunderUntil >= 0) tickThunder(player, s, now);
    }

    /** Игрок сейчас в рывке (для сферы ветра). */
    public static boolean isDashing(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s != null && player.serverLevel().getGameTime() <= s.trailUntil + 1;
    }

    /** Мгновенно сбросить перезарядку рывка (клиенту отправляется уведомление). */
    public static void refreshDash(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s != null) s.lastDash = Long.MIN_VALUE / 2;
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ResetDashPacket());
    }

    // ------------------------------------------------------------------ Гром

    /** Игрок реально в воздухе (не на земле и не прямо над ней). */
    private static boolean isAirborne(ServerPlayer player) {
        return !player.onGround() && !player.isInWater() && !player.isInLava()
                && !player.getAbilities().flying && !player.isFallFlying() && !player.isPassenger()
                && player.level().noCollision(player, player.getBoundingBox().move(0.0, -0.6, 0.0));
    }

    private static void tickThunder(ServerPlayer player, State s, long now) {
        if (!player.isAlive() || now > s.thunderUntil || player.isInWater() || player.isInLava()
                || player.getAbilities().flying || player.isFallFlying() || player.isPassenger()) {
            s.thunderUntil = -1;
            return;
        }
        if (now > s.thunderStart && player.onGround()) {
            s.thunderUntil = -1;
            thunderSlam(player, s, now);
        }
    }

    /** Заряженный «Гром» гасит урон от падения. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !DeadRunnersConfig.serverReady()) return;
        State s = STATES.get(player.getUUID());
        if (s != null && s.thunderUntil >= 0 && DeadRunnersConfig.SERVER.thunderNoFallDamage.get()) {
            event.setDistance(0.0f);
            event.setCanceled(true);
        }
    }

    private static boolean canThunderHit(ServerPlayer owner, LivingEntity t) {
        if (t == owner || !t.isAlive() || t.isSpectator()) return false;
        if (t instanceof ArmorStand) return false;
        if (t instanceof Player other) return owner.canHarmPlayer(other);
        return !(t instanceof TamableAnimal pet && pet.isOwnedBy(owner));
    }

    private static boolean isGlass(BlockState st) {
        return st.is(Tags.Blocks.GLASS) || st.is(Tags.Blocks.GLASS_PANES) || st.is(Blocks.TINTED_GLASS);
    }

    private static void thunderSlam(ServerPlayer player, State s, long now) {
        var cfg = DeadRunnersConfig.SERVER;
        ServerLevel level = player.serverLevel();
        double x = player.getX(), y = player.getY(), z = player.getZ();
        player.fallDistance = 0;
        int cd = cfg.thunderCooldown.get();
        s.thunderReadyAt = now + cd;
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ThunderCdPacket(cd));

        // стекло 3x3 под игроком разбивается, игрок падает дальше (падение считается заново)
        if (cfg.thunderBreakGlass.get()) {
            int by = Mth.floor(player.getBoundingBox().minY - 0.2);
            int cx = Mth.floor(x), cz = Mth.floor(z);
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            for (int bx = cx - 1; bx <= cx + 1; bx++) {
                for (int bz = cz - 1; bz <= cz + 1; bz++) {
                    pos.set(bx, by, bz);
                    if (isGlass(level.getBlockState(pos)) && level.mayInteract(player, pos)) {
                        level.destroyBlock(pos, false, player);
                    }
                }
            }
        }

        // урон и отбрасывание: один запрос по ограниченной области, с потолком целей
        double r = cfg.thunderRadius.get();
        float dmg = cfg.thunderDamage.get().floatValue();
        double kb = cfg.thunderKnockback.get();
        int left = cfg.thunderMaxTargets.get();
        DamageSource src = player.damageSources().playerAttack(player);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(x - r, y - 1.0, z - r, x + r, y + 2.5, z + r), t -> canThunderHit(player, t))) {
            double dx = x - e.getX(), dz = z - e.getZ();
            double d2 = dx * dx + dz * dz;
            if (d2 > r * r) continue;
            double falloff = 1.0 - 0.5 * Math.sqrt(d2) / r;
            if (e instanceof ArmorStand) { // манекен туториала: крутится и сыпет искрами, без урона
                e.setYRot(e.getYRot() + 120.0f);
                level.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 1.0, e.getZ(), 8, 0.3, 0.5, 0.3, 0.2);
                if (--left <= 0) break;
                continue;
            }
            if (dmg > 0.0f) e.hurt(src, dmg);
            if (e.isAlive()) {
                e.knockback(kb * falloff, dx, dz);
                e.hurtMarked = true;
            }
            if (--left <= 0) break;
        }

        // три расходящихся волны (одна частица на волну: клиент рисует кольцо сам) и немного пыли
        for (int i = 0; i < 3; i++) {
            level.sendParticles(ModParticles.SHOCKWAVE.get(), x, y + 0.03, z, 0, i * 3.0, r * (1.0 - 0.2 * i), 0.0, 1.0);
        }
        level.sendParticles(ModParticles.DASH_CLOUD.get(), x, y + 0.15, z, 14, 0.9, 0.05, 0.9, 0.04);
        level.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.7f, 1.25f);
        level.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.3f, 0.75f);
    }

    // ------------------------------------------------------------ парирование

    private static boolean inParryWindow(ServerPlayer player) {
        if (!DeadRunnersConfig.serverReady() || !DeadRunnersConfig.SERVER.parryEnabled.get()) return false;
        State s = STATES.get(player.getUUID());
        return s != null && player.serverLevel().getGameTime() <= s.trailUntil + 1;
    }

    /** Ловим снаряды, оказавшиеся рядом с игроком во время рывка. */
    private static void scanParry(ServerPlayer player) {
        if (!DeadRunnersConfig.SERVER.parryEnabled.get()) return;
        double r = DeadRunnersConfig.SERVER.parryRadius.get();
        AABB box = player.getBoundingBox().inflate(r);
        int left = 8; // потолок отражений за тик: защита от лагов на ловушках
        for (Projectile proj : player.serverLevel().getEntitiesOfClass(Projectile.class, box)) {
            Vec3 motion = proj.getDeltaMovement();
            if (motion.lengthSqr() < 0.04) continue; // застрявшие или падающие без скорости
            if (tryParry(player, proj, motion.length()) && --left <= 0) break;
        }
    }

    private static boolean tryParry(ServerPlayer player, Projectile proj, double speed) {
        if (!proj.isAlive() || proj instanceof FishingHook || proj instanceof FireworkRocketEntity) return false;
        CompoundTag data = proj.getPersistentData();
        // Нельзя отразить снаряд, который уже отразил этот же игрок
        if (data.hasUUID(TAG_PARRY_BY) && data.getUUID(TAG_PARRY_BY).equals(player.getUUID())) return false;
        Entity owner = proj.getOwner();
        // и собственный свежий снаряд тоже
        if (owner == player) return false;

        var cfg = DeadRunnersConfig.SERVER;
        Vec3 dir = player.getLookAngle();
        Entity target = cfg.parryHoming.get() ? pickTarget(player, proj, owner) : null;
        if (target != null) {
            Vec3 toTarget = target.getBoundingBox().getCenter().subtract(proj.position());
            if (toTarget.lengthSqr() > 1.0E-6) dir = toTarget.normalize();
        } else if (cfg.parryTowardOwner.get() && owner != null && owner.isAlive() && owner.level() == proj.level()) {
            Vec3 toOwner = owner.getBoundingBox().getCenter().subtract(proj.position());
            if (toOwner.lengthSqr() > 1.0E-6) dir = toOwner.normalize();
        }

        double newSpeed = Math.max(speed * cfg.parrySpeedMultiplier.get(), cfg.parryMinSpeed.get());
        if (target != null) newSpeed = Math.max(newSpeed, cfg.parryHomingSpeed.get());
        proj.setOwner(player);
        data.putUUID(TAG_PARRY_BY, player.getUUID());
        // чуть отодвигаем снаряд по новому курсу, чтобы он сразу не попал обратно в игрока
        proj.setPos(proj.position().add(dir.scale(0.8)));
        proj.shoot(dir.x, dir.y, dir.z, (float) newSpeed, 0.0f);
        if (proj instanceof AbstractHurtingProjectile hurting) {
            // огненные шары и черепа разгоняются по своей «силе» - разворачиваем и её
            hurting.xPower = dir.x * 0.1;
            hurting.yPower = dir.y * 0.1;
            hurting.zPower = dir.z * 0.1;
        }
        proj.hurtMarked = true; // отправить новую скорость клиентам

        HOMING.removeIf(h -> h.proj == proj);
        if (target != null) {
            proj.setNoGravity(true);
            if (HOMING.size() >= MAX_HOMING) HOMING.remove(0);
            HOMING.add(new Homing(proj, target, newSpeed, cfg.parryHomingTicks.get(), dir));
        }

        ServerLevel level = player.serverLevel();
        level.playSound(null, proj.getX(), proj.getY(), proj.getZ(),
                ModSounds.PARRY.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        level.sendParticles(ParticleTypes.END_ROD, proj.getX(), proj.getY(), proj.getZ(),
                8, 0.2, 0.2, 0.2, 0.05);
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!PENDING.isEmpty()) {
            List<Pending> copy = new ArrayList<>(PENDING);
            PENDING.clear();
            for (Pending p : copy) {
                if (p.player().isAlive()) tryParry(p.player(), p.projectile(), p.speed());
            }
        }
        if (!HOMING.isEmpty()) tickHoming();
        com.deadrunners.CheckpointData.tickDelayed();
    }

    // ------------------------------------------------- самонаведение снаряда

    /** Куда лететь отражённому снаряду: прошлый владелец, иначе ближайший враг по взгляду игрока. */
    private static Entity pickTarget(ServerPlayer player, Projectile proj, Entity owner) {
        var cfg = DeadRunnersConfig.SERVER;
        if (cfg.parryTowardOwner.get() && owner instanceof LivingEntity lo && lo != player
                && lo.isAlive() && lo.level() == proj.level()) {
            return lo;
        }
        double range = cfg.parryHomingRange.get();
        Vec3 look = player.getLookAngle();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : proj.level().getEntitiesOfClass(LivingEntity.class,
                proj.getBoundingBox().inflate(range),
                t -> t != player && t.isAlive() && !t.isSpectator() && t instanceof Enemy)) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(proj.position());
            double d = to.length();
            if (d < 1.0E-3) continue;
            double score = (1.0 - look.dot(to) / d) * 8.0 + d / range;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private static void tickHoming() {
        var cfg = DeadRunnersConfig.SERVER;
        double maxTurn = Math.toRadians(cfg.parryHomingTurn.get());
        Iterator<Homing> it = HOMING.iterator();
        while (it.hasNext()) {
            Homing h = it.next();
            Projectile p = h.proj;
            if (!p.isAlive() || p.isRemoved() || !h.target.isAlive()
                    || h.target.level() != p.level() || --h.ticksLeft < 0
                    || p.getDeltaMovement().lengthSqr() < 0.01) { // воткнулся / остановился
                it.remove();
                continue;
            }
            Level level = p.level();
            Vec3 pos = p.position();
            Vec3 to = h.target.getBoundingBox().getCenter().subtract(pos);
            double dist = to.length();
            if (dist < 1.0E-3) {
                it.remove();
                continue;
            }
            Vec3 desired = to.scale(1.0 / dist);
            double look = Math.min(dist, h.speed * 2.5 + 1.0);

            Vec3 nd;
            if (clear(level, p, pos, desired, look)) {
                h.stuck = 0;
                // рядом с целью - доворачиваем мгновенно, чтобы точно попасть
                nd = dist <= h.speed * 1.6 ? desired : rotateToward(h.dir, desired, maxTurn);
            } else {
                // цель за стеной: ищем свободное направление, максимально близкое к прямому, и огибаем
                Vec3 way = detour(level, p, pos, desired, h.dir, look);
                if (way == null) {
                    if (++h.stuck > 10) {
                        it.remove();
                        continue;
                    }
                    way = desired;
                } else {
                    h.stuck = 0;
                }
                nd = rotateToward(h.dir, way, maxTurn * 1.8);
            }

            h.dir = nd;
            p.setDeltaMovement(nd.scale(h.speed));
            if (p instanceof AbstractHurtingProjectile hurting) {
                hurting.xPower = nd.x * h.speed * 0.0526;
                hurting.yPower = nd.y * h.speed * 0.0526;
                hurting.zPower = nd.z * h.speed * 0.0526;
            }
            p.hurtMarked = true;
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY(), p.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    /** Свободен ли путь на длину len (проверяем центральный луч и четыре по краям хитбокса). */
    private static boolean clear(Level level, Projectile p, Vec3 from, Vec3 dir, double len) {
        return rayClear(level, p, from, dir, len) && edgesClear(level, p, from, dir, len);
    }

    private static boolean rayClear(Level level, Projectile p, Vec3 from, Vec3 dir, double len) {
        return level.clip(new ClipContext(from, from.add(dir.scale(len)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    /** Четыре луча по краям хитбокса (центральный уже проверен в rayClear). */
    private static boolean edgesClear(Level level, Projectile p, Vec3 from, Vec3 dir, double len) {
        Vec3 to = from.add(dir.scale(len));
        Vec3 ref = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 r = dir.cross(ref).normalize().scale(0.25);
        Vec3 u = dir.cross(r).normalize().scale(0.25);
        Vec3[] offsets = {r, r.reverse(), u, u.reverse()};
        for (Vec3 o : offsets) {
            BlockHitResult hit = level.clip(new ClipContext(from.add(o), to.add(o),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) return false;
        }
        return true;
    }

    /** Ближайшее к desired свободное направление (кольцами вокруг desired); среди равных - ближе к текущему курсу. */
    private static Vec3 detour(Level level, Projectile p, Vec3 pos, Vec3 desired, Vec3 cur, double len) {
        Vec3 ref = Math.abs(desired.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = desired.cross(ref).normalize();
        Vec3 up = right.cross(desired).normalize();
        double[] rings = {12, 25, 40, 55, 70, 90, 110, 130, 155, 180};
        for (double deg : rings) {
            double th = Math.toRadians(deg);
            Vec3 best = null;
            double bestDot = -2.0;
            for (int k = 0; k < 8; k++) {
                double phi = k * Math.PI / 4.0;
                Vec3 d = desired.scale(Math.cos(th))
                        .add(right.scale(Math.cos(phi) * Math.sin(th)))
                        .add(up.scale(Math.sin(phi) * Math.sin(th)))
                        .normalize();
                double dot = d.dot(cur);
                if (dot <= bestDot) continue; // не лучше уже найденного - лучи не тратим
                if (!rayClear(level, p, pos, d, len) || !edgesClear(level, p, pos, d, len)) continue;
                if (dot > bestDot) {
                    bestDot = dot;
                    best = d;
                }
            }
            if (best != null) return best;
        }
        return null;
    }

    /** Поворот вектора from в сторону to не более чем на maxRad радиан. */
    private static Vec3 rotateToward(Vec3 from, Vec3 to, double maxRad) {
        double dot = Mth.clamp(from.dot(to), -1.0, 1.0);
        double ang = Math.acos(dot);
        if (ang <= maxRad) return to;
        Vec3 perp = to.subtract(from.scale(dot));
        if (perp.lengthSqr() < 1.0E-8) {
            perp = from.cross(Math.abs(from.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0));
        }
        perp = perp.normalize();
        return from.scale(Math.cos(maxRad)).add(perp.scale(Math.sin(maxRad))).normalize();
    }


    // ------------------------------------------------------- неуязвимость

    private static boolean shouldBlock(LivingEntity entity, DamageSource source) {
        if (!(entity instanceof ServerPlayer player)) return false;
        if (!DeadRunnersConfig.serverReady() || !DeadRunnersConfig.SERVER.dashInvulnerable.get()) return false;
        State s = STATES.get(player.getUUID());
        if (s == null || player.serverLevel().getGameTime() > s.invulnUntil) return false;
        // void и /kill не блокируем, чтобы нельзя было застрять
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttack(LivingAttackEvent event) {
        // Снаряд попал в игрока в рывке: отразим его в конце тика
        if (event.getEntity() instanceof ServerPlayer player
                && event.getSource().getDirectEntity() instanceof Projectile proj
                && inParryWindow(player)) {
            PENDING.add(new Pending(player, proj, proj.getDeltaMovement().length()));
        }
        if (shouldBlock(event.getEntity(), event.getSource())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onHurt(LivingHurtEvent event) {
        if (shouldBlock(event.getEntity(), event.getSource())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onDamage(LivingDamageEvent event) {
        if (shouldBlock(event.getEntity(), event.getSource())) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        STATES.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) com.deadrunners.CheckpointData.flush(sp);
        STATES.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopping(net.minecraftforge.event.server.ServerStoppingEvent event) {
        com.deadrunners.CheckpointData.flushAll();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        STATES.clear();
        PENDING.clear();
        HOMING.clear();
        com.deadrunners.CheckpointData.clearDelayed();
    }
}
