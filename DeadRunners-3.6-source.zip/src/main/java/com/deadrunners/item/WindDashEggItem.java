package com.deadrunners.item;

import com.deadrunners.ModEntities;
import com.deadrunners.entity.WindDashEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;

/** Яйцо призыва сферы ветра. */
public class WindDashEggItem extends Item {
    public static final int COLOR_MAIN = 0x7FE8FF;
    public static final int COLOR_SPOT = 0xFFFFFF;

    public WindDashEggItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        WindDashEntity e = ModEntities.WIND_DASH.get().create(level);
        if (e == null) return InteractionResult.FAIL;
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0f, 0.0f);
        level.addFreshEntity(e);
        level.gameEvent(ctx.getPlayer(), GameEvent.ENTITY_PLACE, pos);
        if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
