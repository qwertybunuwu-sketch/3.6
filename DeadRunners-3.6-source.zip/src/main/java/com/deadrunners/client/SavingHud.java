package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.DeadRunnersMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Правый нижний угол: значок кассеты и «Saving...», затем «Saved!»; значок и надпись плавно гаснут вместе. */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, value = Dist.CLIENT)
public final class SavingHud {
    private static final ResourceLocation ICON =
            new ResourceLocation(DeadRunnersMod.MODID, "textures/block/checkpoint_star.png");
    /** Сколько тиков идёт «Saving...», сколько держится «Saved!» и сколько длится затухание. */
    private static final int SAVING = 24;
    private static final int DONE = 24;
    private static final int FADE = 24;
    private static final int TOTAL = SAVING + DONE + FADE;
    private static int age = TOTAL;

    private SavingHud() {}

    public static void start() {
        age = 0;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || age >= TOTAL) return;
        if (!Minecraft.getInstance().isPaused()) age++;
    }

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        if (age >= TOTAL || !DeadRunnersConfig.CLIENT.savingIndicator.get()) return;
        float t = age + partialTick;
        float a = t < SAVING + DONE ? 1.0f : Mth.clamp(1.0f - (t - SAVING - DONE) / FADE, 0.0f, 1.0f);
        int alpha = Math.round(a * 255.0f);
        if (alpha < 6) return;
        Minecraft mc = Minecraft.getInstance();

        boolean saving = age < SAVING;
        String text = saving
                ? Component.translatable("deadrunners.saving").getString() + ".".repeat(1 + (age / 4) % 3)
                : Component.translatable("deadrunners.saved").getString();
        int tw = mc.font.width(text);
        int x = width - 12 - 16;
        int y = height - 12 - 16;
        // значок покачивается, пока идёт сохранение; потом замирает
        int bob = saving ? Math.round(Mth.sin(t * 0.5f) * 1.0f) : 0;
        RenderSystem.enableBlend();
        g.setColor(1.0f, 1.0f, 1.0f, a);
        g.blit(ICON, x, y + bob, 0.0f, 0.0f, 16, 16, 16, 16);
        g.setColor(1.0f, 1.0f, 1.0f, 1.0f);
        g.drawString(mc.font, text, x - 6 - tw, y + 4, (alpha << 24) | 0xFFFFFF, true);
    }
}
