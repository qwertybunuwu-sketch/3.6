package com.deadrunners.net;

import com.deadrunners.server.ServerHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: игрок запустил крюк в метку пространства. */
public record HookPacket(BlockPos pos) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeBlockPos(pos);
    }

    public static HookPacket decode(FriendlyByteBuf buf) {
        return new HookPacket(buf.readBlockPos());
    }

    public static void handle(HookPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) ServerHandler.onHook(player, packet.pos());
        });
        ctx.setPacketHandled(true);
    }
}
