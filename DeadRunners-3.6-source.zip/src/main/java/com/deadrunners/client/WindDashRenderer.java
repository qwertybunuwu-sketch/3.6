package com.deadrunners.client;

import com.deadrunners.DeadRunnersMod;
import com.deadrunners.entity.WindDashEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Светящийся вращающийся кубик и два воздушных кольца вокруг него. Всего 4 небольших квадрата-группы. */
public class WindDashRenderer<T extends WindDashEntity> extends EntityRenderer<T> {
    private static final ResourceLocation WIND_CUBE = new ResourceLocation(DeadRunnersMod.MODID, "textures/entity/wind_dash.png");
    public static final ResourceLocation LIFE_CUBE = new ResourceLocation(DeadRunnersMod.MODID, "textures/entity/life_essence.png");
    private static final ResourceLocation RING = new ResourceLocation(DeadRunnersMod.MODID, "textures/particle/shockwave.png");
    private static final int LIGHT = 0xF000F0;

    private final ResourceLocation cube;
    private final float cr;
    private final float cg;
    private final float cb;

    public WindDashRenderer(EntityRendererProvider.Context ctx) {
        this(ctx, WIND_CUBE, 0.85f, 0.94f, 1.0f);
    }

    public WindDashRenderer(EntityRendererProvider.Context ctx, ResourceLocation cube, float r, float g, float b) {
        super(ctx);
        this.shadowRadius = 0.0f;
        this.cube = cube;
        this.cr = r;
        this.cg = g;
        this.cb = b;
    }

    @Override
    public ResourceLocation getTextureLocation(T e) {
        return cube;
    }

    @Override
    public void render(T e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        if (!e.isActive()) return;
        float t = e.tickCount + partial;
        ps.pushPose();
        ps.translate(0.0, 0.3 + Mth.sin(t * 0.1f) * 0.05, 0.0);

        // кубик
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(t * 6.0f));
        ps.mulPose(Axis.XP.rotationDegrees(t * 3.0f));
        VertexConsumer c = buf.getBuffer(RenderType.entityTranslucent(cube));
        float h = 0.15f;
        for (int s = -1; s <= 1; s += 2) {
            face(ps, c, s * h, 0, 0, 0, h, 0, 0, 0, h, 0.9f);
            face(ps, c, 0, s * h, 0, h, 0, 0, 0, 0, h, 0.9f);
            face(ps, c, 0, 0, s * h, h, 0, 0, 0, h, 0, 0.9f);
        }
        ps.popPose();

        // кольца
        VertexConsumer r = buf.getBuffer(RenderType.entityTranslucent(RING));
        float pulse = 1.0f + Mth.sin(t * 0.25f) * 0.1f;
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(t * 8.0f));
        ps.mulPose(Axis.XP.rotationDegrees(28.0f));
        float s1 = 0.55f * pulse;
        face(ps, r, 0, 0, 0, s1, 0, 0, 0, 0, s1, 0.85f);
        ps.popPose();
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(-t * 6.0f));
        ps.mulPose(Axis.ZP.rotationDegrees(28.0f));
        float s2 = 0.42f * pulse;
        face(ps, r, 0, 0, 0, s2, 0, 0, 0, 0, s2, 0.7f);
        ps.popPose();

        ps.popPose();
    }

    /** Квадрат с центром a и полуосями u, v. */
    private void face(PoseStack ps, VertexConsumer b, float ax, float ay, float az,
                             float ux, float uy, float uz, float vx, float vy, float vz, float alpha) {
        var pose = ps.last();
        vtx(pose, b, ax - ux - vx, ay - uy - vy, az - uz - vz, 0, 0, alpha);
        vtx(pose, b, ax + ux - vx, ay + uy - vy, az + uz - vz, 1, 0, alpha);
        vtx(pose, b, ax + ux + vx, ay + uy + vy, az + uz + vz, 1, 1, alpha);
        vtx(pose, b, ax - ux + vx, ay - uy + vy, az - uz + vz, 0, 1, alpha);
    }

    private void vtx(PoseStack.Pose pose, VertexConsumer b, float x, float y, float z, float u, float v, float a) {
        b.vertex(pose.pose(), x, y, z).color(cr, cg, cb, a).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LIGHT).normal(pose.normal(), 0.0f, 1.0f, 0.0f).endVertex();
    }
}
