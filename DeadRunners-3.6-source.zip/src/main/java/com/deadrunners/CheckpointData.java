package com.deadrunners;

import com.deadrunners.net.CheckpointSyncPacket;
import com.deadrunners.net.Net;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Одна точка возрождения на игрока: измерение, координаты, поворот и позиция звезды. Хранится в мире. */
public class CheckpointData extends SavedData {
    private static final String NAME = "deadrunners_checkpoints";

    public record Entry(ResourceKey<Level> dim, double x, double y, double z, float yRot, float xRot, BlockPos star) {}

    private final Map<UUID, Entry> map = new HashMap<>();

    public static CheckpointData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(CheckpointData::load, CheckpointData::new, NAME);
    }

    public Entry getEntry(UUID id) {
        return map.get(id);
    }

    // ------------------------------------------------------------- действия

    /** Тиков до второй части звука (0.65 с), в момент которой происходит само сохранение. */
    private static final int SAVE_DELAY = 13;

    private static final class Delayed {
        final ServerPlayer player;
        final Entry snapshot;
        int left = SAVE_DELAY;

        Delayed(ServerPlayer player, Entry snapshot) {
            this.player = player;
            this.snapshot = snapshot;
        }
    }

    private static final Map<UUID, Delayed> DELAYED = new HashMap<>();

    /** Клик по кассете: сразу играет звук, позиция запоминается, сохранение случится на второй части звука. */
    public static void saveFor(ServerPlayer p, BlockPos star) {
        if (DELAYED.containsKey(p.getUUID())) return;
        DELAYED.put(p.getUUID(), new Delayed(p, new Entry(p.level().dimension(), p.getX(), p.getY(), p.getZ(),
                p.getYRot(), p.getXRot(), star.immutable())));
        p.serverLevel().playSound(null, star, ModSounds.CHECKPOINT_SAVE.get(), SoundSource.BLOCKS, 1.0f, 1.0f);
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new com.deadrunners.net.SavingPacket());
    }

    /** Вызывать каждый тик сервера. */
    public static void tickDelayed() {
        if (DELAYED.isEmpty()) return;
        var it = DELAYED.values().iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (--d.left > 0) continue;
            it.remove();
            ServerPlayer p = d.player;
            if (!p.isAlive()) continue;
            if (!p.serverLevel().getBlockState(d.snapshot.star()).is(ModBlocks.CHECKPOINT_STAR.get())) continue;
            commit(p, d.snapshot);
        }
    }

    /** Игрок вышел из игры или сервер останавливается: сохранить сразу, без сообщений и частиц. */
    public static void flush(ServerPlayer p) {
        Delayed d = DELAYED.remove(p.getUUID());
        if (d == null || !p.isAlive()) return;
        CheckpointData data = get(p.server);
        data.map.put(p.getUUID(), d.snapshot);
        data.setDirty();
    }

    public static void flushAll() {
        for (Delayed d : java.util.List.copyOf(DELAYED.values())) flush(d.player);
    }

    public static void clearDelayed() {
        DELAYED.clear();
    }

    private static void commit(ServerPlayer p, Entry e) {
        CheckpointData d = get(p.server);
        BlockPos star = e.star();
        d.map.put(p.getUUID(), e);
        d.setDirty();
        if (p.hasDisconnected()) return;
        com.deadrunners.server.LifeManager.healFull(p);
        sync(p);
        ServerLevel level = p.serverLevel();
        level.sendParticles(ParticleTypes.END_ROD, star.getX() + 0.5, star.getY() + 0.6, star.getZ() + 0.5,
                14, 0.3, 0.3, 0.3, 0.05);
    }

    /** Кассета уничтожена: у всех игроков, привязанных к ней, чекпоинт пропадает (офлайн-игроки узнают при входе). */
    public static void onStarRemoved(ServerLevel level, BlockPos pos) {
        CheckpointData d = get(level.getServer());
        java.util.List<UUID> gone = new java.util.ArrayList<>();
        for (Map.Entry<UUID, Entry> me : d.map.entrySet()) {
            Entry e = me.getValue();
            if (e.dim().equals(level.dimension()) && e.star().equals(pos)) gone.add(me.getKey());
        }
        if (gone.isEmpty()) return;
        for (UUID id : gone) d.map.remove(id);
        d.setDirty();
        for (UUID id : gone) {
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(id);
            if (p == null) continue;
            sync(p);
            p.sendSystemMessage(Component.translatable("deadrunners.checkpoint.cleared"));
        }
    }

    public static boolean clear(ServerPlayer p) {
        CheckpointData d = get(p.server);
        boolean had = d.map.remove(p.getUUID()) != null;
        if (had) d.setDirty();
        sync(p);
        p.sendSystemMessage(Component.translatable(had ? "deadrunners.checkpoint.cleared" : "deadrunners.checkpoint.none"));
        if (had) {
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_BREAK,
                    SoundSource.PLAYERS, 1.0f, 0.8f);
        }
        return had;
    }

    /** Отправить клиенту, какая звезда активна (для подсветки). */
    public static void sync(ServerPlayer p) {
        Entry e = get(p.server).map.get(p.getUUID());
        CheckpointSyncPacket pkt = e == null ? new CheckpointSyncPacket(false, new ResourceLocation("minecraft:overworld"), BlockPos.ZERO)
                : new CheckpointSyncPacket(true, e.dim().location(), e.star());
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }

    public static Vec3 pos(Entry e) {
        return new Vec3(e.x(), e.y(), e.z());
    }

    // ------------------------------------------------------------- NBT

    public static CheckpointData load(CompoundTag tag) {
        CheckpointData d = new CheckpointData();
        ListTag list = tag.getList("list", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            if (!t.hasUUID("id")) continue;
            ResourceLocation rl = ResourceLocation.tryParse(t.getString("dim"));
            if (rl == null) continue;
            d.map.put(t.getUUID("id"), new Entry(ResourceKey.create(Registries.DIMENSION, rl),
                    t.getDouble("x"), t.getDouble("y"), t.getDouble("z"), t.getFloat("yr"), t.getFloat("xr"),
                    NbtUtils.readBlockPos(t.getCompound("star"))));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Entry> me : map.entrySet()) {
            Entry e = me.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("id", me.getKey());
            t.putString("dim", e.dim().location().toString());
            t.putDouble("x", e.x());
            t.putDouble("y", e.y());
            t.putDouble("z", e.z());
            t.putFloat("yr", e.yRot());
            t.putFloat("xr", e.xRot());
            t.put("star", NbtUtils.writeBlockPos(e.star()));
            list.add(t);
        }
        tag.put("list", list);
        return tag;
    }
}
