package com.deadrunners.entity;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.ModSounds;
import com.deadrunners.server.LifeManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Эссенция жизни: «глоток» лечит одну ячейку, затем долго восстанавливается. Если лечить нечего, не тратится. */
public class LifeEssenceEntity extends WindDashEntity {
    public LifeEssenceEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    @Override
    protected boolean onTouch(ServerPlayer p) {
        return LifeManager.healCell(p);
    }

    @Override
    protected int respawnTicks() {
        return DeadRunnersConfig.SERVER.lifeEssenceRespawn.get();
    }

    @Override
    protected void touchFx(ServerLevel sl) {
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.READY.get(), SoundSource.PLAYERS, 1.0f, 1.7f);
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.3, getZ(), 12, 0.3, 0.3, 0.3, 0.02);
    }
}
