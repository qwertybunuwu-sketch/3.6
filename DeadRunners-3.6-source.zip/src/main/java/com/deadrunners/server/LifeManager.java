package com.deadrunners.server;

import com.deadrunners.DeadRunnersConfig;
import com.deadrunners.DeadRunnersMod;
import com.deadrunners.net.LifeSyncPacket;
import com.deadrunners.net.Net;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Система жизней: мало ячеек здоровья, один удар = одна ячейка.
 * Пустота, лава, /kill и огромный урон убивают сразу. Огонь поджигает одну ячейку: она выгорает
 * и оставляет ожог, пока он держится, ячейку не лечит ничто, кроме чекпоинта.
 * Лечение: чекпоинт, эссенция жизни, медленная естественная регенерация.
 */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID)
public final class LifeManager {
    private static final UUID LIFE_ID = UUID.fromString("5d0b6a14-8f0e-4c1b-9f43-1c6f7d3a2e91");
    private static final int MAX_CELLS = 20;
    /** После выгорания ячейки новый огонь не поджигает следующую ячейку ещё столько тиков. */
    private static final int BURN_GRACE = 30;

    private static final Map<UUID, Life> LIFE = new HashMap<>();

    private static final class Life {
        int burnLeft;
        int burnTotal;
        int grace;
        int regen;
        int scars;
        final int[] scar = new int[MAX_CELLS];
        boolean internal;
        float internalAmount;
    }

    private LifeManager() {}

    private static Life life(ServerPlayer p) {
        return LIFE.computeIfAbsent(p.getUUID(), id -> new Life());
    }

    private static boolean enabled() {
        return DeadRunnersConfig.serverReady() && DeadRunnersConfig.SERVER.lifeEnabled.get();
    }

    private static void sync(ServerPlayer p, Life l) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new LifeSyncPacket(l.burnLeft, l.burnTotal, l.scars));
    }

    // ------------------------------------------------------------- максимум здоровья

    /** Максимум здоровья задаётся постоянным модификатором; проверка дешёвая (чтение атрибута). */
    private static void applyAttribute(ServerPlayer player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        AttributeModifier mod = attr.getModifier(LIFE_ID);
        if (!DeadRunnersConfig.SERVER.lifeEnabled.get()) {
            if (mod != null) attr.removeModifier(LIFE_ID);
            return;
        }
        double want = DeadRunnersConfig.SERVER.lifeMaxHealth.get() - attr.getBaseValue();
        if (mod == null || Math.abs(mod.getAmount() - want) > 1.0E-6) {
            boolean fresh = mod == null;
            if (mod != null) attr.removeModifier(LIFE_ID);
            attr.addPermanentModifier(new AttributeModifier(LIFE_ID, "deadrunners_life", want,
                    AttributeModifier.Operation.ADDITION));
            if (fresh && player.isAlive()) player.setHealth(player.getMaxHealth());
        }
        if (player.getHealth() > player.getMaxHealth()) player.setHealth(player.getMaxHealth());
    }

    // ------------------------------------------------------------------- лечение

    /** Чекпоинт: полное лечение, ожоги и горение снимаются. */
    public static void healFull(ServerPlayer player) {
        if (!player.isAlive()) return;
        player.setHealth(player.getMaxHealth());
        if (!enabled()) return;
        Life l = life(player);
        l.burnLeft = 0;
        l.burnTotal = 0;
        l.grace = 0;
        l.scars = 0;
        l.regen = 0;
        player.clearFire();
        sync(player, l);
    }

    /** Эссенция жизни: +1 ячейка (кроме выжженных ожогом). false - лечить нечего. */
    public static boolean healCell(ServerPlayer player) {
        if (!player.isAlive()) return false;
        float cap = Mth.floor(player.getMaxHealth());
        Life l = null;
        if (enabled()) {
            l = life(player);
            cap -= l.scars;
        }
        if (player.getHealth() >= cap) return false;
        player.setHealth(Math.min(player.getHealth() + 1.0f, cap));
        if (l != null) l.regen = 0;
        return true;
    }

    /** Лечат только наши источники: чекпоинт, эссенция и медленная регенерация. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onHeal(LivingHealEvent event) {
        if (event.getEntity() instanceof ServerPlayer && enabled()) event.setCanceled(true);
    }

    // ---------------------------------------------------------------------- тик

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        if (!DeadRunnersConfig.serverReady()) return;
        applyAttribute(player);
        if (!DeadRunnersConfig.SERVER.lifeEnabled.get() || !player.isAlive() || player.isSpectator()) return;

        Life l = life(player);
        boolean changed = false;
        if (l.burnLeft > 0 && --l.burnLeft == 0) {
            burnOut(player, l);
            changed = true;
        }
        if (l.grace > 0) l.grace--;
        for (int i = l.scars - 1; i >= 0; i--) {
            if (--l.scar[i] <= 0) {
                System.arraycopy(l.scar, i + 1, l.scar, i, l.scars - i - 1);
                l.scars--;
                changed = true;
            }
        }
        if (changed) sync(player, l);
        if (!player.isAlive()) return;

        // медленная естественная регенерация: одна ячейка за regenTicks, пока ничего не горит
        float cap = Mth.floor(player.getMaxHealth()) - l.scars;
        if (l.burnLeft == 0 && player.getHealth() < cap) {
            if (++l.regen >= DeadRunnersConfig.SERVER.lifeRegenTicks.get()) {
                l.regen = 0;
                player.setHealth(Math.min(player.getHealth() + 1.0f, cap));
            }
        } else {
            l.regen = 0;
        }
    }

    private static void startBurn(ServerPlayer player, Life l) {
        if (l.burnLeft > 0 || l.grace > 0) return;
        l.burnTotal = DeadRunnersConfig.SERVER.lifeBurnTicks.get();
        l.burnLeft = l.burnTotal;
        sync(player, l);
    }

    /** Горящая ячейка выгорела: минус одна ячейка и ожог на её месте. */
    private static void burnOut(ServerPlayer player, Life l) {
        l.burnTotal = 0;
        l.grace = BURN_GRACE;
        boolean lost = loseCell(player, l);
        if (lost && player.isAlive() && l.scars < MAX_CELLS) {
            l.scar[l.scars++] = DeadRunnersConfig.SERVER.lifeScarTicks.get();
        }
        player.clearFire();
    }

    /** Снять одну ячейку (если она последняя, игрок умирает). Возвращает, получилось ли. */
    private static boolean loseCell(ServerPlayer player, Life l) {
        boolean lethal = player.getHealth() - 1.0f <= 0.0f;
        l.internal = true;
        l.internalAmount = lethal ? 1000.0f : 1.0f;
        try {
            boolean hit = player.hurt(player.damageSources().onFire(), l.internalAmount);
            if (!hit && !lethal) {
                // кадры неуязвимости съели удар: снимаем ячейку напрямую
                player.setHealth(player.getHealth() - 1.0f);
                hit = true;
            }
            return hit;
        } finally {
            l.internal = false;
        }
    }

    // --------------------------------------------------------------------- урон

    /** Пустота, лава, /kill и огромный урон убивают сразу; огонь поджигает ячейку; остальное - 1 или 2 ячейки. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !enabled()) return;
        Life l = life(player);
        if (l.internal) {
            event.setAmount(l.internalAmount);
            return;
        }
        float dmg = event.getAmount();
        if (dmg <= 0.0f) return;
        DamageSource src = event.getSource();
        if (src.is(DamageTypes.FELL_OUT_OF_WORLD) || src.is(DamageTypes.GENERIC_KILL) || src.is(DamageTypes.LAVA)
                || dmg >= DeadRunnersConfig.SERVER.lifeInstaKill.get().floatValue()) {
            event.setAmount(player.getMaxHealth() + player.getAbsorptionAmount() + 100.0f);
            return;
        }
        if (src.is(DamageTypeTags.IS_FIRE)) {
            // огонь не бьёт по здоровью напрямую: загорается одна ячейка
            event.setCanceled(true);
            startBurn(player, l);
            return;
        }
        l.regen = 0;
        event.setAmount(dmg >= DeadRunnersConfig.SERVER.lifeHeavyHit.get().floatValue() ? 2.0f : 1.0f);
    }

    // ------------------------------------------------------------ жизненный цикл

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) LIFE.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            LIFE.remove(p.getUUID());
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new LifeSyncPacket(0, 0, 0));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            LIFE.remove(p.getUUID());
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new LifeSyncPacket(0, 0, 0));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        LIFE.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        LIFE.clear();
    }
}
