package com.deadrunners;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DeadRunnersMod.MODID);

    public static final RegistryObject<SoundEvent> DASH = reg("dash");
    public static final RegistryObject<SoundEvent> BOUNCE = reg("bounce");
    public static final RegistryObject<SoundEvent> DOUBLE_JUMP = reg("double_jump");
    public static final RegistryObject<SoundEvent> READY = reg("ready");
    public static final RegistryObject<SoundEvent> PARRY = reg("parry");
    public static final RegistryObject<SoundEvent> DEATH = reg("death");
    public static final RegistryObject<SoundEvent> CHECKPOINT_SAVE = reg("checkpoint_save");

    public static final RegistryObject<SoundEvent> HOOK_FIRE = reg("hook_fire");
    public static final RegistryObject<SoundEvent> HOOK_HIT = reg("hook_hit");
    public static final RegistryObject<SoundEvent> HOOK_PULL = reg("hook_pull");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(DeadRunnersMod.MODID, name)));
    }
}
