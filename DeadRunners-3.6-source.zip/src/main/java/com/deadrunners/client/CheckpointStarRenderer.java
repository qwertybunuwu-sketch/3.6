package com.deadrunners.client;

import com.deadrunners.CheckpointClient;
import com.deadrunners.ModItems;
import com.deadrunners.block.CheckpointStarBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Дискета, вращающаяся и покачивающаяся в воздухе над блоком. Без аллокаций на кадр. */
public class CheckpointStarRenderer implements BlockEntityRenderer<CheckpointStarBlockEntity> {
    private final ItemRenderer items;
    private final ItemStack stack = new ItemStack(ModItems.CHECKPOINT_STAR.get());

    public CheckpointStarRenderer(BlockEntityRendererProvider.Context ctx) {
        this.items = ctx.getItemRenderer();
    }

    @Override
    public void render(CheckpointStarBlockEntity be, float partial, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        float time = level.getGameTime() + partial;
        boolean active = CheckpointClient.isActive(level.dimension(), be.getBlockPos());
        pose.pushPose();
        pose.translate(0.5, 0.5 + Mth.sin(time * 0.1f) * 0.07, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(time * (active ? 5.0f : 3.0f)));
        pose.scale(1.5f, 1.5f, 1.5f);
        items.renderStatic(stack, ItemDisplayContext.FIXED, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                pose, buffers, level, 0);
        pose.popPose();
    }
}
