package com.deadrunners.client;

import com.deadrunners.DeadRunnersConfig;

/** Цвета HUD (рывок и Гром) из конфига с кэшем разбора, чтобы не парсить строки каждый кадр. */
public final class HudColors {
    /** Палитра Окабе-Ито: хорошо различима при всех видах дальтонизма. */
    private static final int CB_DASH = 0xE69F00;
    private static final int CB_THUNDER_TOP = 0x56B4E9;
    private static final int CB_THUNDER_BOT = 0x0072B2;

    private static final int CB_HOOK = 0x56B4E9;

    private static String dashSrc, topSrc, botSrc, hookSrc;
    private static int hook = 0x4FA8FF;
    private static int dash = 0xAAAAAA, top = 0xC8E6FF, bot = 0x5A96EB;

    private HudColors() {}

    public static boolean valid(String s) {
        return s != null && s.matches("#?[0-9A-Fa-f]{6}");
    }

    private static int parse(String s, int fallback) {
        if (!valid(s)) return fallback;
        return Integer.parseInt(s.startsWith("#") ? s.substring(1) : s, 16);
    }

    public static int dash() {
        var c = DeadRunnersConfig.CLIENT;
        if (c.colorblindMode.get()) return CB_DASH;
        String s = c.dashColor.get();
        if (!s.equals(dashSrc)) {
            dashSrc = s;
            dash = parse(s, 0xAAAAAA);
        }
        return dash;
    }

    public static int hook() {
        var c = DeadRunnersConfig.CLIENT;
        if (c.colorblindMode.get()) return CB_HOOK;
        String s = c.hookColor.get();
        if (!s.equals(hookSrc)) {
            hookSrc = s;
            hook = parse(s, 0x4FA8FF);
        }
        return hook;
    }

    public static int thunderTop() {
        var c = DeadRunnersConfig.CLIENT;
        if (c.colorblindMode.get()) return CB_THUNDER_TOP;
        String s = c.thunderColorTop.get();
        if (!s.equals(topSrc)) {
            topSrc = s;
            top = parse(s, 0xC8E6FF);
        }
        return top;
    }

    public static int thunderBottom() {
        var c = DeadRunnersConfig.CLIENT;
        if (c.colorblindMode.get()) return CB_THUNDER_BOT;
        String s = c.thunderColorBottom.get();
        if (!s.equals(botSrc)) {
            botSrc = s;
            bot = parse(s, 0x5A96EB);
        }
        return bot;
    }
}
