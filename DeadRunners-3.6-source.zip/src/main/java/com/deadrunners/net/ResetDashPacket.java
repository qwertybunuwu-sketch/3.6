package com.deadrunners.net;

import com.deadrunners.client.ClientEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: сфера ветра сбросила перезарядку рывка. */
public record ResetDashPacket() {
    public void encode(FriendlyByteBuf buf) {}

    public static ResetDashPacket decode(FriendlyByteBuf buf) {
        return new ResetDashPacket();
    }

    public static void handle(ResetDashPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> ClientEvents::resetDashCooldown));
        ctx.setPacketHandled(true);
    }
}
