package com.deadrunners.net;

import com.deadrunners.client.HookWebs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиенты рядом: другой игрок запустил крюк, показать паутину. */
public record HookFxPacket(int entityId, BlockPos pos) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeBlockPos(pos);
    }

    public static HookFxPacket decode(FriendlyByteBuf buf) {
        return new HookFxPacket(buf.readVarInt(), buf.readBlockPos());
    }

    public static void handle(HookFxPacket packet, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> HookWebs.addRemote(packet.entityId(), packet.pos())));
        ctx.setPacketHandled(true);
    }
}
