package com.deadrunners;

public enum HudStyle {
    /** Широкая низкая полоска, заполняется слева направо. */
    BAR,
    /** Маленький квадрат, заполняется снизу вверх. */
    SQUARE
}
