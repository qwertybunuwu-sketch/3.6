package com.deadrunners.block;

import com.deadrunners.CheckpointClient;
import com.deadrunners.CheckpointData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Звезда-чекпоинт: ПКМ сохраняет позицию игрока как точку возрождения. */
public class CheckpointStarBlock extends BaseEntityBlock {
    private static final VoxelShape SHAPE = Block.box(3.0, 0.0, 3.0, 13.0, 14.0, 13.0);

    public CheckpointStarBlock(Properties props) {
        super(props);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CheckpointStarBlockEntity(pos, state);
    }

    /** Сам блок не рисуется — дискету рисует рендерер блок-сущности. */
    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel sl) {
            CheckpointData.onStarRemoved(sl, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) CheckpointData.saveFor(sp, pos);
        return InteractionResult.CONSUME;
    }

    /** Активное состояние: проверяется только при отрисовке (клиентский случайный тик блока рядом с игроком). */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource rnd) {
        if (!CheckpointClient.isActive(level.dimension(), pos)) return;
        double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
        level.addParticle(ParticleTypes.END_ROD, x + (rnd.nextDouble() - 0.5) * 0.5, y + rnd.nextDouble() * 0.6,
                z + (rnd.nextDouble() - 0.5) * 0.5, 0.0, 0.03, 0.0);
        if (rnd.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.HAPPY_VILLAGER, x + (rnd.nextDouble() - 0.5), y + rnd.nextDouble(),
                    z + (rnd.nextDouble() - 0.5), 0.0, 0.0, 0.0);
        }
    }
}
