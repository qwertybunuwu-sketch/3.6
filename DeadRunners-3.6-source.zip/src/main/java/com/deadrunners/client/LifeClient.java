package com.deadrunners.client;

import net.minecraft.util.Mth;

/** Клиентское состояние ожогов (приходит с сервера, таймер горения дальше считается локально). */
public final class LifeClient {
    private static int burnLeft;
    private static int burnTotal;
    private static int scars;

    private LifeClient() {}

    public static void set(int left, int total, int sc) {
        burnLeft = left;
        burnTotal = total;
        scars = sc;
    }

    public static void tick() {
        if (burnLeft > 0) burnLeft--;
    }

    public static void reset() {
        burnLeft = 0;
        burnTotal = 0;
        scars = 0;
    }

    public static boolean burning() {
        return burnLeft > 0;
    }

    public static float burnFraction(float partial) {
        return burnTotal > 0 ? Mth.clamp((burnLeft - partial) / (float) burnTotal, 0.0f, 1.0f) : 0.0f;
    }

    public static int scars() {
        return scars;
    }
}
