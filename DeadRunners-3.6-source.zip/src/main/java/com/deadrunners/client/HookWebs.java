package com.deadrunners.client;

import com.deadrunners.DeadRunnersMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Паутина крюка: синяя лента с шиповым узлом на конце. Рисуется без аллокаций на сегмент. */
@Mod.EventBusSubscriber(modid = DeadRunnersMod.MODID, value = Dist.CLIENT)
public final class HookWebs {
    private static final int FLY = 3;
    private static final int FADE = 5;
    private static final int MAX = 16;
    private static final int SEGMENTS = 14;

    public static final class Web {
        final int entityId;
        final BlockPos target;
        int age;
        int end = -1;

        Web(int entityId, BlockPos target) {
            this.entityId = entityId;
            this.target = target;
        }
    }

    private static final List<Web> WEBS = new ArrayList<>();

    private HookWebs() {}

    public static Web addLocal(BlockPos target) {
        return add(new Web(-1, target));
    }

    public static void addRemote(int entityId, BlockPos target) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.getId() == entityId) return;
        Web w = add(new Web(entityId, target));
        Entity e = mc.level != null ? mc.level.getEntity(entityId) : null;
        double dist = e != null ? e.position().distanceTo(Vec3.atCenterOf(target)) : 8.0;
        w.end = FLY + (int) Math.ceil(dist / 1.6) + 1;
    }

    private static Web add(Web w) {
        if (WEBS.size() >= MAX) WEBS.remove(0);
        WEBS.add(w);
        return w;
    }

    public static void end(Web w) {
        if (w.end < 0) w.end = w.age;
    }

    public static void clear() {
        WEBS.clear();
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || WEBS.isEmpty() || Minecraft.getInstance().isPaused()) return;
        for (int i = WEBS.size() - 1; i >= 0; i--) {
            Web w = WEBS.get(i);
            w.age++;
            if ((w.end >= 0 && w.age - w.end > FADE) || w.age > 100) WEBS.remove(i);
        }
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || WEBS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        float pt = event.getPartialTick();
        Camera cam = event.getCamera();
        Vec3 cp = cam.getPosition();
        PoseStack ps = event.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = bs.getBuffer(RenderType.lightning());
        int rgb = HudColors.hook();
        int cr = (rgb >> 16) & 255, cg = (rgb >> 8) & 255, cb = rgb & 255;

        for (Web w : WEBS) {
            // начало ленты
            double ox, oy, oz;
            if (w.entityId < 0) {
                Vec3 pp = mc.player.getPosition(pt);
                if (!cam.isDetached()) {
                    var look = cam.getLookVector();
                    var left = cam.getLeftVector();
                    var up = cam.getUpVector();
                    ox = cp.x + look.x() * 0.6 - left.x() * 0.3 - up.x() * 0.3;
                    oy = cp.y + look.y() * 0.6 - left.y() * 0.3 - up.y() * 0.3;
                    oz = cp.z + look.z() * 0.6 - left.z() * 0.3 - up.z() * 0.3;
                } else {
                    ox = pp.x;
                    oy = pp.y + mc.player.getBbHeight() * 0.7;
                    oz = pp.z;
                }
            } else {
                Entity e = mc.level.getEntity(w.entityId);
                if (e == null) continue;
                Vec3 pp = e.getPosition(pt);
                ox = pp.x;
                oy = pp.y + e.getBbHeight() * 0.7;
                oz = pp.z;
            }
            double tx = w.target.getX() + 0.5, ty = w.target.getY() + 0.5, tz = w.target.getZ() + 0.5;
            float t = Mth.clamp((w.age + pt) / FLY, 0.0f, 1.0f);
            float ease = 1.0f - (1.0f - t) * (1.0f - t);
            double bx = ox + (tx - ox) * ease, by = oy + (ty - oy) * ease, bz = oz + (tz - oz) * ease;
            float alpha = w.end < 0 ? 1.0f : Mth.clamp(1.0f - (w.age - w.end + pt) / FADE, 0.0f, 1.0f);
            if (alpha <= 0.01f) continue;
            float tension = Mth.clamp(1.0f - (w.age + pt - FLY) / 10.0f, 0.0f, 1.0f);
            float amp = 0.02f + 0.25f * tension * (t >= 1.0f ? 1.0f : 0.3f);
            float time = (w.age + pt) * 1.6f;

            // координаты относительно камеры
            double ax = ox - cp.x, ay = oy - cp.y, az = oz - cp.z;
            double ex = bx - cp.x, ey = by - cp.y, ez = bz - cp.z;
            double dx = ex - ax, dy = ey - ay, dz = ez - az;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-3) continue;
            double ndx = dx / len, ndy = dy / len, ndz = dz / len;

            double px = ax, py = ay, pz = az;
            double sx = 0, sy = 0, sz = 0;
            boolean first = true;
            double psx = 0, psy = 0, psz = 0;
            double ppx = 0, ppy = 0, ppz = 0;
            for (int i = 0; i <= SEGMENTS; i++) {
                float f = i / (float) SEGMENTS;
                double mx = ax + dx * f, my = ay + dy * f, mz = az + dz * f;
                // боковой вектор ленты: перпендикуляр к направлению и взгляду
                double cxv = ndy * mz - ndz * my, cyv = ndz * mx - ndx * mz, czv = ndx * my - ndy * mx;
                double cl = Math.sqrt(cxv * cxv + cyv * cyv + czv * czv);
                if (cl < 1.0E-6) { cxv = 0; cyv = 1; czv = 0; cl = 1; }
                sx = cxv / cl; sy = cyv / cl; sz = czv / cl;
                float wob = Mth.sin(f * (float) Math.PI) * amp * Mth.sin(time + f * 7.0f);
                double qx = mx + sx * wob, qy = my + sy * wob, qz = mz + sz * wob;
                if (!first) {
                    ribbon(vc, m, ppx, ppy, ppz, psx, psy, psz, qx, qy, qz, sx, sy, sz, 0.10f, cr, cg, cb, 70 * alpha);
                    ribbon(vc, m, ppx, ppy, ppz, psx, psy, psz, qx, qy, qz, sx, sy, sz, 0.05f, cr, cg, cb, 200 * alpha);
                    ribbon(vc, m, ppx, ppy, ppz, psx, psy, psz, qx, qy, qz, sx, sy, sz, 0.018f, 255, 255, 255, 235 * alpha);
                }
                ppx = qx; ppy = qy; ppz = qz;
                psx = sx; psy = sy; psz = sz;
                first = false;
            }
            node(vc, m, ex, ey, ez, ndx, ndy, ndz, sx, sy, sz, cr, cg, cb, alpha);
        }
        bs.endBatch(RenderType.lightning());
    }

    private static void v(VertexConsumer vc, Matrix4f m, double x, double y, double z, int r, int g, int b, float a) {
        vc.vertex(m, (float) x, (float) y, (float) z).color(r, g, b, Mth.clamp(Math.round(a), 0, 255)).endVertex();
    }

    private static void ribbon(VertexConsumer vc, Matrix4f m,
                               double ax, double ay, double az, double asx, double asy, double asz,
                               double bx, double by, double bz, double bsx, double bsy, double bsz,
                               float w, int r, int g, int b, float a) {
        v(vc, m, ax - asx * w, ay - asy * w, az - asz * w, r, g, b, a);
        v(vc, m, ax + asx * w, ay + asy * w, az + asz * w, r, g, b, a);
        v(vc, m, bx + bsx * w, by + bsy * w, bz + bsz * w, r, g, b, a);
        v(vc, m, bx - bsx * w, by - bsy * w, bz - bsz * w, r, g, b, a);
    }

    /** Круглый узел с шипом: лист-«ромб» вперёд по направлению ленты и восьмиугольник ядра. */
    private static void node(VertexConsumer vc, Matrix4f m, double x, double y, double z,
                             double dx, double dy, double dz, double sx, double sy, double sz,
                             int r, int g, int b, float alpha) {
        // второй базисный вектор в плоскости, обращённой к камере: n x s, где n = направление к камере
        double nl = Math.sqrt(x * x + y * y + z * z);
        if (nl < 1.0E-6) return;
        double nx = -x / nl, ny = -y / nl, nz = -z / nl;
        double ux = ny * sz - nz * sy, uy = nz * sx - nx * sz, uz = nx * sy - ny * sx;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (ul < 1.0E-6) return;
        ux /= ul; uy /= ul; uz /= ul;
        // шип
        double tipx = x + dx * 0.42, tipy = y + dy * 0.42, tipz = z + dz * 0.42;
        v(vc, m, x - sx * 0.07, y - sy * 0.07, z - sz * 0.07, 255, 255, 255, 235 * alpha);
        v(vc, m, tipx, tipy, tipz, 255, 255, 255, 235 * alpha);
        v(vc, m, tipx, tipy, tipz, 255, 255, 255, 235 * alpha);
        v(vc, m, x + sx * 0.07, y + sy * 0.07, z + sz * 0.07, 255, 255, 255, 235 * alpha);
        // ядро: восьмиугольник из четырёхугольников от центра
        for (int layer = 0; layer < 2; layer++) {
            float rad = layer == 0 ? 0.14f : 0.07f;
            int cr = layer == 0 ? r : 255, cg = layer == 0 ? g : 255, cb = layer == 0 ? b : 255;
            float a = (layer == 0 ? 230 : 255) * alpha;
            for (int k = 0; k < 8; k++) {
                double a0 = k * Math.PI / 4.0, a1 = (k + 1) * Math.PI / 4.0;
                double c0 = Math.cos(a0) * rad, s0 = Math.sin(a0) * rad;
                double c1 = Math.cos(a1) * rad, s1 = Math.sin(a1) * rad;
                v(vc, m, x, y, z, cr, cg, cb, a);
                v(vc, m, x + sx * c0 + ux * s0, y + sy * c0 + uy * s0, z + sz * c0 + uz * s0, cr, cg, cb, a);
                v(vc, m, x + sx * c1 + ux * s1, y + sy * c1 + uy * s1, z + sz * c1 + uz * s1, cr, cg, cb, a);
                v(vc, m, x + sx * c1 + ux * s1, y + sy * c1 + uy * s1, z + sz * c1 + uz * s1, cr, cg, cb, a);
            }
        }
    }
}
